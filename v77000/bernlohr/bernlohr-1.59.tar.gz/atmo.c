/* ============================================================================

   Copyright (C) 1990, 1997, 1998, ..., 2010, 2017, 2018, 2019  Konrad Bernloehr

   This file is part of the IACT/atmo package for CORSIKA.

   The IACT/atmo package is free software; you can redistribute it 
   and/or modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   This package is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this package. If not, see <http://www.gnu.org/licenses/>.

============================================================================ */

/* ================================================================== */
/**
 *  @file atmo.c
 *  @short Use of tabulated atmospheric profiles and atmospheric refraction.
 *
 *  @author  Konrad Bernloehr 
 *  @date    @verbatim CVS $Date: 2019-02-02 14:58:08 +0100 (Sa, 02 Feb 2019) $ @endverbatim
 *  @version @verbatim CVS $Revision: 6973 $ @endverbatim
 *
 *  --------------------------------------------------------------------
 *
 *  This file provides code for use of external atmospheric models
 *  (in the form of text-format tables) with the CORSIKA program.
 *  Six atmospheric models as implemented in the MODTRAN program
 *  and as tabulated in MODTRAN documentation (F.X. Kneizys et al. 1996,
 *  'The MODTRAN 2/3 Report and LOWTRAN 7 Model', Phillips Laboratory,
 *  Hanscom AFB, MA 01731-3010, U.S.A.) are provided as separate files
 *  (atmprof1.dat ... atmprof6.dat). User-provided atmospheric
 *  models should be given model numbers above 6.
 *  For model number 99 you may actually define a non-standard file
 *  name, rather than atmprof99.dat.
 *
 *  Note that for the Cherenkov part and the hadronic (and muon) part
 *  of CORSIKA the table values are directly interpolated but the
 *  electron/positron/gamma part (derived from EGS) uses special
 *  layers (at present 4 with exponential density decrease and the
 *  most upper layer with constant density). Parameters of these
 *  layers are fitted to tabulated values but not every possible
 *  atmospheric model fits very well with an exponential profile.
 *  You are adviced to check that the fit matches tabulated values to
 *  sufficient precision in the altitude ranges of interest to you.
 *  Try to adjust layer boundary altitudes in case of problems.
 *  The propagation of light without refraction (as implemented in
 *  CORSIKA, unless using the CURVED option) and with refraction (as
 *  implemented by this software) assumes a plane-parallel atmosphere.
 *  Instead of a single set of starting layer boundaries, newer version
 *  (Jan. 2019) try different sets of boundaries and use the most
 *  promising set for further fit improvement.
 *
 *  There are different ways to load and interpolate an atmospheric
 *  profile table. The usual procedure is that after loading the
 *  values from the file, the nearly exponential structure is taken
 *  advantage of and a relatively large number (order 10k) of
 *  equidistant support points are pre-interpolated from the original
 *  non-equidistant levels of the input point, saving binary-search
 *  of the matching interval for each interpolation. This FAST_INTERPOLATION
 *  option is activated by default but can be disabled by compiling
 *  with '-DNO_FAST_INTERPOLATION' (or '-DNO_FAST_INTERPOLATION2' if
 *  only fast interpolation for the reverse direction, from thickness
 *  to altitude, should be disabled.)
 *  The initial pre-interpolation used to be a linear interpolation in
 *  altitude versus log(density) or log(thickness) or log(n-1),
 *  respectively but with the 'rpolator' table interpolation code
 *  this can be turned into cubic spline interpolation.
 *  Unless problems with the CORSIKA build procedure prevent that
 *  the rpolator code and its cubic spline interpolation are intended
 *  to be the default scheme from now on (Jan. 2019). In either case
 *  for the default setting, the rpolator code and be enforced with
 *  '-DWITH_RPOLATOR' or disabled with '-DNO_RPOLATOR'.
 *  Cubic spline interpolation can be disabled with '-DNO_RPOLATOR_CSPLINE'.
 *  The fine-grained interpolation under the FAST_INTERPOLATION scheme
 *  continues to be linear in altitude versus log(density) etc.
 *
 *  Because the CORSIKA build procedure does not know yet about the additional
 *  source file, it gets included when compiling atmo.c, unless compiled with
 *  '-DWITH_RPOLATOR_SEPARATE'.
*/
/* ==================================================================== */

/** @ingroup iact_atmo_interface The CORSIKA iact/atmo interface */
/** @{ */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#ifndef M_PI
# define M_PI (3.14159265358979323846264338327950288)
#endif

#include "atmo.h"
#include "fileopen.h"

#include "rpolator.h"

/* We need the following line for sim_telarray but not with CORSIKA: */
/* # define WITH_RPOLATOR_SEPARATE 1 */ /* For now handled by the Makefile */

/* If rpolator is requested, either by default or explicitly, include the header file/source file. */
/* The problem here is the CORSIKA build process which does not know yet about the rpolator */
/* source code. This is circumvented for the time being by including the source code directly */
/* rather than compiling it separately and linking with it. */
#ifndef WITH_RPOLATOR_SEPARATE
# include "rpolator.c" /* Include C source file to keep the build happy with the old Makefile.am etc. for now. */
#endif

/* Now always using cubic splines, at least in initialization */
#define WITH_RPOLATOR_CSPLINE 1 /* Take advantage of cubic splines if we have them available */

/*
 * The fast interpolation method sidesteps calls to LOG and EXP functions
 * by a narrower internal step size but can result in little artifacts
 * around the sampling points of the atmospheric profile.
 * The fast interpolation scheme is now always used. Cannot be disabled anymore.
 */

#define FAST_INTERPOLATION  always
#define FAST_INTERPOLATION2 always
#define FAST_INTERPOLATION3 always

#ifndef NO_THICKX_DIRECT
# ifndef WITH_THICKX_DIRECT
#  define WITH_THICKX_DIRECT
# endif
#endif

// # ifndef NO_THICKX_DIRECT_CSPLINE
// #  ifndef WITH_THICKX_DIRECT_CSPLINE
// #   define WITH_THICKX_DIRECT_CSPLINE
// #  endif
// # endif

#ifndef UNUSED
# ifdef __GNUC__
#  define UNUSED(x) UNUSED_ ## x __attribute__((__unused__))
# else
#  define UNUSED(x) UNUSED_ ## x
# endif
#endif

#ifdef __cplusplus
/* You can compile this file with a C++ compiler instead of a C compiler, if you want */
extern "C" {
#endif

/* Local C called functions (parameter types are always checked) */
static void init_refraction_tables(void);
static void init_fast_interpolation(void);
static void init_corsika_atmosphere(void);
static void init_atmosphere(void);
static double sum_log_dev_sq(double a, double b, double c, int np, 
   double *h, double *t, double *rho);
static double atm_exp_fit(double h1, double h2, double *ap, double *bp, 
   double *cp, double *s0, int *npp);

/* Variables used for atmospheric profiles */

#define MAX_PROFILE 120
int atmosphere;                                      /**< The atmospheric profile number, 0 for built-in. */
static char *atmprof_name = NULL;                    /**< File name for atmospheric profile table. */
static int num_prof;                                 /**< Number of levels in original table. */
static double p_alt[MAX_PROFILE];                    /**< Altitude levels in given table (converted to [cm], upward order). */
static double p_alt_rev[MAX_PROFILE];                /**< Altitude levels in given table (converted to [cm], reversed order). */
static double p_rho[MAX_PROFILE];                    /**< Density at given levels [g/cm^3] (upward height order) */
static double p_rho_rev[MAX_PROFILE];                /**< Density at given levels [g/cm^3], reversed order */
static double p_thick[MAX_PROFILE];                  /**< Atmospheric thickness at given levels [g/cm^2] */
static double p_log_rho[MAX_PROFILE];                /**< Log of density at given levels (for better interpolation) */
static double p_log_thick[MAX_PROFILE];              /**< Log of atmospheric thickness at given levels (upward height order) */
static double p_log_thick_rev[MAX_PROFILE];          /**< Log of atmospheric thickness at given levels (reversed order) */
static double p_log_n1[MAX_PROFILE];                 /**< Log of (index of refraction minus 1.0) at given levels. */
static double p_bend_ray_hori_a[MAX_PROFILE];        /**< Coefficient for horizontal displacement refraction effect (reversed order) */
static double p_bend_ray_time_a[MAX_PROFILE];        /**< Coefficient for arrival time effect by refraction, density dependence (reversed order) */
static double p_bend_ray_time0[MAX_PROFILE];         /**< Coefficient for arrival time effect by refraction, altitude dependence */

static CsplinePar *cs_alt_log_rho;                   /**< Cubic spline parameters for log(density) versus altitude interpolation */
static CsplinePar *cs_alt_log_thick;                 /**< Cubic spline parameters for log(thickness) versus altitude interpolation */
static CsplinePar *cs_alt_log_n1;                    /**< Cubic spline parameters for log(n-1) versus altitude interpolation */
static CsplinePar *cs_log_thick_alt;                 /**< Cubic spline parameters for altitude versus log(thickness) reverse interpolation */
static CsplinePar *cs_bend_rho_hori_a;               /**< Cubic spline parameters for horizontal displacement refraction effect */
static CsplinePar *cs_bend_rho_time_a;               /**< Cubic spline parameters for arrival time effect by refraction, density dependence */
static CsplinePar *cs_bend_alt_time0;                /**< Cubic spline parameters for arrival time effect by refraction, altitude dependence */

static double top_of_atmosphere = 112.83e5;          /**< Height of top of atmosphere [cm], = p_alt[num_prof-1] */
static double bottom_of_atmosphere = 0.;             /**< Bottom is normally at sea level but table could differ, = p_alt[0] */
static double bottom_log_thickness;                  /**< Thickness at bottom, depending on profile, = p_log_thick[0] */
static double top_log_thickness;                     /**< Thickness at top is zero, thus using an extrapolation from the second last value */
                                                     /**< for fast interpolation in reverse direction (thickness to height). */

static double top_layer_2nd_altitude;                /**< Second highest altitude tabulated, using exponential density profile above that. */
static double top_layer_rho0;                        /**< Sea-level altitude matching profile in top layer, without scaling for thickness. */
static double top_layer_cfac;                        /**< Scaling factor needed to match thickness at second last level. */
static double top_layer_hscale;                      /**< Height scale of exponention density profile in top layer. */
static double top_layer_hscale_rho0_cfac;            /**< top_layer_rho0 * top_layer_cfac * top_layer_hscale */
static double top_layer_hscale_rho0_cfac_inv;        /**< 1./(top_layer_rho0 * top_layer_cfac * top_layer_hscale) */
static double top_layer_exp_top;                     /**< exp(-top_of_atmosphere/top_layer_hscale) */

#define MAX_FAST_PROFILE 40000
static double *fast_p_alt;              /**< Equidistant steps in altitude */
static double *fast_p_log_rho;          /**< Log(rho) at fast_p_alt steps */
static double *fast_p_log_thick;        /**< Log(thick) at fast_p_alt steps */
static double *fast_p_log_n1;           /**< Log(n-1) at fast_p_alt steps */
static double fast_h_fac;               /**< Inverse of height difference per step */
#ifdef WITH_THICKX_DIRECT
static double *fast_p_thick;            /**< Direct interpolation of thickness at fast_p_alt steps */
static double *fast_p_rho;              /**< Direct interpolation of density at fast_p_alt steps */
static double *fast_p_n1;                 /**< Direct interpolation of n-1 at fast_p_alt steps */
# ifdef WITH_THICKX_DIRECT_CSPLINE
static CsplinePar *cs_alt_thick;        /**< Cubic spline parameters for thickness directly versus altitude interpolation */
static CsplinePar *cs_alt_rho;          /**< Cubic spline parameters for density directly versus altitude interpolation */
static CsplinePar *cs_alt_n1;           /**< Cubic spline parameters for n-1 directly versus altitude interpolation */
# endif
#endif
static double *fast_p_eq_log_thick;     /**< Equidistant steps in log(thick) */
static double *fast_p_heigh_rev;        /**< Altitude at given log(thick) steps */
static double fast_log_thick_fac;       /**< Inverse of log(thickness) difference per step */
static double *fast_p_bend_ray_hori_a;  /**< Coefficient for horizontal displacement refraction effect */
static double *fast_p_bend_ray_time_a;  /**< Coefficient for arrival time effect by refraction, density dependence */
static double *fast_p_bend_ray_time0;   /**< Coefficient for arrival time effect by refraction, altitude dependence */
static double *fast_p_rho_rev;          /**< Density steps used in fast interpolation, in order of incr. density */
static double fast_rho_fac;

void free_atmo_csplines(void);

void free_atmo_csplines()
{
   if ( cs_alt_log_rho != (CsplinePar *) NULL )
   {
      free(cs_alt_log_rho);
      cs_alt_log_rho = NULL;
   }
   if ( cs_alt_log_thick != (CsplinePar *) NULL )
   {
      free(cs_alt_log_thick);
      cs_alt_log_thick = NULL;
   }
   if ( cs_alt_log_n1 != (CsplinePar *) NULL )
   {
      free(cs_alt_log_n1);
      cs_alt_log_n1 = NULL;
   }
   if ( cs_log_thick_alt != (CsplinePar *) NULL )
   {
      free(cs_log_thick_alt);
      cs_log_thick_alt = NULL;
   }
   if ( cs_bend_rho_hori_a != (CsplinePar *) NULL )
   {
      free(cs_bend_rho_hori_a);
      cs_bend_rho_hori_a = NULL;
   }
   if ( cs_bend_rho_time_a != (CsplinePar *) NULL )
   {
      free(cs_bend_rho_time_a);
      cs_bend_rho_time_a = NULL;
   }
   if ( cs_bend_alt_time0 != (CsplinePar *) NULL )
   {
      free(cs_bend_alt_time0);
      cs_bend_alt_time0 = NULL;
   }
}

/* ======================================================================= */

static double etadsn = 0.000283 * 994186.38 / 1222.656; /* CORSIKA default */;  
static double observation_level;  /**< Altitude [cm] of observation level */
static double obs_level_refidx;
static double obs_level_thick;

/* ========================== trace_ray_planar ======================= */
/**
 *  @short Trace a downward light ray in a planar atmosphere.
 *
 *  @param emlev Emission level altitude [cm]
 *  @param olev  Observation level altitude [cm] (below emlev)
 *  @param za    Zenith angle (positive downwards)
 *  @param step  Step length [cm]
 *  @param xo    Arrival position at observation level [cm] (returned only),
 *               positive value expected for downward bending.
 *  @param to    Travel time to observation level [ns] (returned only).
 *  @param so    Path length travelled [cm] (returned only).
 */

static void trace_ray_planar(double emlev, double olev, double za, double step,
   double *xo, double *to, double *so);

static void trace_ray_planar(double emlev, double olev, double za, double step,
   double *xo, double *to, double *so)
{
   double ss = 0., t = 0., dt;
   double vc = 29.9792458; /* Vacuum speed of light [cm/ns] */
   double vci = 1./vc; /* Inverse of vacuum speed of light */

   double cz = cos(za);
   double sz = sin(za);

   if ( emlev < olev )
   {
      double tlev = emlev;
      emlev = olev;
      olev = tlev;
   }
   double h = emlev >= olev ? emlev-olev : 0.;
   double y = olev + h;
   double x = h * tan(za);
   double n1 = refidx_(&y);
//   printf("Start ray at x = %5.3f m, z = %5.3f m a.s.l., n=%8.6f\n",
//      x*1e-2, y*1e-2, n1);
   double p = n1*sz; /* Invariant */
   double x2, y2, h2, sz2, cz2, n2;
   
   while ( h > 0. )
   {
      double nstep = (h>step*cz) ? step : h/cz;
      double dx;

      y2 = y - nstep * cz;
      h2 = y2 - olev;
      n2 = refidx_(&y2);
      sz2 = p/n2;
      cz2 = sqrt(1.-sz2*sz2);
      dx = nstep * 0.5*(sz+sz2);
      x2 = x - dx;
      
      ss += nstep;
      dt = nstep * 0.5*(n1+n2) * vci;
      t += dt;

      sz = sz2;
      cz = cz2;
      x  = x2;
      y  = y2;
      h  = h2;
      n1 = n2;
   }
   *xo = x;
   *to = t;
   *so = ss;
}

/* ------------------- init_refraction_tables ---------------------- */
/**
 *  @short Initialize tables needed for atmospheric refraction.
 *
 *  Initialize the correction tables used for the refraction bending
 *  of the light paths. It is called once after the atmospheric
 *  profile has been defined.
*/

static void init_refraction_tables()
{
   int ialt;
   
   /* Etadsn is the parameter used in CORSIKA for the scaling */
   /* between density and index of refraction minus one (n-1). */
   etadsn = 0.000283 * 994186.38 / 1222.656; /* CORSIKA default */
#ifdef DEBUG_TEST_ALL
   printf("Etadsn=(n-1)/density parameter as in CORSIKA: %g\n",etadsn);
#endif
   /* Look for better approximation above the observation level. */
   for (ialt=0; ialt<num_prof; ialt++)
   {
      if ( p_alt[ialt] > observation_level + 1.5e5 )
      {
         etadsn = exp(p_log_n1[ialt]) / exp(p_log_rho[ialt]);
         break;
      }
   }

#ifdef DEBUG_TEST_ALL
   if ( p_alt[0] != p_alt[4] && p_log_rho[0] != p_log_rho[4] )
   {
      double dscl_p, dscl_t;
      dscl_p = (p_alt[4]-p_alt[0]) / (p_log_rho[0]-p_log_rho[4]);
      dscl_t = (p_alt[4]-p_alt[0]) / (p_log_thick[0]-p_log_thick[4]);
      printf("Pressure scale height near ground: %7.2f m\n",dscl_p*0.01);
      printf("Thickness scale height near ground: %7.2f m\n",dscl_t*0.01);
      printf("Etadsn=(n-1)/density parameter at 15 km above ground: %g\n",etadsn);
   }
#endif
   
   /* Initialize tables by numerical integration for vertical and slanted */
   /* (45 degrees) paths, taking into account known angular dependencies. */

   for (ialt=0; ialt<num_prof; ialt++)
   {
      double theta0 = 45. * (M_PI/180.);
      double n_sint0 = refidx_(&p_alt[ialt]) * sin(theta0);
      double x0=0., t_vt=0., s0=0.;
      double x_45=0., t_45=0., s45=0.;
      double theta1 = asin(n_sint0/refidx_(&observation_level));
      double c = cos(theta0+0.28*(theta1-theta0));
      double s = sin(theta0+0.28*(theta1-theta0));
      double vc = 29.9792458; /* Vacuum speed of light [cm/ns] */
      double vci = 1./vc; /* Inverse of vacuum speed of light */
      double airmass = 1./cos(theta0);
      double zem = p_alt[ialt];
      double dz = (zem - observation_level);
      double de = etadsn*(thickx_(&observation_level)-thickx_(&zem));
      double t0_vt = (dz + de) * vci; /* Vertical time estimate to observation level */
      double t0_45 = t0_vt * airmass; /* Inclined time estimate for straight-line track */

      trace_ray_planar(p_alt[ialt],observation_level, 0., 2.5e2, &x0, &t_vt, &s0);
      trace_ray_planar(p_alt[ialt],observation_level, theta0, 2.5e2, &x_45, &t_45, &s45);

      if ( p_alt[ialt] < observation_level )
      {
         t_vt *= -1.;
         t_45 *= -1.;
         x_45 *= -1.;
      }
      /* The bending parameter looked up by altitude is filled in normal order. */
      p_bend_ray_time0[ialt]  = t_vt - t0_vt;
      /* The bending parameters looked up by density are filled in reverse order 
         since cubic spline interpolation needs supporting points in rising order. */
      if ( x_45 >= 0. ) /* Normally positive, tracing the other way in x as in the old code, here x0_45=0. */
         p_bend_ray_hori_a[num_prof-1-ialt] = sqrt(x_45 * (c*c*c)/s);
      else
         p_bend_ray_hori_a[num_prof-1-ialt] = -sqrt(-x_45 * (c*c*c)/s);
      if ( ((t_45 - t0_45) - (t_vt - t0_vt)) < 0. )
      {
         p_bend_ray_time_a[num_prof-1-ialt] = 
          sqrt(((t0_45 - t_45) - (t0_vt - t_vt)) * (c*c*c)/(s*s));
      }
      else
         p_bend_ray_time_a[num_prof-1-ialt] = sqrt(-((t0_45 - t_45) - (t0_vt - t_vt)) * (c*c*c)/(s*s));;
   }

#ifdef TEST_RAYBND
for (ialt=0; ialt<num_prof; ialt++)
{
   printf("++ h=%g [km]   time0=%g   time_a=%g [ns]   hori_a=%g [m]\n",
      p_alt[ialt]*1e-5, p_bend_ray_time0[ialt], p_bend_ray_time_a[num_prof-1-ialt], p_bend_ray_hori_a[num_prof-1-ialt]);
}
#endif

   /* Set up cubic spline interpolation parameters for refraction. */
   /* These parameters are allocated once and never free()ed; thus might get reported as memory leaks. */
   cs_bend_rho_hori_a   = set_1d_cubic_params (p_rho_rev, p_bend_ray_hori_a, num_prof, 0);
   cs_bend_rho_time_a   = set_1d_cubic_params (p_rho_rev, p_bend_ray_time_a, num_prof, 0);
   cs_bend_alt_time0    = set_1d_cubic_params (p_alt, p_bend_ray_time0,  num_prof, 0);

   if ( fast_p_rho_rev == (double *) NULL )
      fast_p_rho_rev = (double *) calloc(MAX_FAST_PROFILE,sizeof(double));
   if ( fast_p_bend_ray_hori_a == (double *) NULL )
      fast_p_bend_ray_hori_a = (double *) calloc(MAX_FAST_PROFILE,sizeof(double));
   if ( fast_p_bend_ray_time_a == (double *) NULL )
      fast_p_bend_ray_time_a = (double *) calloc(MAX_FAST_PROFILE,sizeof(double));
   if ( fast_p_bend_ray_time0 == (double *) NULL )
      fast_p_bend_ray_time0 = (double *) calloc(MAX_FAST_PROFILE,sizeof(double));

   /* Set up fast interpolation, without binary search, also for refraction correction */
   fast_rho_fac = (double)(MAX_FAST_PROFILE-1) / p_rho[0];
   int i;
   for ( i=0; i<MAX_FAST_PROFILE; i++)
   {
      double rho, h;
      if ( i < MAX_FAST_PROFILE-1 )
         fast_p_rho_rev[i] = rho = i / fast_rho_fac;
      else /* avoid rounding errors */
         fast_p_rho_rev[i] = rho = p_rho[0];
      h = fast_p_alt[i];
      fast_p_bend_ray_hori_a[i] = rpol_cspline(p_rho_rev, p_bend_ray_hori_a, cs_bend_rho_hori_a, num_prof, rho, 0, 0);
      fast_p_bend_ray_time_a[i] = rpol_cspline(p_rho_rev, p_bend_ray_time_a, cs_bend_rho_time_a, num_prof, rho, 0, 0);
      fast_p_bend_ray_time0[i]  = rpol_cspline(p_alt, p_bend_ray_time0,  cs_bend_alt_time0,  num_prof, h, 0, 0);
   }
}

/* ------------------- init_fast_interpolation ---------------------- */

/** 
 *  @short An alternate interpolation method (which requires that the
 *         table is sufficiently fine-grained and equidistant) has to
 *         be initialized first.
 */

static void init_fast_interpolation()
{
   int i;
   double h2 = p_alt[num_prof-2], h1 = top_of_atmosphere; /* Second last and last height */
   double rho2 = p_rho[num_prof-2], rho1 = p_rho[num_prof-1]; /* Corresponding density */
   double hscale = 8.7e5, rho0 = 0., cfac = 1.0;
   double rho, t;
 
   fast_h_fac = (double)(MAX_FAST_PROFILE-1) / 
        (top_of_atmosphere - bottom_of_atmosphere);

   
   if ( rho1 > 0. )
   {
      /* We assume zero thickness at the top, no matter what the table says, but we cannot have its log value. */
      /* Therefore we integrate an assumed exponential density rho(h)=rho0*exp(-h/hscale). */
      hscale = (h1-h2) / log(rho2/rho1);
      rho0   = rho2 / exp(-h2/hscale);
      /* Our integral may not match the thickness at the second last level well; need correction factor. */
      double t2 = hscale * rho0 * (exp(-h2/hscale) - exp(-h1/hscale));
      cfac = p_thick[num_prof-2] / t2;

      if ( num_prof+2 <= MAX_PROFILE )
      {
         double h12 = 0.5*(h1+h2), t12; /* Halfway between h2 and h1 */
         double h14 = 0.25*h1+0.75*h2, t14; /* A quarter between h2 and h1 */
         double h18 = 0.125*h1+0.875*h2, t18; /* A quarter between h2 and h1 */
         t12 = hscale * cfac * rho0 * (exp(-h12/hscale) - exp(-top_of_atmosphere/hscale));
         t14 = hscale * cfac * rho0 * (exp(-h14/hscale) - exp(-top_of_atmosphere/hscale));
         t18 = hscale * cfac * rho0 * (exp(-h18/hscale) - exp(-top_of_atmosphere/hscale));
         double tmp= p_log_thick[num_prof-1];
         p_alt[num_prof-1] = h18;
         p_log_thick[num_prof-1] = log(t18);
         p_alt[num_prof] = h14;
         p_log_thick[num_prof] = log(t14);
         p_alt[num_prof+1] = h12;
         p_log_thick[num_prof+1] = log(t12);
         free(cs_alt_log_thick);
         /* Tweak the cubic spline a bit to go smoother into the explicitely handled final layer */
         /* although we will not use it beyond the second last level. */
         cs_alt_log_thick = set_1d_cubic_params (p_alt, p_log_thick, num_prof+2, 0); /* Include temporary points */
         /* Restore thickness profile as read in */
         p_alt[num_prof-1] = top_of_atmosphere;
         p_log_thick[num_prof-1] = tmp;
      }
   }
   
   if ( fast_p_alt == (double *) NULL )
      fast_p_alt = (double *) calloc(MAX_FAST_PROFILE,sizeof(double));
   if ( fast_p_log_rho == (double *) NULL )
      fast_p_log_rho = (double *) calloc(MAX_FAST_PROFILE,sizeof(double));
   if ( fast_p_log_thick == (double *) NULL )
      fast_p_log_thick = (double *) calloc(MAX_FAST_PROFILE,sizeof(double));
   if ( fast_p_log_n1 == (double *) NULL )
      fast_p_log_n1 = (double *) calloc(MAX_FAST_PROFILE,sizeof(double));
#ifdef WITH_THICKX_DIRECT
   if ( fast_p_rho == (double *) NULL )
      fast_p_rho = (double *) calloc(MAX_FAST_PROFILE,sizeof(double));
   if ( fast_p_thick == (double *) NULL )
      fast_p_thick = (double *) calloc(MAX_FAST_PROFILE,sizeof(double));
   if ( fast_p_n1 == (double *) NULL )
      fast_p_n1 = (double *) calloc(MAX_FAST_PROFILE,sizeof(double));
#endif

   for ( i=0; i<MAX_FAST_PROFILE; i++)
   {
      double h;
      if ( i<MAX_FAST_PROFILE-1 )
         h = fast_p_alt[i] = bottom_of_atmosphere + (double) i / fast_h_fac;
      else /* avoid rounding errors */
         h = fast_p_alt[i] = top_of_atmosphere;

      if ( num_prof >= 2 && h > p_alt[num_prof-2] )
      {
         if ( rho1 > 0. )
         {
            rho = cfac * rho0 * exp(-h/hscale);
            t = hscale * cfac * rho0 * (exp(-h/hscale) - exp(-top_of_atmosphere/hscale));
         }
         else
         {
            /* Last resort: assume linear density */
            double r = log((h-h2)/(h1-h2));
            rho = p_rho[num_prof-2] * r;
            t = p_thick[num_prof-2] * (r*r);
         }
         fast_p_log_rho[i]   = (rho>0.) ? log(rho) : -10.;
         fast_p_log_thick[i] = (t>0.) ? log(t) : -15.;
         fast_p_log_n1[i]    = (rho>0.) ? log(etadsn*rho) : -15.;
      }
      else
      {
         fast_p_log_rho[i]   = rpol_cspline(p_alt, p_log_rho,   cs_alt_log_rho,   num_prof, h, 0, 0);
         fast_p_log_n1[i]    = rpol_cspline(p_alt, p_log_n1,    cs_alt_log_n1,    num_prof, h, 0, 0);
         /* For thickness lookup use cspline ignoring the last level */
         fast_p_log_thick[i] = rpol_cspline(p_alt, p_log_thick, cs_alt_log_thick, num_prof-1, h, 0, 0);
      }
#ifdef WITH_THICKX_DIRECT
      fast_p_thick[i] = exp(fast_p_log_thick[i]);
      fast_p_rho[i]   = exp(fast_p_log_rho[i]);
      fast_p_n1[i]    = exp(fast_p_log_n1[i]);
#endif

#ifdef MORE_ATMO_TESTS
      printf("@a  %d   %g  %g %g %g   %g %g %g\n", 
         i, fast_p_alt[i], fast_p_log_rho[i], fast_p_log_thick[i], fast_p_log_n1[i],
         exp(fast_p_log_rho[i]), exp(fast_p_log_thick[i]), 1.+exp(fast_p_log_n1[i]));
#endif
   }

#ifdef WITH_THICKX_DIRECT
# ifdef WITH_THICKX_DIRECT_CSPLINE
   cs_alt_thick = set_1d_cubic_params (fast_p_alt, fast_p_thick, MAX_FAST_PROFILE-1, 0); /* Ignore last point */
   cs_alt_rho   = set_1d_cubic_params (fast_p_alt, fast_p_rho, MAX_FAST_PROFILE, 0);
   cs_alt_n1    = set_1d_cubic_params (fast_p_alt, fast_p_n1, MAX_FAST_PROFILE, 0);
# endif
#endif

   /* Since we interpolate in log(thickness) and not in thickness directly but the
      thickness at the top of the atmosphere is zero (thus no log value), we need to
      set an extrapolation value, based on the thickness given at the second last height
      and the scale height beyond that, to come up with a log value close enough to the top. */
   top_log_thickness = p_log_thick[num_prof-2] - log((h1-h2)/hscale) - 5.;
   fast_log_thick_fac = (double)(MAX_FAST_PROFILE-1) / (bottom_log_thickness - top_log_thickness) ;

   double fast_p_alt_rev[MAX_FAST_PROFILE], fast_p_log_thick_rev[MAX_FAST_PROFILE];
   for ( i=0; i<MAX_FAST_PROFILE; i++)
   {
      fast_p_alt_rev[MAX_FAST_PROFILE-1-i] = fast_p_alt[i];
      fast_p_log_thick_rev[MAX_FAST_PROFILE-1-i] = fast_p_log_thick[i];
   }

   /* Note: this temporary cspline is not at equidistant log thickness intervals. */
   CsplinePar *fcs_log_thick_alt = set_1d_cubic_params (fast_p_log_thick_rev+1, fast_p_alt_rev+1, MAX_FAST_PROFILE-1, 0); /* Ignore first point in reverse */

   /* Add initialization of fast_p_heigh table of heigh in equidistant steps of log(thickness) */
   
   if ( fast_p_eq_log_thick == (double *) NULL )
      fast_p_eq_log_thick = (double *) calloc(MAX_FAST_PROFILE,sizeof(double));
   if ( fast_p_heigh_rev == (double *) NULL )
      fast_p_heigh_rev = (double *) calloc(MAX_FAST_PROFILE,sizeof(double));

   for ( i=0; i<MAX_FAST_PROFILE; i++)
   {
      double logt;

      if ( i<MAX_FAST_PROFILE-1 )
         logt = fast_p_eq_log_thick[i] = (double) i / fast_log_thick_fac + top_log_thickness;
      else /* avoid rounding errors */
         logt = fast_p_eq_log_thick[i] = bottom_log_thickness;

      /* The very first entry must return the top of the atmosphere! */
      if ( i == 0 )
         fast_p_heigh_rev[i] = top_of_atmosphere;
      /* First check if we are in the last tabulated layer below the top of the atmosphere as listed */
      else if ( num_prof >= 2 && exp(logt) < p_thick[num_prof-2] )
      {
         if ( rho1 > 0. )
         {
            fast_p_heigh_rev[i] = -hscale * log(exp(logt)/(hscale*rho0*cfac) + exp(-h1/hscale));
         }
         else
         {
            /* Last resort: assume linear thickness */
            fast_p_heigh_rev[i] = h2 + (h1-h2)*exp(logt)/p_thick[num_prof-2];
         }
      }
      else
      {
         /* Because of the anomaly of the thickness for the highest level, now in */
         /* reverse order the first point, we use cspline lookup ignoring the first point. */
         /* Filling the reverse table from the finely sampled forward table results in a more accurate round-trip */
         /* Cubic spline from dense sampling (note: not equidistant) gives best height reversal */
         fast_p_heigh_rev[i] = rpol_cspline(fast_p_log_thick_rev+1, fast_p_alt_rev+1, fcs_log_thick_alt, MAX_FAST_PROFILE-1, logt, 0, 0);
      }
#ifdef MORE_ATMO_TESTS
      printf("@b  %d   %g %g\n", i, fast_p_eq_log_thick[i], fast_p_heigh_rev[i]);
#endif
   }
   free (fcs_log_thick_alt);
}

/* ------------------------ init_common_atmosphere ----------------------- */
/**
 *  @short Second-stage part of atmospheric profile initialization is
 *         common to CORSIKA default profile and tabulated profiles.
 */

static void init_common_atmosphere(void);

static void init_common_atmosphere()
{
   double ts;
   int il;

   if ( num_prof < 5 )
   {
      fprintf(stderr,
         "There are definitely too few atmospheric levels in this file.\n");
      fprintf(stderr,
         "Normally this kind of file should have 50 or more levels.\n");
      exit(1);
   }

   bottom_of_atmosphere = p_alt[0];
   top_of_atmosphere    = p_alt[num_prof-1];

   /* Check consistency of density and thickness columns */
   ts = p_thick[num_prof-1];
   for (il=num_prof-1; il>0; il--)
   {
      double hs = 0., rho0 = 0.;
      if ( p_alt[il] <= p_alt[il-1] || p_rho[il] <= 0. ||
           p_rho[il-1] <= 0. || p_rho[il] > p_rho[il-1] ||
           p_thick[il] >= p_thick[il-1] )
      {
         fprintf(stderr,"Invalid atmospheric density profile between rows %d and %d.\n",
            il-1, il);
         fprintf(stderr,"   Row %d: h=%g km, rho=%g g/cm^3, thickness=%g g/cm^2\n",
            il-1, p_alt[il-1]*1e-5, p_rho[il-1], p_thick[il-1]);
         fprintf(stderr,"   Row %d: h=%g km, rho=%g g/cm^3, thickness=%g g/cm^2\n",
            il, p_alt[il]*1e-5, p_rho[il], p_thick[il]);
         exit(1);
      }
      hs = (p_alt[il]-p_alt[il-1])/(p_log_rho[il-1]-p_log_rho[il]);
      rho0 = p_rho[il] / exp(-p_alt[il]/hs);
      ts += hs*rho0*(exp(-p_alt[il-1]/hs)-exp(-p_alt[il]/hs));
   }
   if ( fabs(log(ts/p_thick[0])) > 0.5 )
   {
      fprintf(stderr,"Density and thickness columns in atmospheric profile are highly inconsistent:\n"
         "Thickness at altitude %g km given as %5.3f g/cm^2 but integrated as %5.3f g/cm^2.\n",
         p_alt[0]*1e-5, p_thick[0], ts);
      exit(1);
   }
   else if ( fabs(log(ts/p_thick[0])) > 0.05 )
   {
      fprintf(stderr,"Density and thickness columns in atmospheric profile are not fully consistent:\n"
         "Thickness at altitude %g km given as %5.3f g/cm^2 but integrated as %5.3f g/cm^2.\n",
         p_alt[0]*1e-5, p_thick[0], ts);
      fprintf(stderr,"Continuing with problematic atmospheric profile.\n");
   }

   /* Fill reversed-order vectors needed for interpolation*/
   for ( il=0; il<num_prof; il++ )
   {
      p_alt_rev[il] = p_alt[num_prof-1-il];
      p_rho_rev[il] = p_rho[num_prof-1-il];
      p_log_thick_rev[il] = p_log_thick[num_prof-1-il];
   }

   bottom_log_thickness = p_log_thick[0]; 

   top_layer_2nd_altitude = p_alt[num_prof-2];
   top_layer_rho0 = 0.;
   /* Within the last tabulated layer we are going to use a direct approach instead of
      the interpolation that gets used elsewhere, no matter what interpolation scheme.
      This takes the zero thickness at the top directly into account.
      Fortunately, this interval gets rarely used since not much happens there. */
   if ( p_rho[num_prof-1] > 0. ) /* Exponential profile model for the last layer is possible */
   {
      double h2   = p_alt[num_prof-2], h1   = p_alt[num_prof-1]; /* Second last and last height */
      double rho2 = p_rho[num_prof-2], rho1 = p_rho[num_prof-1]; /* Corresponding density */
      /* We assume zero thickness at the top, no matter what the table says, but we cannot have its log value. */
      /* Therefore we integrate an assumed exponential density rho(h)=rho0*exp(-h/hscale). */
      double hscale = (h1-h2) / log(rho2/rho1);
      double rho0   = rho2 / exp(-h2/hscale);
      /* Our integral may not match the thickness at the second last level well; need correction factor. */
      double t2 = hscale * rho0 * (exp(-h2/hscale) - exp(-h1/hscale));
      double cfac = p_thick[num_prof-2] / t2;
      top_layer_hscale = hscale;
      top_layer_rho0 = rho0;
      top_layer_cfac = cfac;
      /* Short-cuts for more efficient use later-on */
      top_layer_hscale_rho0_cfac = rho0 * cfac * hscale;
      top_layer_hscale_rho0_cfac_inv = 1./top_layer_hscale_rho0_cfac;
      top_layer_exp_top = exp(-top_of_atmosphere/hscale);
   }

   /* Set up cubic spline interpolation parameter before setting up fast interpolation. */
   /* Because of the required zero thickness at the top of the atmosphere, */
   /* setting up cubic splines (forward as well as backward) should exclude the top level. */
   /* The density and index of refraction columns do not suffer from this problem. */
   /* These parameters are allocated once and never free()ed; thus might get reported as memory leaks. */
   cs_alt_log_rho   = set_1d_cubic_params (p_alt,             p_log_rho,   num_prof,   0);
   cs_alt_log_n1    = set_1d_cubic_params (p_alt,             p_log_n1,    num_prof,   0);
   cs_alt_log_thick = set_1d_cubic_params (p_alt,             p_log_thick, num_prof-1, 0); /* Ignore last point */
   cs_log_thick_alt = set_1d_cubic_params (p_log_thick_rev+1, p_alt_rev+1, num_prof-1, 0); /* Ignore first point in reverse */

   /* Initialize faster tables for most frequent lookups, to be accessed without binary search. */
   init_fast_interpolation();

   /* Initialize the tables for the refraction bending, after cubic splines and fast interpolation, if any. */
   init_refraction_tables();

   atexit(free_atmo_csplines);
}

/* ------------------- init_corsika_atmosphere -------------------- */
/**
 *  @short Take the atmospheric profile from CORSIKA built-in functions.
 *
 *  For use of the refraction bending corrections together with the
 *  CORSIKA built-in atmospheres, the atmosphere tables are constructed
 *  from the CORSIKA RHOF and THICK functions.
 *  Note that the refraction index in this case is without taking the
 *  effect of wator vapour into account.
*/

static void init_corsika_atmosphere()
{
   static double alt[50] = 
                    {   0.,  1.,  2.,  3.,  4.,  5.,  6.,  7.,  8.,  9., 
                       10., 11., 12., 13., 14., 15., 16., 17., 18., 19., 
                       20., 21., 22., 23., 24., 25., 27., 30., 32., 35., 
                       37., 40., 42., 45., 47., 50., 55., 60., 65., 70., 
                       75., 80., 85., 90., 95.,100.,105.,110.,112.,112.83  };
   int ialt;
   double rho, thick, n_1;
   
   atmosphere = 0;
   
   thick = 0.;
   top_of_atmosphere = heigh_(&thick);
   
   num_prof = 0;
   for (ialt=0; ialt<50 && ialt<MAX_PROFILE; ialt++)
   {
      if ( alt[ialt] > top_of_atmosphere )
      {
         if ( ialt > 0 && ialt+1 < 50 && ialt+1 < MAX_PROFILE )
            alt[ialt] = 0.5*(alt[ialt-1]+top_of_atmosphere);
         else
            alt[ialt] = top_of_atmosphere;
      }
      p_alt[num_prof] = alt[ialt]*1e5;
      /* Get density from CORSIKA */
      rho = rhof_(&p_alt[num_prof]);
      if ( rho <= 0. )
         rho = 1e-20;
      p_log_rho[num_prof] = log(rho);
      p_rho[num_prof] = rho;
      /* Get atmospheric thickness from CORSIKA */
      thick = thick_(&p_alt[num_prof]);
      p_log_thick[num_prof] = (thick>0.)?log(thick):-1000.;
      p_rho[num_prof] = rho;
      p_thick[num_prof] = thick;
      /* Index of refraction simply proportional to density, assuming */
      /* n=1.000283 for CORSIKA default atmosphere at sea level */
      /* (which is about 0.5% away from the real value of n-1). */
      n_1 = rho * 0.000283 * 994186.38 / 1222.656;
      p_log_n1[num_prof] = (n_1>0.)?log(n_1):-1000.;
      num_prof++;
      if ( thick <= 0. )
         break;
   }
   
   init_common_atmosphere();
}

/* ----------------------- init_atmosphere ------------------------ */
/**
 *  @short Initialize atmospheric profiles.
 *
 *  Internal function for initialising both external and CORSIKA
 *  built-in atmospheric profiles. If any CORSIKA built-in profile
 *  should be used, it simply calls init_corsika_atmosphere().
 *
 *  Otherwise, atmospheric models are read in from text-format tables.
 *  The supplied models 1-6 are based on output of the MODTRAN program.
 *  For the interpolation of relevant parameters (density, thickness,
 *  index of refraction, ...) all parameters are transformed such
 *  that linear interpolation can be easily used.
 *
*/

static void init_atmosphere ()
{
   char fname[128];
   FILE *f;
   size_t count;
   int fmt = 0;
   double alt,rho,thick,n_1;
   size_t cols_s[4] = { 1, 2, 3, 4 }; /* First four columns used in short format */
   size_t cols_l[4] = { 1, 5, 6, 9 }; /* Jump over unused columns in long format */
   double **coldata = NULL;
   int i;

   /* CORSIKA built-in atmospheres have atmosphere numbers <= 0 */
   if ( atmosphere <=0 )
   {
      init_corsika_atmosphere();
      return;
   }

   if ( atmprof_name == NULL ) /* Atmosphere profile defined by number */
   {
      /* There are two different versions of data files. */
#ifndef LONG_ATMPROF
      sprintf(fname,"atmprof%d.dat",atmosphere);
      fmt = 1;
#else
      sprintf(fname,"atm_profile_model_%d.dat",atmosphere);
      fmt = 2;
#endif
      if ( (f=fileopen(fname,"r")) == NULL )
      {
         perror(fname);
#ifdef LONG_ATMPROF /* Try the other variant before giving up. */
         sprintf(fname,"atmprof%d.dat",atmosphere);
         fmt = 1;
#else
         sprintf(fname,"atm_profile_model_%d.dat",atmosphere);
         fmt = 2;
#endif
         fprintf(stderr,"Trying file %s instead.\n", fname);
         if ( (f=fileopen(fname,"r")) == NULL )
         {
            fflush(NULL);
            perror(fname);
            exit(1);
         }
      }
      atmprof_name = strdup(fname);
   }
   else /* Atmosphere profile defined by name */
   {
      if ( (f=fileopen(atmprof_name,"r")) == NULL )
      {
         fflush(NULL);
         perror(fname);
         exit(1);
      }
      if ( strstr(atmprof_name,"atm_profile_model_") != NULL )
         fmt = 2;
      else
         fmt = 1;
      strncpy(fname,atmprof_name,sizeof(fname)-1);
   }

   count = 0;
   num_prof = 0;

   if ( read_table_v(fname,f,&count,4,&coldata,(fmt==1)?cols_s:cols_l) != 0 )
   {
      fflush(stdout);
      fprintf(stderr,"Read atmospheric profile from file '%s' with read_table_v() failed.\n", fname);
      exit(1);
   }
   if ( count > (size_t) MAX_PROFILE )
   {
      fflush(stdout);
      fprintf(stderr,"Atmospheric profile has %ju levels but can handle only %d.\n", count, MAX_PROFILE);
      exit(1);
   }
   num_prof = (int) count;
   for ( i=0; i<num_prof; i++ )
   {
      alt = coldata[0][i];
      rho = coldata[1][i];
      thick = coldata[2][i];
      n_1 = coldata[3][i];
      p_alt[i] = alt*1e5; /* Altitude in file was in km */
      p_rho[i] = rho;
      p_thick[i] = thick;
      p_log_rho[i] = (rho>0.)?log(rho):-1000.;
      p_log_thick[i] = (thick>0.)?log(thick):-1000.;
      p_log_n1[i] = (n_1>0.)?log(n_1):-1000.;
   }
   free(coldata[0]);
   free(coldata[1]);
   free(coldata[2]);
   free(coldata[3]);
   free(coldata);

   fclose(f);
   fflush(stdout);

   printf("\nAtmospheric profile %d with %d levels read from file %s\n\n",
      atmosphere,num_prof,fname);

   init_common_atmosphere();
}

/* -------------------------- atmset_ ---------------------------- */
/**
 *  @short Set number of atmospheric model profile to be used.
 *
 *  The atmospheric model is initialized first before the
 *  interpolating functions can be used. For efficiency reasons,
 *  the functions rhofx_(), thickx_(), ... don't check if the
 *  initialisation was done.
 *
 *  This function is called if the 'ATMOSPHERE' keyword is
 *  present in the CORSIKA input file.
 *
 *  The function may be called from CORSIKA to initialize
 *  the atmospheric model via 'CALL ATMSET(IATMO,OBSLEV)' or such.
 *
 *  @param iatmo   (pointer to) atmospheric profile number;
 *   	           negative for CORSIKA built-in profiles.
 *  @param obslev  (pointer to) altitude of observation level [cm]
 *
 *  @return (none)
*/

void atmset_ (int *iatmo, double *obslev)
{
   atmosphere = *iatmo;
   if ( atmprof_name != NULL && atmosphere != 99 )
   {
      fflush(NULL);
      fprintf(stderr,"Cannot set atmospheric profile by both name and number. Name is reset.\n");
      atmprof_name = NULL;
   }
   else if ( atmprof_name != NULL && atmosphere == 99 )
   {
      fprintf(stdout,"Atmospheric profile 99 to be read from file '%s'.\n", atmprof_name);
   }
   observation_level = *obslev;

   if ( *iatmo > 0 )
      init_atmosphere();
   else
      init_corsika_atmosphere();

   obs_level_refidx = refidx_(obslev);
   obs_level_thick = thickx_(obslev);
}

/* -------------------------- atmnam_ ---------------------------- */
/**
 *  @short Instead of setting the atmospheric profile by number, it gets
 *     set by name, also indicated by setting profile number to 99.
 *     It does not actually initialize the atmosphere - this still should
 *     be done with atmset, using profile number 99 for that purpose.
 *     You need to call atmnam_ before atmset to make use of this feature.
 */

void atmnam_ (const char *aname, double *obslev)
{
   if ( atmprof_name != NULL )
      free(atmprof_name);
   atmprof_name = strdup(aname); /* Need copy here since value passed may change. */
   if ( atmosphere > 0 && atmosphere != 99 )
   {
      fflush(NULL);
      fprintf(stderr,"Cannot set atmospheric profile by both name and number. Using name '%s'.\n", aname);
      atmosphere = 99;
   }

   if ( obslev != NULL && *obslev >= 0. )
   {
      /* With observation level given, do the initialization immediately. */
      /* This method is not used with CORSIKA. */
      observation_level = *obslev;
      atmosphere = 99;

      init_atmosphere();

      obs_level_refidx = refidx_(&observation_level);
      obs_level_thick = thickx_(&observation_level);
   }
   else
   {
      /* Without, wait for later atmset_(99,obslev) call to initialize.
         This would, in CORSIKA inputs, normally correspond to:
           IACT ATMOFILE youratmfile.dat
           ATMOSPHERE 99 T
         while the reverse order would try to open atmprof99.dat.
      */
      fprintf(stdout,"File '%s' registered for atmospheric profile 99.\n", atmprof_name);
   }
}


/* ---------------------------- rhofx_ ----------------------------- */
/**
 *
 *  @short Density of the atmosphere as a function of altitude.
 *  This function can be called from Fortran code as RHOFX(HEIGHT).
 *
 *  @param  height (pointer to) altitude [cm]
 *
 *  @return density [g/cm**3]
*/

double rhofx_ (double *height)
{
   double h = (*height);

   if ( h <= bottom_of_atmosphere )
      return p_rho[0];
   else if ( h > top_of_atmosphere )
      return 0.;

#ifdef WITH_THICKX_DIRECT_CSPLINE

   return rpol_cspline(fast_p_alt, fast_p_rho, cs_alt_rho, MAX_FAST_PROFILE, h, 1, 0); /* Equidistant support points */

#else

   int i;
   double r;
   i = (int) ( fast_h_fac * (h-bottom_of_atmosphere) );
   if ( i >= MAX_FAST_PROFILE-1 )
      return 0.;
   r = fast_h_fac * (h-fast_p_alt[i]);
# ifdef WITH_THICKX_DIRECT
   return r*(fast_p_rho[i+1]-fast_p_rho[i]) + fast_p_rho[i];
# else
   return exp(r*(fast_p_log_rho[i+1]-fast_p_log_rho[i]) + fast_p_log_rho[i]);
# endif

#endif
}

/* ---------------------------- thickx_ ----------------------------- */
/**
 *
 *  @short Atmospheric thickness [g/cm**2] as a function of altitude.
 *  This function can be called from Fortran code as THICKX(HEIGHT).
 *
 *  @param  height (pointer to) altitude [cm]
 *
 *  @return thickness [g/cm**2]
 *
*/

double thickx_ (double *height)
{
   double h = (*height);

   if ( h <= bottom_of_atmosphere )
      return p_thick[0];
   else if ( h >= top_of_atmosphere )
      return 0.;

   /* Always special-case lookups in the last tabulated layer, no matter what interpolation scheme */
   if ( /* num_prof >= 2 && */ h > p_alt[num_prof-2] )
   {
      /* For the top layer (between second highest and highest levels as tabulated)
         we don't rely on the interpolation scheme otherwise used but use a direct approach.
         Fortunately, this interval gets rarely used since not much happens there. */
      if ( top_layer_rho0 > 0. )
         return top_layer_hscale_rho0_cfac * (exp(-h/top_layer_hscale) - top_layer_exp_top);
      else
      {
         /* Last resort: assume linear density profile between last two levels */
         double r = (h-top_layer_2nd_altitude)/(top_of_atmosphere-top_layer_2nd_altitude);
         return p_thick[num_prof-2] * (r*r);
      }
   }

#ifdef WITH_THICKX_DIRECT_CSPLINE

   return rpol_cspline(fast_p_alt, fast_p_thick, cs_alt_thick, MAX_FAST_PROFILE-1, h, 1, 0); /* Equidistant support points */

#else

   int i;
   double r;
   i = (int) ( fast_h_fac * (h-bottom_of_atmosphere) );
   if ( i >= MAX_FAST_PROFILE-1 )
      return 0.;
   else if ( i < 0 )
      return p_thick[0];
   r = fast_h_fac * (h-fast_p_alt[i]);

# ifdef WITH_THICKX_DIRECT
   return r*(fast_p_thick[i+1]-fast_p_thick[i]) + fast_p_thick[i];
# else
   return exp(r*(fast_p_log_thick[i+1]-fast_p_log_thick[i]) + fast_p_log_thick[i]);
# endif
#endif
}

/* ---------------------------- refidx_ ----------------------------- */
/**
 *
 *  @short Index of refraction as a function of altitude [cm].
 *  This function can be called from Fortran code as REFIDX(HEIGHT).
 *
 *  @param height (pointer to) altitude [cm]
 *
 *  @return index of refraction
 *
*/

double refidx_ (double *height)
{
   double h = (*height);

   if ( h <= bottom_of_atmosphere )
      return 1.+exp(p_log_n1[0]);
   else if ( h >= top_of_atmosphere )
      return 1.;

#ifdef WITH_THICKX_DIRECT_CSPLINE

   return 1. + rpol_cspline(fast_p_alt, fast_p_n1, cs_alt_n1, MAX_FAST_PROFILE, h, 1, 0); /* Equidistant support points */

#else

   int i;
   double r;
   i = (int) ( fast_h_fac * ((*height)-bottom_of_atmosphere) );
   if ( i >= MAX_FAST_PROFILE-1 )
      return 1.;
   r = fast_h_fac * ((*height)-fast_p_alt[i]);
# ifdef WITH_THICKX_DIRECT
   return 1. + r*(fast_p_n1[i+1]-fast_p_n1[i]) + fast_p_n1[i];
# else
   // return 1.+exp((1.-r)*fast_p_log_n1[i] + r*fast_p_log_n1[i+1]);
   return 1. + exp(r*(fast_p_log_n1[i+1]-fast_p_log_n1[i]) + fast_p_log_n1[i]);
# endif
#endif
}

/* ---------------------------- heighx_ ----------------------------- */
/**
 *
 *  @short Altitude [cm] as a function of atmospheric thickness [g/cm**2].
 *  This function can be called from Fortran code as HEIGHX(THICK).
 *
 *  @param   thick  (pointer to) atmospheric thickness [g/cm**2]
 *
 *  @return   altitude [cm]
*/

double heighx_ (double *thick)
{
   double h, logt;
   if ( (*thick) <= 0. )
      return top_of_atmosphere;

   /* Always special-case lookups in the last tabulated layer, no matter what interpolation scheme */
   if ( /* num_prof >= 2 && */ (*thick) < p_thick[num_prof-2] )
   {
      /* For the top layer (between second highest and highest levels as tabulated)
         we don't rely on the interpolation scheme otherwise used but use a direct approach.
         Fortunately, this interval gets rarely used since not much happens there. */
      if ( top_layer_rho0 > 0. )
         h = -top_layer_hscale * log( (*thick)*top_layer_hscale_rho0_cfac_inv + top_layer_exp_top );
      else
      {
         /* Last resort: assume linear density profile between last two levels */
         double r2 = (*thick)/p_thick[num_prof-2];
         h = top_layer_2nd_altitude + (top_of_atmosphere-top_layer_2nd_altitude)*sqrt(r2);
      }

      if ( h < top_of_atmosphere )
         return h;
      else
         return top_of_atmosphere;
   }

   logt = log(*thick);
   if ( logt > bottom_log_thickness )
     return bottom_of_atmosphere;

   int i;
   double r;
   i = (int) ( fast_log_thick_fac * (logt - top_log_thickness) );
   if ( i >= MAX_FAST_PROFILE-1 )
   {
# ifdef MORE_ATMO_TESTS
      if ( i > MAX_FAST_PROFILE-1 )
      {
         fflush(0);
         fprintf(stderr,"Problem in heighx_():\n");
         fprintf(stderr,"   fast_log_thick_fac = %g\n", fast_log_thick_fac);
         fprintf(stderr,"   thick = %g, logt = %g\n", *thick, logt);
         fprintf(stderr,"   bottom_log_thickness = %g\n", bottom_log_thickness);
         fprintf(stderr,"   i = (int) ( fast_log_thick_fac * (logt-bottom_log_thickness) ) = %d\n", i);
         fprintf(stderr,"   Below bottom of atmosphere?\n");
      }
# endif
      return bottom_of_atmosphere;
   }
   else if ( i < 0 )
   {
# ifdef MORE_ATMO_TESTS
      fflush(0);
      fprintf(stderr,"Problem in heighx_():\n");
      fprintf(stderr,"   fast_log_thick_fac = %g\n", fast_log_thick_fac);
      fprintf(stderr,"   thick = %g, logt = %g\n", *thick, logt);
      fprintf(stderr,"   bottom_log_thickness = %g\n", bottom_log_thickness);
      fprintf(stderr,"   i = (int) ( fast_log_thick_fac * (logt-bottom_log_thickness) ) = %d\n", i);
      fprintf(stderr,"   Very close to top of atmosphere?\n");
# endif
      return top_of_atmosphere;
   }
   r = fast_log_thick_fac * (logt-fast_p_eq_log_thick[i]);
   // h = (1.-r)*fast_p_heigh_rev[i] + r*fast_p_heigh_rev[i+1];
   h = r*(fast_p_heigh_rev[i+1]-fast_p_heigh_rev[i]) + fast_p_heigh_rev[i];

   if ( h < top_of_atmosphere )
      return h;
   else
      return top_of_atmosphere;
}

/* ---------------------------- raybnd_ ---------------------------- */
/**
 *  @short Calculate the bending of light due to atmospheric refraction.
 *
 *  Path of light through the atmosphere including the bending by refraction.
 *  This function assumes a plane-parallel atmosphere.
 *  Coefficients for corrections from straight-line propagation to
 *  refraction-bent path are numerically evaluated when the atmospheric 
 *  model is defined.
 *  Note that while the former mix of double/float data types may appear odd,
 *  it was determined by the variables present in older CORSIKA to save
 *  conversions. With CORSIKA 6.0 all parameters are of double type.
 *
 *  This function may be called from FORTRAN as
 *    CALL RAYBND(ZEM,U,V,W,DX,DY,DT)
 *
 *  @param zem    Altitude of emission above sea level [cm]
 *  @param u      Initial/Final direction cosine along X axis (updated)
 *  @param v      Initial/Final direction cosine along Y axis (updated)
 *  @param w      Initial/Final direction cosine along Z axis, positive is downwards (updated)
 *  @param dx     Position in CORSIKA detection plane [cm] (updated)
 *  @param dy     Position in CORSIKA detection plane [cm] (updated)
 *  @param dt     Time of photon [ns]. Input: emission time.
 *                Output: time of arrival in CORSIKA detection plane.
*/

void raybnd_(double *zem, cors_dbl_t *u, cors_dbl_t *v, 
   double *w, cors_dbl_t *dx, cors_dbl_t *dy, cors_dbl_t *dt)
{
   double sin_t_em, sin_t_obs, theta_em, theta_obs;
   double c, s, h, t, t0;
   double rho = rhofx_(zem);
   double hori_off, travel_time;
   double vc = 29.9792458; /* Vacuum speed of light [cm/ns] */
   double vci = 1./vc; /* Inverse of vacuum speed of light */
   double airmass = ((*w) != 0.) ? fabs(1./(*w)) : 99999.;
   double dz = fabs((*zem) - observation_level);
   double de = etadsn*fabs(obs_level_thick-thickx_(zem));

   int ialt = (int) ( fast_h_fac * ((*zem)-bottom_of_atmosphere) );
   int irho = (int) ( fast_rho_fac * rho );
   if ( ialt < 0 )
      ialt = 0;
   else if ( ialt >= MAX_FAST_PROFILE )
      ialt = MAX_FAST_PROFILE-1;
   if ( irho < 0 )
      irho = 0;
   else if ( irho >= MAX_FAST_PROFILE )
      irho = MAX_FAST_PROFILE-1;
   double ralt = fast_h_fac * ((*zem)-fast_p_alt[ialt]);
   double rrho = fast_rho_fac * (rho-fast_p_rho_rev[irho]);
#ifdef TEST_RAYBND
   printf(" raybnd (fast): zem=%5.3f [km], ialt=%d, ralt=%7.5f, step=%g -> alt=%5.3f [km]\n", 
      (*zem)*1e-5, ialt, ralt, 1./fast_h_fac, (bottom_of_atmosphere+ialt/fast_h_fac)*1e-5);
   printf(" raybnd (fast): rho=%g [g/cm^3], irho=%d, rrho=%7.5f, step=%g -> rho=%g\n", 
      rho, irho, rrho, 1./fast_rho_fac, irho/fast_rho_fac);
#endif

#ifdef TEST_RAYBND
   printf(" raybnd: emission altitude = %3.2f cm, observation level = %3.1f cm\n",
      *zem, observation_level);
   printf(" raybnd (start): u=%f, v=%f, w=%f, dx=%f, dy=%f, dt=%f\n", *u, *v, *w, *dx, *dy, *dt);
#endif

   /* (Sine of) emission zenith angle */
   sin_t_em = sqrt((*u)*(*u)+(*v)*(*v));
   if ( sin_t_em <= 0. )
   {   /* Exactly vertical: no bending; just calulate travel time. */
#ifdef TEST_RAYBND
      c = 1.;
      s = 0.;
      t = rpol(p_rho,p_bend_ray_time_a,num_prof,rho);
      printf(" raybnd (vertical): time = %5.3f + %5.3f +%5.3f + %5.3f\n",
         *dt,(dz + de) * airmass * vci,
      rpol(p_alt,p_bend_ray_time0,num_prof,*zem),
         -(t*t) * (s*s)/(c*c*c));
#endif
      /* Very unlikely case, no need for optimization */
      *dt += (dz + de) * airmass * vci +
         rpol(p_alt,p_bend_ray_time0,num_prof,*zem);
      return;
   }
   /* Rounding errors with nearly horizontal light have to checked */
   if ( sin_t_em > 1. )
   {
#ifdef TEST_RAYBND
      printf(" raybnd: no correction for upward light\n");
#endif
      return;
   }
#ifdef TEST_RAYBND
   if ( (*w) <= 0. )
      printf(" raybnd: upward light ??\n");
#endif

   /* Zenith angle at emission */
   theta_em = asin(sin_t_em);

   /* (Sine of) observed zenith angle */
   sin_t_obs = sin_t_em*refidx_(zem) / obs_level_refidx;

   /* For downward rays there should be no need for a further 
      rounding error check but with upward rays we could have
      an effective total internal reflection in the atmosphere -
      which we will not treat but forget the ray. */
   if ( sin_t_obs > 1. )
   {
#ifdef TEST_RAYBND
      printf(" raybnd: sine of zenith angle out of range\n");
#endif
      return;
   }

   /* Zenith angle at observation level */
   theta_obs = asin(sin_t_obs);

#ifdef TEST_RAYBND
   fflush(NULL);
   printf(" raybnd: theta = %5.3f, %5.3f\n",(double)(theta_em*180./M_PI),
      (double)(theta_obs*180./M_PI));
#endif

   /* Calculate horizontal displacement with respect to straight line */
   /* and total light travel time from emission to observation level. */

   c = cos(theta_em+0.28*(theta_obs-theta_em));
   s = sin(theta_em+0.28*(theta_obs-theta_em));

   h  = rrho*(fast_p_bend_ray_hori_a[irho+1]-fast_p_bend_ray_hori_a[irho]) + fast_p_bend_ray_hori_a[irho];
   t  = rrho*(fast_p_bend_ray_time_a[irho+1]-fast_p_bend_ray_time_a[irho]) + fast_p_bend_ray_time_a[irho];
   t0 = ralt*(fast_p_bend_ray_time0[ialt+1]-fast_p_bend_ray_time0[ialt]) + fast_p_bend_ray_time0[ialt];

   hori_off = -(h*h) * s/(c*c*c);
#ifdef TEST_RAYBND
   printf(" raybnd: horizontal displacement = %5.2f\n",hori_off);
   printf(" raybnd: time = %5.3f + %5.3f +%5.3f + %5.3f\n",
      *dt,(dz + de) * airmass * vci, t0, -(t*t) * (s*s)/(c*c*c));
#endif
   travel_time = t0 - (t*t) * (s*s)/(c*c*c);
   travel_time += (dz + de) * airmass * vci;

   /* Update arguments: */
   /* Emission direction replaced by observed direction. */
   *u *= sin_t_obs/sin_t_em;
   *v *= sin_t_obs/sin_t_em;
   if ( (*w) >= 0. ) /* Downward ray remains downward ray */
      *w = sqrt(1.-sin_t_obs*sin_t_obs);
   else
      *w = -sqrt(1.-sin_t_obs*sin_t_obs); /* Upward ray remainy upward */

   /* Position in observation level corrected for displacement. */
   *dx += hori_off * (*u)/sin_t_obs;
   *dy += hori_off * (*v)/sin_t_obs;

   /* Light travel time added to emission time. */
   *dt += travel_time;

#ifdef TEST_RAYBND
   printf(" raybnd (end): u=%f, v=%f, w=%f, dx=%f, dy=%f, dt=%f\n", *u, *v, *w, *dx, *dy, *dt);
#endif
}

/* ============================================================== */
/*
 *  Functions for fitting the tabulated density profile for CORSIKA EGS part.
*/

/* ------------------------ sum_log_dev_sq ------------------------- */
/**
 *  Measure of deviation of model layers from tables.
*/

static double sum_log_dev_sq(double a, double b, double c, int np,
   double *h, double *t, double * UNUSED(rho))
{
   int ip;
   double s = 0., al;
   for (ip=0; ip<np; ip++ )
   {
#if 0
      /* Fit minimizes relative deviations (better fits at high altitude) */
      if ( a+b*exp(-h[ip]/c) > 0. && t[ip] > 0. )
         al = log((a+b*exp(-h[ip]/c)) / t[ip]);
      else
         al = 0.;
      s += al*al;
#elif 1
      /* Compromise between relative and absolute deviations */
      if ( a+b*exp(-h[ip]/c) > 0. && t[ip] > 0. )
         al = log((a+b*exp(-h[ip]/c)) / t[ip]);
      else
         al = 0.;
      s += fabs(al)*fabs(a+b*exp(-h[ip]/c) - t[ip]);
#elif 0
      /* Fit minimizes absolute deviations (better fits at low altitude) */
      al = a+b*exp(-h[ip]/c) - t[ip];
      s += al*al;
#endif
   }
   return s;
}

/* ------------------------ atm_exp_fit ------------------------- */
/**
 *  Fit one atmosphere layer by an expontential density model.
*/

static double atm_exp_fit ( double h1, double h2, double *ap, 
   double *bp, double *cp, double *s0, int *npp )
{
   int ip, np, iter;
   double h[MAX_PROFILE], t[MAX_PROFILE], rho[MAX_PROFILE], t1, t2;
   double a = *ap, b = *bp, c = *cp;
   double s, dc;
   
   for (ip=np=0; ip<num_prof; ip++)
      if ( p_alt[ip] >= h1 && p_alt[ip] <= h2 && p_alt[ip] < 86e5 )
      {
         h[np] = p_alt[ip];
         t[np] = exp(p_log_thick[ip]);
         rho[np] = exp(p_log_rho[ip]);
         np++;
      }
   t1 = thickx_(&h1);
   t2 = thickx_(&h2);
   
   *s0 = sum_log_dev_sq(a,b,c,np,h,t,rho);
   *npp = np;
   if ( np <= 0 )
      return 0.;
   else if ( h1 == h2 || t1 == t2 )
      return sum_log_dev_sq(a,b,c,np,h,t,rho);
   else if ( np <= 2 || ( np == 3 && (h1==h[0] || h2==h[1])) )
   {
      *cp = c = *cp;
      *bp = b = (t2-t1) / (exp(-h2/c)-exp(-h1/c));
      *ap = a = t1 - b*exp(-h1/c);
      return sum_log_dev_sq(a,b,c,np,h,t,rho);
   }
   
   c = *cp;
   b = (t2-t1) / (exp(-h2/c)-exp(-h1/c));
   a = t1 - b*exp(-h1/c);
   s = sum_log_dev_sq(a,b,c,np,h,t,rho);
   for ( iter=0, dc=2000.e2; iter<30; iter++ )
   {
      double a1, a2, a3, an, b1, b2, b3, bn, c1, c2, c3, cn, s1, s2, s3, sn;
      c2 = c;
      c1 = c - dc;
      if ( c1 <= 0. )
         c1 = c / 2.;
      c3 = c + dc;
      
      b1 = (t2-t1) / (exp(-h2/c1)-exp(-h1/c1));
      a1 = t1 - b1*exp(-h1/c1);
      b2 = (t2-t1) / (exp(-h2/c2)-exp(-h1/c2));
      a2 = t1 - b2*exp(-h1/c2);
      b3 = (t2-t1) / (exp(-h2/c3)-exp(-h1/c3));
      a3 = t1 - b3*exp(-h1/c3);
      s1 = sum_log_dev_sq(a1,b1,c1,np,h,t,rho);
      s2 = sum_log_dev_sq(a2,b2,c2,np,h,t,rho);
      s3 = sum_log_dev_sq(a3,b3,c3,np,h,t,rho);
      /* This works only for a roughly parabolic minimum */
      cn = ((c1*c1-c2*c2)*(s3-s2)-(c3*c3-c2*c2)*(s1-s2)) /
          (2.*(c1-c2)*(s3-s2)-2.*(c3-c2)*(s1-s2));
      if ( cn <= 0. )
         cn = 0.5*c;
      bn = (t2-t1) / (exp(-h2/cn)-exp(-h1/cn));
      an = t1 - bn*exp(-h1/cn);
      sn = sum_log_dev_sq(an,bn,cn,np,h,t,rho);
      if ( sn > s )
         break;
      if ( sn < s*1.00001 )
      {
         a = an;
         b = bn;
         c = cn;
         s = sn;
         break;
      }
      if ( cn < 3000.e2 )
      {
         cn = 3000.e2;
         bn = (t2-t1) / (exp(-h2/cn)-exp(-h1/cn));
         an = t1 - bn*exp(-h1/cn);
         dc = 1000.e2;
      }
      else if ( cn > c + 1.5*dc )
      {
         cn = c + 1.5*dc;
         bn = (t2-t1) / (exp(-h2/cn)-exp(-h1/cn));
         an = t1 - bn*exp(-h1/cn);
         dc *= 2.;
      }
      else if ( cn < c -1.5*dc )
      {
         cn = c -1.5*dc;
         bn = (t2-t1) / (exp(-h2/cn)-exp(-h1/cn));
         an = t1 - bn*exp(-h1/cn);
         dc *= 2.;
      }
      else if ( fabs(c-cn) < 0.25*dc )
         dc = 2.*fabs(c-cn) + 0.2*dc;
      else
         dc = 1.5*fabs(c-cn);
      a = an;
      b = bn;
      c = cn;
      s = sn;
   }
   *cp = c;
   *bp = b;
   *ap = a;
   return s;
}

/** Corresponding to CORSIKA built-in function THICK; 
    only used to show fit results. */

static double fn_thick(double h, int nl, double *hl, 
   double *a, double *b, double *c)
{
   int i;
   if ( h > top_of_atmosphere || nl < 2 )
      return 0;
   for ( i=0; i<nl-1; i++)
      if ( h < hl[i+1] )
         return a[i] + b[i] * exp((-h)/c[i]);
   return a[i] - h/c[i];
}

/** Corresponding to CORSIKA built-in function RHOF; 
    only used to show fit results. */

static double fn_rhof(double h, int nl, double *hl, 
   double *UNUSED(a), double *b, double *c)
{
   int i;
   if ( h > top_of_atmosphere || nl < 2 )
      return 0;
   for ( i=0; i<nl-1; i++)
      if ( h < hl[i+1] )
         return b[i]/c[i] * exp((-h)/c[i]);
   return 1./c[i];
}

#if 0
/** Corresponding to CORSIKA built-in function HEIGHT. */

static double fn_height(double t, int nl, double *hl, 
   double *a, double *b, double *c)
{
   int i;
   if ( t < 0. )
      return top_of_atmosphere;
   for ( i=0; i<nl-1; i++)
      if ( t > fn_thick(hl[i+1],nl,hl,a,b,c) )
         return c[i] * log(b[i] / (t-a[i]));
   return (a[i]-t) * c[i];
}
#endif

/* ---------------------------- atmfit_ ------------------------------ */
/**
 *  @short Fit the tabulated density profile for CORSIKA EGS part.
 *
 *  Fitting of the tabulated atmospheric density profile by
 *  piecewise exponential parts as used in CORSIKA.
 *  The fits are constrained by fixing the atmospheric thicknesses
 *  at the boundaries to the values obtained from the table.
 *  Note that not every atmospheric profile can be fitted well
 *  by the CORSIKA piecewise models (4*exponential + 1*constant
 *  density). In particular, the tropical model is known to 
 *  be a problem. Setting the boundary heights manually might help.
 *  The user is advised to check at least once that the fitted
 *  layers represent the tabulated atmosphere sufficiently well,
 *  at least at the altitudes most critical for the observations
 *  (usually at observation level and near shower maximum but
 *  depending on the user's emphasis, this may vary).
 *
 *  Fit all layers (except the uppermost) by exponentials and (if *nlp > 0)
 *  try to improve fits by adjusting layer boundaries.
 *  The uppermost layer has constant density up to the 'edge' of the atmosphere.
 *  
 *  This function may be called from CORSIKA.
 * 
 *  Parameters (all pointers since function is called from Fortran):
 *  @param   nlp    Number of layers (or negative of that if boundaries set manually)
 *  @param   hlay   Vector of layer (lower) boundaries.
 *  @param   aatm,batm,catm    Parameters as used in CORSIKA.
*/

void atmfit_(int *nlp, double *hlay, double *aatm, double *batm, double *catm)
{
   int il, np, k;
   double *a, *b, *c, *h, *s, *s0;
   double atmp[2], btmp[2], ctmp[2], htmp[3];
   int nl = (*nlp<0) ? -*nlp : *nlp;     /* Actual number of layers */
   double factmx = (*nlp<0) ? 1.0 : 2.0; /* Max. scale for boundary adjustment */
   int show_fit;
#define NLAYX 10
   double hlayx[NLAYX][5] =
   {  { 0., 0., 0., 0., 0. },
      { 0., 3., 7., 15., 110. },
      { 0., 4., 10., 20., 110. },
      { 0., 6., 12., 25., 109. },
      { 0., 7., 15., 30., 108. },
      { 0., 8., 16., 32., 107. },
      { 0., 9., 18., 36., 106. },
      { 0., 10., 20., 40., 105. },
      { 0., 11., 22., 45., 104. },
      { 0., 12., 25., 50., 103. } 
   };
   double sx[NLAYX], sxbest = 0.;
   int ix, ixbest = 0;

   if ( nl < 2 || atmosphere == 0 )
      return;

#ifdef DEBUG_ATM_FIT
   printf("\nParameters of atmospheric layers as suggested by CORSIKA:\n");
   for ( il=0; il<nl; il++)
      printf("  Layer %d: %6.2f km < h < %6.2f km: a = %13.6g, b = %13.6g, c = %13.6g\n",
         il+1, hlay[il]/1e5,
         (il+1<(*nlp)) ? hlay[il+1]/1e5 : aatm[il]*catm[il]/1e5,
         aatm[il], batm[il], catm[il]);
   printf("\n");
#endif

   if ( (h  = (double *) calloc((size_t)(nl+1),sizeof(double))) == NULL ||
        (s  = (double *) calloc((size_t)(nl),sizeof(double))) == NULL ||
        (s0 = (double *) calloc((size_t)(nl),sizeof(double))) == NULL ||
        (a  = (double *) calloc((size_t)(nl),sizeof(double))) == NULL ||
        (b  = (double *) calloc((size_t)(nl),sizeof(double))) == NULL ||
        (c  = (double *) calloc((size_t)(nl),sizeof(double))) == NULL )
   {
      return;
   }

   /* The lowest layer boundary must not be below the lowest table entry */
   /* because values can only be interpolated, not extrapolated. */
   if ( hlay[0] < bottom_of_atmosphere )
      hlay[0] = bottom_of_atmosphere;
   /* The default layers are known to be a rather bad choice for */
   /* the tropical atmosphere. Replace them with better starting values. */
   if ( *nlp > 0 )
   {
      if ( atmosphere == 1 || (atmosphere >= 10 && atmosphere <40) )
      {
         hlay[1] = 9.25e5;
         hlay[2] = 19.0e5;
         hlay[3] = 37.5e5;
         hlay[4] = 105.0e5;
      }

      for ( il=1; il<5; il++ )
         hlayx[0][il] = hlay[il]/1e5;

      /* Search for a decent starting point in altitude levels */
      
      for ( ix=0; ix<NLAYX; ix++ )
      {
         for ( il=1; il<5; il++ )
            hlay[il] = hlayx[ix][il]*1e5;
         for ( il=0; il<nl; il++ )
         {
            a[il] = aatm[il];
            b[il] = batm[il];
            c[il] = catm[il];
            h[il] = hlay[il];
         }
         h[nl] = top_of_atmosphere;

         sx[ix] = 0.;
         for ( il=0; il<nl-1; il++ )
            sx[ix] += atm_exp_fit(h[il],h[il+1],&a[il],&b[il],&c[il],&s0[il],&np);
#ifdef DEBUG_ATM_FIT
         printf("\nStarting level set %d:\n",ix);
         for ( il=0; il<nl; il++)
            printf("  Layer %d: %6.2f km < h < %6.2f km: a = %13.6g, b = %13.6g, c = %13.6g, s = %10.4e -> %10.4e\n",
               il+1,h[il]/1e5,h[il+1]/1e5,a[il],b[il],c[il],s0[il],s[il]);
         printf("  Sum of residuals squared: %g\n", sx[ix]);
#endif
         if ( ix == 0 || sx[ix] < sxbest )
         {
            sxbest = sx[ix];
            ixbest = ix;
         }
      }
      for ( il=1; il<5; il++ )
         hlay[il] = hlayx[ixbest][il]*1e5;
   }

   for ( il=0; il<nl; il++ )
   {
      a[il] = aatm[il];
      b[il] = batm[il];
      c[il] = catm[il];
      h[il] = hlay[il];
   }
   // h[nl] = a[nl-1]*c[nl-1];
   h[nl] = top_of_atmosphere;

   fflush(NULL);

#ifdef DEBUG_ATM_FIT
   printf("\nParameters of atmospheric layers before the fit, after adjusting layers:\n");
   for ( il=0; il<nl; il++)
      printf("  Layer %d: %6.2f km < h < %6.2f km: a = %13.6g, b = %13.6g, c = %13.6g\n",
         il+1,h[il]/1e5,h[il+1]/1e5,a[il],b[il],c[il]);
   printf("\n");

   /* Functions and variables for cut-and-paste into gnuplot or C: */
   
   puts("thicka(h)=(h<h2a?a1a+b1a*exp(-h*1e5/c1a):(h<h3a?a2a+b2a*exp(-h*1e5/c2a):(h<h4a?a3a+b3a*exp(-h*1e5/c3a):(h<h5a?a4a+b4a*exp(-h*1e5/c4a):(h<h6a?a5a-h*1e5/c5a:0)))))");
   puts("rhoa(h)=(h<h2a?b1a/c1a*exp(-h*1e5/c1a):(h<h3a?b2a/c2a*exp(-h*1e5/c2a):(h<h4a?b3a/c3a*exp(-h*1e5/c3a):(h<h5a?b4a/c4a*exp(-h*1e5/c4a):(h<h6a?1./c5a:0)))))");
   for ( il=0; il<=nl;il++)
     printf("h%da=%6.2f;",il+1,h[il]/1.e5);
   printf("\n");
   for ( il=0; il<nl;il++)
     printf("a%da=%13.6g;",il+1,a[il]);
   printf("\n");
   for ( il=0; il<nl;il++)
     printf("b%da=%13.6g;",il+1,b[il]);
   printf("\n");
   for ( il=0; il<nl;il++)
     printf("c%da=%13.6g;",il+1,c[il]);
   printf("\n");
#endif

   for ( il=0; il<nl-1; il++ )
      s[il] = atm_exp_fit(h[il],h[il+1],&a[il],&b[il],&c[il],&s0[il],&np);

   c[nl-1] = 2./rhofx_(&h[nl-1]);
   a[nl-1] = thickx_(&h[nl-1]) + h[nl-1]/c[nl-1];
   b[nl-1] = 1.;
   h[nl] = a[nl-1]*c[nl-1];

   if ( factmx > 1.0 ) /* Try to improve by adjusting boundaries */
   {
#ifdef DEBUG_ATM_FIT
      printf("\nIntermediate results of atmosphere fit:\n");
      for ( il=0; il<nl; il++)
         printf("  Layer %d: %6.2f km < h < %6.2f km: a = %13.6g, b = %13.6g, c = %13.6g, s = %10.4e -> %10.4e\n",
            il+1,h[il]/1e5,h[il+1]/1e5,a[il],b[il],c[il],s0[il],s[il]);
      printf("\n");
      for ( il=0; il<=nl;il++)
        printf("h%db=%6.2f;",il+1,h[il]/1.e5);
      printf("\n");
      for ( il=0; il<nl;il++)
        printf("a%db=%13.6g;",il+1,a[il]);
      printf("\n");
      for ( il=0; il<nl;il++)
        printf("b%db=%13.6g;",il+1,b[il]);
      printf("\n");
      for ( il=0; il<nl;il++)
        printf("c%db=%13.6g;",il+1,c[il]);
      printf("\n");
#endif

      for (k=0; k<3; ++k)
      {
       for ( il=nl-2; il>=0; il-- )
       {
         double smin[2], stmp[2], s0tmp[2], hvar;
         int nptmp[2], npmin[2];
         atmp[0] = a[il]; atmp[1] = a[il+1];
         btmp[0] = b[il]; btmp[1] = b[il+1];
         ctmp[0] = c[il]; ctmp[1] = c[il+1];
         htmp[0] = h[il]; htmp[1] = h[il+1]; htmp[2] = h[il+2];
         smin[0] = atm_exp_fit(htmp[0],htmp[1],&atmp[0],&btmp[0],&ctmp[0],&s0tmp[0],&npmin[0]);
         if ( il < nl-2 )
            smin[1] = atm_exp_fit(htmp[1],htmp[2],&atmp[1],&btmp[1],&ctmp[1],&s0tmp[1],&npmin[1]);
         else
         {
            smin[1] = 0.;
            npmin[1] = 4;
         }
#ifdef DEBUG_ATM_FIT2
         printf("In layers %d/%d: smin=%f/%f, npmin=%d/%d\n",
            il, il+1, smin[0], smin[1], npmin[0], npmin[1]);
#endif
         if ( npmin[0] <= 3 || npmin[1] <= 3 )
            continue;

#ifdef DEBUG_ATM_FIT2
         printf("In layers %d/%d try all hvar from %f km to %f km with factmx=%f\n",
            il, il+1, (htmp[0]+3.e5)/1e5, (htmp[2]-3.e5)/1e5, factmx);
#endif
         for ( hvar=(il<nl-2?htmp[0]+3.e5:htmp[1]); hvar<=htmp[2]-3.e5; hvar+=0.25e5 )
         {
            if ( hvar < h[il+1]/factmx || hvar > h[il+1]*factmx || hvar > h[il+1]+10.e5 )
               continue;
            atmp[0] = a[il]; atmp[1] = a[il+1];
            btmp[0] = b[il]; btmp[1] = b[il+1];
            ctmp[0] = c[il]; ctmp[1] = c[il+1];
            stmp[0] = atm_exp_fit(htmp[0],hvar,&atmp[0],&btmp[0],&ctmp[0],&s0tmp[0],&nptmp[0]);
            if ( il < nl-2 )
               stmp[1] = atm_exp_fit(hvar,htmp[2],&atmp[1],&btmp[1],&ctmp[1],&s0tmp[1],&nptmp[1]);
            else
            {
               stmp[1] = 0.;
               nptmp[1] = 4;
            }
#ifdef DEBUG_ATM_FIT2
            printf("Try hvar=%f: stmp=%f/%f, nptmp=%d/%d\n", hvar/1e5, 
               stmp[0], stmp[1], nptmp[0], nptmp[1]);
            printf("    hmin=%f  smin=%f/%f, npmin=%d/%d\n", htmp[1]/2e5,            
               smin[0], smin[1], npmin[0], npmin[1]);
#endif
            if ( nptmp[0] >= 3 && nptmp[1] >= 3 &&
                 stmp[0]/(nptmp[0]-2.9)+stmp[1]/(nptmp[1]-2.5) <
                 smin[0]/(npmin[0]-2.9)+smin[1]/(npmin[1]-2.5) )
            {
#ifdef DEBUG_ATM_FIT2
               printf("Looks like we got an improvement\n");
#endif
               htmp[1] = hvar;
               smin[0] = stmp[0];
               smin[1] = stmp[1];
               npmin[0] = nptmp[0];
               npmin[1] = nptmp[1];
            }
         }
         h[il+1] = htmp[1];
       }
      }

      sxbest=0.;
      for ( il=0; il<nl-1; il++ )
      {
         s[il] = atm_exp_fit(h[il],h[il+1],&a[il],&b[il],&c[il],&s0[il],&np);
         sxbest += s[il];
      }

      c[nl-1] = 2./rhofx_(&h[nl-1]);
      a[nl-1] = thickx_(&h[nl-1]) + h[nl-1]/c[nl-1];
      b[nl-1] = 1.;
      h[nl] = a[nl-1]*c[nl-1];
   }
#ifdef DEBUG_ATM_FIT
   else
      printf("No layer adjustment enabled\n");
#endif

   printf("\nResults of the atmosphere fit:\n");
   for ( il=0; il<nl; il++)
      printf("  Layer %d: %6.2f km < h < %6.2f km: a =%13.6g, b =%13.6g, c =%13.6g\n",
         il+1,h[il]/1e5,h[il+1]/1e5,a[il],b[il],c[il]);
   printf("  Sum of residuals squared: %g (compared to %g with starting layers)\n", sxbest, sx[0]);
   printf("\n");
#ifdef DEBUG_ATM_FIT
   puts("thickb(h)=(h<h2b?a1b+b1b*exp(-h*1e5/c1b):(h<h3b?a2b+b2b*exp(-h*1e5/c2b):(h<h4b?a3b+b3b*exp(-h*1e5/c3b):(h<h5b?a4b+b4b*exp(-h*1e5/c4b):(h<h6b?a5b-h*1e5/c5b:0)))))");
   puts("rhob(h)=(h<h2b?b1b/c1b*exp(-h*1e5/c1b):(h<h3b?b2b/c2b*exp(-h*1e5/c2b):(h<h4b?b3b/c3b*exp(-h*1e5/c3b):(h<h5b?b4b/c4b*exp(-h*1e5/c4b):(h<h6b?1./c5b:0)))))");
   for ( il=0; il<=nl;il++)
     printf("h%db=%6.2f;",il+1,h[il]/1.e5);
   printf("\n");
   for ( il=0; il<nl;il++)
     printf("a%db=%13.6g;",il+1,a[il]);
   printf("\n");
   for ( il=0; il<nl;il++)
     printf("b%db=%13.6g;",il+1,b[il]);
   printf("\n");
   for ( il=0; il<nl;il++)
     printf("c%db=%13.6g;",il+1,c[il]);
   printf("\n");
#endif

#ifdef RESPECT_EGS_TOP_OF_ATMOSPHERE
   if ( h[nl] > 113e5 ) /* There was a fixed limit of 113 km in EGS part */
   {
      fflush(NULL);
      if ( h[nl-1] >= 112.99e5 )
      {
         fprintf(stderr,
         "\nAtmospheric boundaries cannot satisfy requirements for CORSIKA\n");
         fprintf(stderr,"EGS part (upper end at %6.2f instead of 113.00 km)\n\n",
            h[nl]/1e5);
      }
      else
      {
         double rho;
         fprintf(stderr,"\nUpper atmospheric boundary forced from %6.2 to 113.00 km\n",
             h[nl]/1e5);
         fprintf(stderr,"to satisfy requirements for CORSIKA EGS part\n");
         h[nl] = 113e5;
         rho = thickx_(&h[nl-1]) / (h[nl]-h[nl-1]);
         c[nl-1] = 1./rho;
         a[nl-1] = thickx_(&h[nl-1]) + h[nl-1]/c[nl-1];
      }
   }
#endif

   for ( il=0; il<nl; il++ )
   {
      aatm[il] = a[il];
      batm[il] = b[il];
      catm[il] = c[il];
      hlay[il] = h[il];
   }

   /* Finally, we amend our table such that the density and thickness */
   /* at the level corresponding to the top of the atmosphere are zero */
   /* and any further levels are ignored. */
   /* Note that results from the interpolation and the CORSIKA formulae */
   /* will still not agree in the upper linear density gradient component. */
   top_of_atmosphere = h[nl];
   for (il=0; il<num_prof; il++)
      if ( p_alt[il] >= top_of_atmosphere )
      {
         p_alt[il] = top_of_atmosphere;
         p_rho[il] = p_rho[il-1];
         p_log_rho[il] = p_log_rho[il-1];
         p_log_thick[il] = -100;
         p_log_n1[il] = p_log_n1[il-1];
         num_prof = il+1;
         break;
      }

   /* An environment variable can be used to show fit compared to table  */
   if ( getenv("SHOWFIT") != NULL )
      show_fit = atoi(getenv("SHOWFIT"));
   else
      show_fit = 1;

   if ( show_fit )
   {
      int ip;
      int nr=0;
      double rr=0., rr2=0., rt=0., rt2=0.;
      printf("\nAltitude [km]    rho(table)     rho(fit)       thick(table)  thick(fit)\n");
      for (ip=0; ip<num_prof; ip++ )
      {
      	 if ( p_alt[ip] >= bottom_of_atmosphere && 
	      p_alt[ip] <= top_of_atmosphere )
	 {
	    printf("     %5.1f     %12.5e  %12.5e     %12.5e  %12.5e\n",
	       p_alt[ip]/1e5, p_rho[ip], /* rhofx_(&p_alt[ip]) */ 
                  fn_rhof(p_alt[ip],nl,h,a,b,c),
	       exp(p_log_thick[ip]), /* thickx_(&p_alt[ip]) */ 
                  fn_thick(p_alt[ip],nl,h,a,b,c));
	 }
         if ( p_alt[ip] >= bottom_of_atmosphere && exp(p_log_thick[ip]) > 1.0 )
         {
            double r = p_rho[ip]/fn_rhof(p_alt[ip],nl,h,a,b,c);
            double t = exp(p_log_thick[ip])/fn_thick(p_alt[ip],nl,h,a,b,c);
            rr += r;
            rr2+= r*r;
            rt += t;
            rt2+= t*t;
            nr++;
         }
      }
      if ( nr >= 2 )
      {
         double sr = sqrt((rr2/nr - (rr/nr)*(rr/nr))*(double)nr/(nr-1.0));
         double st = sqrt((rt2/nr - (rt/nr)*(rt/nr))*(double)nr/(nr-1.0));
         double t=1.0;
         if ( sr > 0.1 || st > 0.1 )
            printf("\n *** Warning: problem with atmospheric fit ***\n");
         printf("\n Std. dev. in density ratio: %5.3f percent, in thickness ratio: %5.3f percent,"
                "\n including only layers at thickness above 1 g/cm^2 (altitude below %5.3f km).\n",
            sr*100., st*100., 1e-5*heighx_(&t));
      }
      printf("\n");
      if ( show_fit == 999 )
      {
      	 printf("Terminating now as requested by the SHOWFIT environment variable.\n");
	 exit(0);
      }
   }

   free(h); free(s); free(s0); free(a); free(b); free(c);

   fflush(stdout);

   return;
}

void show_atmo_macros(void);

#if defined (TEST_ATMO)

/** @defgroup Atmo interface test program test_atmo */
/** @{ */

double rhof_(double *h) { exit(1); return 0.; }
double heigh_(double *t) { exit(2); return 0.; }
double thick_(double *h) { exit(3); return 0.; }

/** Basic test program, without fitting */

int main (int argc, char **argv)
{
   int iatmo = 0;
   double olev = 1800e2;
   double h, t, h2;
   if ( argc > 1 )
      iatmo = atoi(argv[1]);
   if ( argc > 2 )
      olev = atof(argv[2])*1e2;

   show_atmo_macros();

   atmset_(&iatmo,&olev);
   
   for ( h=olev; h<30e5; h+=0.001e5 )
   {
      t  = thickx_(&h);
      h2 = heighx_(&t);
      printf("%f %f %f\n",h,t,h2-h);
   }
   return 0;
}

/** @} */

#elif defined (TEST_FIT_ATMO)

/** @defgroup Atmo interface test program test_fit_atmo */
/** @{ */

double rhof_(double *h) { exit(1); return 0.; }
double heigh_(double *t) { exit(2); return 0.; }
double thick_(double *h) { exit(3); return 0.; }

#include <ctype.h>

/** Basic test program, including fitting the profile */

int main (int argc, char **argv)
{
   int iatmo = 0;
   double olev = 1800e2;
   int nlay = 5;
   double hlay[5] = { -5779.5e2 ,   4.e5  ,      1.e6  ,     4.e6,   1.e7 };
   double aatm[5] = { -186.555306, -94.919,  0.61289,0.,.01128292 };
   double batm[5] = {  1222.6562, 1144.9069, 1305.5948, 540.1778, 1. };
   double catm[5] = { 994186.38, 878153.55, 636143.04, 772170.16, 1.e9 };
   if ( argc > 2 )
      olev = atof(argv[2])*1e2;
   if ( argc > 1 )
   {
      if ( isdigit(argv[1][0]) )
         iatmo = atoi(argv[1]);
      else
      {
         iatmo = 99;
         atmnam_(argv[1],&olev);
      }
   }

   show_atmo_macros();

   atmset_(&iatmo,&olev);

   atmfit_(&nlay, hlay, aatm, batm, catm);

   return 0;
}

/** @} */

#elif defined (EVAL_ATMO)

/** @defgroup Atmo interface test program eval_atmo */
/** @{ */

double rhof_(double *h) { exit(1); return 0.; }
double heigh_(double *t) { exit(2); return 0.; }
double thick_(double *h) { exit(3); return 0.; }

#define MAX_D 10

/** This optional main program evaluates the atmospheric profiles for potential sites. */
/** Syntax: eval_atmo iatmo alt_meters [ radius_of_cherenkov_cone_footprint ... ] */

int main (int argc, char **argv)
{
   int iatmo = 0;
   double olev = 2150e2;
   double h, dh;
   static double d[MAX_D] = { 4.4, 7.4, 13.0, 24.0, 0.0 };
   double r;
   int nd, id, iter;
   if ( argc > 1 )
      iatmo = atoi(argv[1]);
   if ( argc > 2 )
      olev = atof(argv[2])*1e2;
   atmset_(&iatmo,&olev);

   if ( argc > 3 )
   {
      int iarg;
      for (id=0; id<MAX_D; id++)
         d[id] = 0.0;
      for ( iarg=3, id=0; iarg<argc && id<MAX_D; iarg++ )
      {
         d[id++] = atof(argv[iarg]);
      }
   }

   show_atmo_macros();

   printf("* Atmosphere %d at altitude %3.1f m:\n", iatmo, olev*0.01);
   printf("*   Atmospheric depth at ground level: %5.3f g/cm^2\n", thickx_(&olev));
   printf("*   Density at ground level: %g g/cm^3\n", rhofx_(&olev));
   printf("*   Refractivity at ground level: %g\n", refidx_(&olev)-1.0);
   printf("*   Maximum Cherenkov angle at ground level: %6.4f deg.\n",
      (180./M_PI)*acos(1./refidx_(&olev)));

   nd = 0;
   for ( id=0; id<sizeof(d)/sizeof(d[0]); id++ )
   {
      if ( d[id] <= 0. )
         break;
      nd++;
   }
   if ( nd > 0 )
      printf("*   Cherenkov light emitted at half of max. Ch. angle arriving within given dist. from particle impact (no bending/scattering):\n");
   for ( id=0; id<nd; id++ )
   {
      h = olev;
      for ( iter=0; iter<10; iter++ )
      {
         r = refidx_(&h);
         dh = d[id]*1e2 / tan(acos(1./r)*0.5);
         h = olev + dh;
      }
      printf("*     Emission at h=%5.3f km a.s.l., t=%5.3f g/cm^2 (half of %5.3f deg.):"
             " within %4.2f m.\n",
         h*1e-5, thickx_(&h), (180./M_PI)*acos(1./r), d[id]);
   }

   return 0;
}

/** @} */

#elif defined (EVAL_AIRMASS)

/** @defgroup Atmo interface test program eval_airmass */
/** @{ */

#include <ctype.h>

double rhof_(double *h) { exit(1); return 0.; }
double heigh_(double *t) { exit(2); return 0.; }
double thick_(double *h) { exit(3); return 0.; }

/** Optional main program (test plus doing something useful) which
    integrates through the spherical atmosphere, either along
    a straight line or along the refracted path, from ground to
    the top of the atmosphere and telling where the top is reached. 
 */

int main (int argc, char **argv)
{
   int iatmo = 0;
   double olev = 2150e2;
   double za = 0.;
   double rc = 6370.6e5;
   double cz, sz;
   double step = 10e2;
   double x, y, r, h, rho;
   double x2, y2, r2, h2, rho2;
   double hmax =120e5;
   double n1, n2, p;
   double t=0., dt, ss = 0., sx=0.;
   int norefract = 0;
   const char *aname = NULL;
   
   if ( argc == 1 || (argc > 1 && strcmp(argv[1],"--help") == 0) )
   {
      fprintf(stderr,"%s: Evaluate atmospheric along path through spherical atmosphere.\n", argv[0]);
      fprintf(stderr,"Syntax: %s [ -n ] [ -r r_km ] iatmo [ olev_m [ za_deg [ step_m ] ] ]\n", argv[0]);
      fprintf(stderr,"Options:\n");
      fprintf(stderr,"   -n            No refraction included in the calculation of the path.\n");
      fprintf(stderr,"   -r r_km       Actual radius of Earth in given place/direction [km] (%4.2f).\n", rc*1e-5);
      fprintf(stderr,"Parameters:\n");
      fprintf(stderr,"    #1 (iatmo):  Atmospheric profile number or file name\n");
      fprintf(stderr,"    #2 (olev_m): Observation level [m] above sea level (%3.1f m)\n",olev/1e2);
      fprintf(stderr,"    #3 (za_deg): Zenith angle at observation level [deg] (0.)\n");
      fprintf(stderr,"    #4 (step_m): Step size for ray-tracing [m] (default: %3.1f m)\n", step/1e2);
      exit(1);
   }

   show_atmo_macros();

   if ( argc > 1 && strcmp(argv[1],"-n") == 0 )
   {
      norefract = 1;
      argc--;
      argv++;
   }
   if ( argc > 2 && strcmp(argv[1],"-r") == 0 )
   {
      rc = atof(argv[2])*1e5;
      argc-=2;
      argv+=2;
   }
   if ( argc > 1 && isdigit(argv[1][0]) )
   {
      iatmo = atoi(argv[1]);
   }
   else if ( argc > 1 )
   {
      aname = argv[1];
      iatmo = 99;
   }
   if ( argc > 2 )
      olev = atof(argv[2])*1e2;
   if ( argc > 3 )
      za = atof(argv[3])*M_PI/180.;
   if ( argc > 4 )
      step = atof(argv[4])*1e2;

   if ( iatmo == 99 && aname != NULL )
   {
      /* With CORSIKA it would be two steps: */
      // atmnam_(aname,NULL);
      // atmset_(&iatmo,&olev);
      /* Use the one-step approach instead here: */
      atmnam_(aname,&olev);
   }
   else
      atmset_(&iatmo,&olev);
   
   cz = cos(za);
   sz = sin(za);

   h = olev;
   r = y = rc + h;
   x = 0.;
   n1 = norefract ? 1 : refidx_(&h);
   p = n1*r*sz; /* Invariant */
   rho = rhofx_(&h);
   
   while ( h<hmax )
   {
      x2 = x + step * sz;
      y2 = y + step * cz;
      
      r2 = sqrt(x2*x2 + y2*y2);
      h2 = r2 - rc;
      n2 = norefract ? 1 : refidx_(&h2);
      rho2 = rhofx_(&h2);
      dt = step * 0.5*(rho + rho2);
//      dt = step * 0.25*(rho + 2.*sqrt(rho*rho2) + rho2);
      t += dt;
      ss += step;
      sx += step*sz * (rc+olev)/(0.5*(r+r2));

#ifdef DEBUG_EVAL_AIRMASS
 printf("Move from x=%g, y=%g, r=%g, h=%g, za=%g to x=%g, y=%g, r=%g, h=%g, za=%g with rho=%g, dt=%g\n",
    x/1e5, y/1e5, r/1e5, h/1e5, asin(sz)*(180./M_PI), x2/1e5, y2/1e5, r2/1e5, h2/1e5, asin(p/(r2*n2))*(180./M_PI), 0.5*(rho+rho2), dt);
#endif

      sz = p/(r2*n2);
      cz = sqrt(1.-sz*sz); /* At this point downward backtracing would fail */
      if ( h2 < h )        /* so we need to remember when we were going down. */
         cz *= -1.;
      x = 0.;
      y = r2;
      h = h2;
      r = r2;
      rho = rho2;
   }
   
   printf("Top of atmosphere (%g km a.s.l.) reached after %g km path and %g g/cm^2 depth.\n",
      hmax/1e5, ss/1e5, t);
   if ( norefract )
      printf("This path does not include refraction along the path.\n");
   else
      printf("This path includes refraction of the light along the path.\n");
   printf("Final point is %g km along the surface, at zenith angle %g deg.\n",
       sx/1e5, asin(sz)*(180./M_PI));

   return 0;
}

/** @} */

#elif defined (CHECK_REFRACT)

/** @defgroup Atmo interface test program check_refract */
/** @{ */

#include <ctype.h>

double rhof_(double *h) { exit(1); return 0.; }
double heigh_(double *t) { exit(2); return 0.; }
double thick_(double *h) { exit(3); return 0.; }

/** Optional main program checking the refraction corrections against ray tracing
    for a planar atmosphere. If compiled with -DCHECK_REFRACT it will output
    more values to verify that atmosphere interpolation, including reverse
    also work as expected.
 */

int main (int argc, char **argv)
{
   int iatmo = 1;
   double olev = 2150e2, emlev = 30000e2;
   double za = 45.*M_PI/180.;
   double cz = cos(za), sz = sin(za);
   double step = 10e2;
   double x, y, h;
   double n1;
   double ss = 0.;
   double t = 0.;
   const char *aname = NULL;
   double vc = 29.9792458; /* Vacuum speed of light [cm/ns] */
   
   if ( argc == 1 || (argc > 1 && strcmp(argv[1],"--help") == 0) )
   {
      fprintf(stderr,"%s: Check refraction corrections against ray tracing.\n", argv[0]);
      fprintf(stderr,"Syntax: %s iatmo [ olev_m [ za_deg [ step_m [ emlev_m ] ] ] ]\n", argv[0]);
      fprintf(stderr,"Parameters:\n");
      fprintf(stderr,"    #1 (iatmo):  Atmospheric profile number or file name\n");
      fprintf(stderr,"    #2 (olev_m): Observation level [m] above sea level (%3.1f m)\n",olev/1e2);
      fprintf(stderr,"    #3 (za_deg): Zenith angle at observation level [deg] (0.)\n");
      fprintf(stderr,"    #4 (step_m): Step size for ray-tracing [m] (default: %3.1f m)\n", step/1e2);
      fprintf(stderr,"    #5 (emlev_m): Emission level [m] above sea level (default: %3.1f m)\n", emlev/1e2);
      exit(1);
   }
   
   show_atmo_macros();

   if ( argc > 1 && isdigit(argv[1][0]) )
   {
      iatmo = atoi(argv[1]);
   }
   else if ( argc > 1 )
   {
      aname = argv[1];
      iatmo = 99;
   }
   if ( argc > 2 )
      olev = atof(argv[2])*1e2;
   if ( argc > 3 )
      za = atof(argv[3])*M_PI/180.;
   if ( argc > 4 )
      step = atof(argv[4])*1e2;
   if ( argc > 5 )
      emlev = atof(argv[5])*1e2;

   if ( iatmo == 99 && aname != NULL )
   {
      /* With CORSIKA it would be two steps: */
      // atmnam_(aname,NULL);
      // atmset_(&iatmo,&olev);
      /* Use the one-step approach instead here: */
      atmnam_(aname,&olev);
   }
   else
      atmset_(&iatmo,&olev);

   printf("\nBottom of atmosphere is at %5.3f km altitude (log(thickness)=%g)\n",
      bottom_of_atmosphere*1e-5, bottom_log_thickness);
   printf("Top of atmosphere is at %5.3f km altitude\n",
      top_of_atmosphere*1e-5);
   printf("Height [km]       Density       Thickness      Index of ref.  Back to h. [km] Delta [m]\n");
   /* Test cases in height particularly dense at the assumed bottom (sea level) and top (120 km) */
   double htest[] = { 0., 0.001, 0.01, 0.1, 1.3,  2., 3.2, 5., 5.123, 8.7, 10., 
      12.3, 15., 20., 33., 50., 72., 80., 93., 100., 106., 110., 112., 114., 
      114.9, 114.99, 114.999, 114.999999, 115., 115.000001, 115.001, 115.01, 115.1,
      117., 118., 119., 119.9, 119.99, 119.999, 120., 200. };
   for ( size_t k=0; k<sizeof(htest)/sizeof(htest[0]); k++ )
   {
      double h_cm = htest[k]*1e5;
      double thick = thickx_(&h_cm);
      double rho = rhofx_(&h_cm);
      double n = refidx_(&h_cm);
      double H = heighx_(&thick);
      printf("  %10.6f  %14.7g %14.7g   %12.10f   %12.8f    %9.5f\n",
         h_cm*1e-5, rho, thick, n, H*1e-5,(H-h_cm)*1e-2);
   }


   cz = cos(za);
   sz = sin(za);

   h = emlev-olev;
   y = emlev;
   x = h * tan(za);
   n1 = refidx_(&emlev);
   printf("\n\nStart ray at x = %5.3f m, z = %5.3f m a.s.l., n=%8.6f\n",
      x*1e-2, y*1e-2, n1);
   double n2 = refidx_(&olev);
   double sz2 = sz*n1/n2;

   /* Tracing with two different step lengths and then extrapolating
      to even smaller step lengths can give quite accurate results
      at a fraction of the computing time. */

   double xo1, xo2, to1, to2, so1, so2;

   trace_ray_planar(emlev,olev,za,step,&xo1,&to1,&so1);
   trace_ray_planar(emlev,olev,za,0.5*step,&xo2,&to2,&so2);

   /* Factors (about 1.0) in extrapolation derived experimentally */
   x  = xo2 + 1.05*(xo2-xo1);
   t  = to2 + 1.025*(to2-to1);
   ss = so2 + 1.05*(so2-so1);

   printf("Ray from %3.1f m down to %3.1f m altitude at %5.3f deg zenith angle in steps of %4.2f m\n"
          "   has straight line distance = %5.3f m (to x=0), at (vaccum) speed of light takes %5.3f ns,\n"
          "   travels %5.3f m, arriving in x=%5.3f m, z=%5.3f m at time=%5.3f ns.\n",
              emlev*1e-2, olev*1e-2, za*(180./M_PI), step*1e-2,
              (emlev-olev)/cos(za)*1e-2, (emlev-olev)/cos(za)/vc,
              ss*1e-2, x*1e-2, olev*1e-2, t);
   double uray = sz, vray = 0., wray = cz, dxray = 0., dyray = 0., dtray = 0.;
   raybnd_(&emlev, &uray, &vray, &wray, &dxray, &dyray, &dtray);
   printf("Raybnd results: x = %5.3f m, t = %5.3f ns\n", -dxray*1e-2, dtray);
   printf("Index of refraction at observation level: %8.6f, zenith angle = %7.5f deg.\n",
      n2, asin(sz2)*(180./M_PI));
   printf("Ray deflected by %3.1f arc seconds.\n", (za-asin(sz2))*(180./M_PI)*3600.);

   double h0 = olev;
   double h1 = (olev<5e5) ? 5e5 : olev + 3e5;
   double h2 = (olev<15e5) ? 15e5 : olev + 13e5;
   double h3 = (olev<50e5) ? 50e5 : olev + 48e5;

   printf("\n\nCalculating difference between raybnd() correction and full tracing with step size %g m:\n", step*0.01);
   printf("\nUsing h1=%5.3f [km], h2=%5.3f [km], h3=%5.3f [km], observation level is %5.3f km\n", 
      h1*1e-5, h2*1e-5, h3*1e-5, h0*1e-5);
   printf("\nZ.a. [deg]     horizontal dev. [m]        time dev. [ns]\n"
            "                h1     h2     h3         h1     h2     h3\n");
   
   for ( double theta=0.; theta<71.*(M_PI/180.); theta+=10.*(M_PI/180.) )
   {
      double x_h1, t_h1, s_h1, dx_h1=0., dy_h1=0., dt_h1=0.;
      double x_h2, t_h2, s_h2, dx_h2=0., dy_h2=0., dt_h2=0.;
      double x_h3, t_h3, s_h3, dx_h3=0., dy_h3=0., dt_h3=0.;
      double u1=sin(theta), v1=0., w1=cos(theta);
      double u2=sin(theta), v2=0., w2=cos(theta);
      double u3=sin(theta), v3=0., w3=cos(theta);
      trace_ray_planar(h1,h0,theta,step,&x_h1,&t_h1,&s_h1);
      trace_ray_planar(h2,h0,theta,step,&x_h2,&t_h2,&s_h2);
      trace_ray_planar(h3,h0,theta,step,&x_h3,&t_h3,&s_h3);
      raybnd_(&h1, &u1, &v1, &w1, &dx_h1, &dy_h1, &dt_h1);
      raybnd_(&h2, &u2, &v2, &w2, &dx_h2, &dy_h2, &dt_h2);
      raybnd_(&h3, &u3, &v3, &w3, &dx_h3, &dy_h3, &dt_h3);
      printf("  %5.1f       %6.3f %6.3f %6.3f     %6.3f %6.3f %6.3f\n",
         theta*(180./M_PI),  
         (dx_h1+x_h1)*1e-2, (dx_h2+x_h2)*1e-2, (dx_h3+x_h3)*1e-2, /* Keep different directions in mind */
         dt_h1-t_h1, dt_h2-t_h2, dt_h3-t_h3);
   }

   return 0;
}

/** @} */

#endif


#define _XSTR_(s) _STR_(s) /**< Expand a macro first and then enclose in string */
#define _STR_(s) #s /**< Enclose in string without macro expansion. */
/** The following shows the same output after a "#define XYZ" and a "#define XYZ 1" (or compiled with "-DXYZ") */
/** Other non-empty, not "1" assigned values are shown explicitly. */
/** Undefined macros are not shown. Neither are any assigned to itself. */
#ifndef SHOW_ALL_MACROS
#define SHOW_MACRO(s) if ( strcmp(#s,_XSTR_(s)) != 0 ) \
    { if ( strcmp("", _XSTR_(s)) != 0 && strcmp("1", _XSTR_(s)) != 0 ) \
       printf( "    " #s "=" _XSTR_(s) "\n" ); else printf( "    " #s "\n" ); }
#else
#define SHOW_MACRO(s) if ( strcmp(#s,_XSTR_(s)) != 0 ) \
    { if ( strcmp("", _XSTR_(s)) != 0 && strcmp("1", _XSTR_(s)) != 0 ) \
       printf( "    with " #s "=" _XSTR_(s) "\n" ); else printf( "    with " #s "\n" ); } \
    else { printf( "    no " #s "\n" ); }
#endif

void show_atmo_macros()
{
   printf("\nPre-processor definitions activated in this version:\n");
   SHOW_MACRO(WITH_RPOLATOR)
   SHOW_MACRO(NO_RPOLATOR)
   SHOW_MACRO(WITH_RPOLATOR_SEPARATE)
   SHOW_MACRO(WITH_RPOLATOR_CSPLINE)
   SHOW_MACRO(NO_RPOLATOR_CSPLINE)
   SHOW_MACRO(NO_FAST_INTERPOLATION)
   SHOW_MACRO(FAST_INTERPOLATION)
   SHOW_MACRO(NO_FAST_INTERPOLATION2)
   SHOW_MACRO(FAST_INTERPOLATION2)
   SHOW_MACRO(NO_FAST_INTERPOLATION3)
   SHOW_MACRO(FAST_INTERPOLATION3)
   SHOW_MACRO(NO_THICKX_DIRECT)
   SHOW_MACRO(WITH_THICKX_DIRECT)
   SHOW_MACRO(NO_THICKX_DIRECT_CSPLINE)
   SHOW_MACRO(WITH_THICKX_DIRECT_CSPLINE)
   SHOW_MACRO(MAX_PROFILE)
   SHOW_MACRO(MAX_FAST_PROFILE)
   SHOW_MACRO(DEBUG_TEST_ALL)
   SHOW_MACRO(TEST_RAYBND)
   SHOW_MACRO(MORE_ATMO_TESTS)
   SHOW_MACRO(LONG_ATMPROF)
   SHOW_MACRO(NLAYX)
   SHOW_MACRO(DEBUG_ATM_FIT)
   SHOW_MACRO(DEBUG_ATM_FIT2)
   SHOW_MACRO(RESPECT_EGS_TOP_OF_ATMOSPHERE)
   SHOW_MACRO(TEST_ATMO)
   SHOW_MACRO(TEST_FIT_ATMO)
   SHOW_MACRO(EVAL_ATMO)
   SHOW_MACRO(MAX_D)
   SHOW_MACRO(EVAL_AIRMASS)
   SHOW_MACRO(DEBUG_EVAL_AIRMASS)
   SHOW_MACRO(CHECK_REFRACT)
}

#ifdef __cplusplus
}
#endif

/** @} */
