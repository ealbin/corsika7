/* ============================================================================

   Copyright (C) 2016  Konrad Bernloehr

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

============================================================================ */

/**
 *  @file fake_corsika.c
 *  @short Simple demonstration of how to write photon bunches without CORSIKA.
 *
 *  The resulting data file will be in the same format as CORSIKA IACT
 *  output and can thus be processed with sim_telarray or any other
 *  program handling the same type of data.
 *
 *  For a much more easy-to-use tool see IactLightEmission in the 
 *  sim_telarray package.
 *
 *  @author  Konrad Bernloehr 
*/

/*
* Compile with
* gcc -DIACT_NO_GRID -O3 -Wall -o fake_corsika fake_corsika.c iact.c \
*      io_simtel.c eventio.c fileopen.c warning.c \
*      straux.c atmo.c sampling.c -lm
* All of the required files are distributed with the IACT/atmo package.
*/

#include "initial.h"      /* This file includes others as required. */
#include "io_basic.h"     /* This file includes others as required. */
#include "mc_tel.h"
#include "iact.h"
#include "atmo.h"

/* Dummy implementations of CORSIKA-linked functions */

void rmmard_(double *a, int *b, int *c)
{
}

double rhof_(double *height)
{
   return rhofx_(height);
}
double thick_(double *height)
{
   return thickx_(height);
}
double heigh_(double *thick)
{
   return heighx_(thick);
}

/* Static arrays as passed from CORSIKA to the IACT interface */

static cors_real_t runh[273];
static cors_real_t evth[273];
static cors_real_t evte[273];
static cors_real_t rune[273];
static cors_dbl_t prmpar[PRMPAR_SIZE];

/* Telescope position as in the CORSIKA inputs card TELESCOPE */

struct telpos_struct
{
   cors_dbl_t x, y, z, r;
};
typedef struct telpos_struct TelPos;

static TelPos telpos;

/* Extended version of photon bunches */

struct photon_bunch
{
   double photons;             //< Size of photon bunch
   double weight;              //< Weight = 1.0 (no thinning)
   double xem, yem, zem;       //< Emission position
   double xol, yol, tol;       //< Position arriving at "observation level" (below telescope)
   double dx, dy, dt;          //< Shift in ray propagation
   double u,v,w;               //< All direction cosines (not necessarily normalized)
   double ctime;               //< Time of emission
   double lambda;              //< Wavelength of photons in bunch
};
typedef struct photon_bunch Bunch;

static Bunch bunch;

/* Various other local variables corresponding to CORSIKA inputs */

static int nscat = 1;
cors_dbl_t cscat1 = 0., cscat2 = 0.; // Note non-zero value requires working random generator
int iatmo = 1;
int nshow = 0;
double obslev = 2000e2;
double rtel = 10e2;
char fname[1024];
double profile[9][15];
int ptype=1, nprof=9, ndim=15, nthick=10;
double thickstep=100;

/* Simplified function for adding history lines */

void addhist(const char *txt)
{
   int len = strlen(txt);
   tellni_(txt,&len);
}

/* Main program */

int main()
{
   int i;
   
   double theta = 35.*M_PI/180., phi = 40.*M_PI/180.;
   double dls = 100.e2; /* 100 m from the reference position = telescope */
   double xls = cos(phi)*sin(theta) * dls;
   double yls = -sin(phi)*sin(theta) * dls;
   double zls = cos(theta) * dls;
   double airlightspeed;
   
   /* Prepare some text to be written to the data file like
      comments in a CORSIKA inputs file. */
   addhist("* This file was actually produced by fake_corsika");
   addhist("* and not by CORSIKA itself.");
   addhist("* It is based on artificial light sources and");
   addhist("* interaction model parameters are irrelevant.");

   /* Dummy longitudinal profiles initialized */
   for ( i=0; i<nprof; i++ )
      profile[i][8] = 1.;

   /* Output file */
   strcpy(fname,"+");
   strcat(fname,"fake.corsika.gz:1000");
   telfil_(fname);

   /* Markers at the beginning of the CORSIKA-style data blocks. */
   strncpy((char*)runh,"RUNH",4);
   strncpy((char*)evth,"EVTH",4);
   strncpy((char*)evte,"EVTE",4);
   strncpy((char*)rune,"RUNE",4);
   
   /* Initialize run header */
   runh[1] = 12345; // Run number
   runh[2] = 10203; // Date of run start
   runh[3] = 6.999; // Fake corsika version (there is no 6.999 and never will be)
   runh[4] = 1;     // No. of observation levels
   runh[5] = obslev;// Observation level [cm]
   runh[15] = 0.;   // Spectral slope 
   runh[16] = 1e-9; // Emin
   runh[17] = 1e-9; // Emax

   /* Set atmospheric profile. */
   atmset_(&iatmo,&obslev);
   airlightspeed = 29.9792458/refidx_(&obslev);

   /* Emit run header block */
   telrnh_(runh);

   /* Use just one telescope above the observation level */
   telpos.x = telpos.y = 0.0;
   telpos.z = rtel;
   telpos.r = rtel;
   telset_(&telpos.x, &telpos.y, &telpos.z, &telpos.r);
   
   /* We do not actually use random scattering of events but need to specify. */
   telasu_(&nscat, &cscat1, &cscat2);
   
   /* Show what has been set up with the IACT interface so far. */
   telshw_();

   /* Prepare the event header with run-wise information */
   evth[1] = 1;       // First event
   evth[2] = 1;       // Gamma ray primary (no offset correction applied)
   evth[3] = 1e-9;    // Dummy total energy of primary
   evth[4] = obslev;  // Starting altitude is observation level
   evth[5] = 0;       // Don't care about first target
   evth[6] = evth[4]; // (Heigh of first interaction.) Positive value indicates TSTART is off; T=0 is at obs.lev.
   evth[7] = -xls/dls;  // px of "shower" (towards North)
   evth[8] = -yls/dls;  // py of "shower" (towards West)
   evth[9] = -zls/dls;  // pz of "shower" (upward or downward?)
   evth[10] = acos(-evth[9]); // Corresponding zenith angle in radian
   evth[11] = atan2(evth[8],evth[7]); // Corresponding (CORSIKA-style) azimuth angle in radian = atan2(py,px)
   evth[43] = runh[1];  // Run number
   evth[44] = runh[2];  // Date of begin run (yymmdd)
   evth[45] = runh[3];  // Version of program
   evth[46] = runh[4];  // Number of observation levels
   evth[47] = runh[5];  // Observation level [cm]
   evth[57] = runh[15]; // Slope of energy spectrum
   evth[58] = runh[16]; // Lower limit in energy [GeV]
   evth[59] = runh[17]; // Upper limit in energy [GeV]
   evth[60] = 1.;       // Dummy cutoff in hadron energy
   evth[61] = 0.106;    // Dummy cutoff in muon energy
   evth[62] = 0.000512; // Dummy cutoff in electron energy
   evth[63] = 1e-9;     // Dummy energy in gamma energy
   // Cherenkov flags: CERENKOV,IACT,no CEFFIC,ATMEXT with refraction,VOLUMEDET (adapted), atmospheric profile (typ. 1)
   evth[70] = 20.;      // Bx; assume some B field (towards North)
   evth[71] = 0.;       // Bz
   evth[74] = 2;        // Report low-E interaction model as URQMD although not used;
   evth[75] = 3;        // Report high-E interaction model as QGSjet
   evth[76] = (0x01 | 0x02 | 0x08 | 0x10 | 0x20 | ((iatmo%1024) << 10));
   evth[79] = 3;        // Computer flag (UNIX)
   evth[80] = evth[81] = evth[10]; // Range in zenith angle
   evth[82] = evth[83] = evth[11]; // Range in CORSIKA-style azimuth angle
   evth[84] = 1.0;      // dummy nominal bunch size
   evth[85] = evth[86] = 1; // dummy no. of Cherenkov detectors (CORSIKA-style)
   evth[92] = 0.;       // angle (in rad) between array x-direction and magnetic north
   evth[94] = 1.0;      // report nominal step length factor for multiple scattering step length in EGS4
   evth[95] = 200.;     // Lower end of light spectrum [nm]
   evth[96] = 1000.;    // Upper end of light spectrum [nm]
   evth[97] = 1;        // No of times 'shower' is used
   evth[98] = evth[118] = 0.; // Core x,y 
   evth[152] = evth[153] = 0.; // VIEWCONE inner and out angle

   /* Dummy primary particle must be photon to avoid deflection correction. */
   prmpar[0] = evth[2]; // Particle ID of primary
   prmpar[1] = 0.;
   prmpar[2] = cos(evth[10]); // Cosine of azimuth angle

   /* Start event */
   televt_(evth, prmpar);
   /* Report dummy longitudinal profiles. */
   tellng_(&ptype,&profile[0][0],&ndim,&nprof,&nthick,&thickstep);

   /* Set up first photon bunch */
   bunch.photons = 10.;
   bunch.weight = 1.0;
   bunch.xem = xls; bunch.yem = yls;
   bunch.zem = obslev + rtel + zls;
   bunch.ctime = 12.5; // Arbitrary emission time [ns]
   bunch.u = evth[7]; bunch.v = evth[8]; bunch.w = evth[9];
   bunch.lambda = 380.;
   bunch.xol = bunch.yol = bunch.tol = 0.;
   bunch.dx = bunch.dy = bunch.dt = 0.;
   bunch.xol = bunch.xem + bunch.u/fabs(bunch.w)*(zls+rtel);
   bunch.yol = bunch.yem + bunch.v/fabs(bunch.w)*(zls+rtel);
   bunch.tol = bunch.ctime + dls/airlightspeed + rtel/fabs(bunch.w)/airlightspeed;
   raybnd_(&bunch.zem, &bunch.u, &bunch.v, &bunch.w, 
      &bunch.xol, &bunch.yol, &bunch.tol);
   bunch.dx = bunch.xol - bunch.xem;
   bunch.dy = bunch.yol - bunch.yem;
   bunch.dt = bunch.tol - bunch.ctime;
   printf("Photon bunch of size %f starts at (x=%f, y=%f, z=%f, t=%f)\n"
          "   in direction (u=%f, v=%f, w=%f)\n" 
          "   and arrives in obs.lev. at (%f,%f) at time %f\n",
         bunch.photons, bunch.xem,  bunch.yem, bunch.zem, bunch.ctime,
         bunch.u, bunch.v, bunch.w, 
         bunch.xol, bunch.yol, bunch.tol);
   /* Hand over the photon bunch to the IACT interface. */
   telout_(&bunch.photons, &bunch.weight, &bunch.xol, &bunch.yol,
      &bunch.u, &bunch.v, &bunch.tol, &bunch.zem,
      &bunch.lambda);

   /* Second photon bunch */
   bunch.photons = 11;
   bunch.weight = 1.0;
   bunch.xem = xls; bunch.yem = yls;
   bunch.zem = obslev + rtel + zls + 3.;
   bunch.lambda = 390.;
   bunch.u = evth[7]; bunch.v = evth[8]; bunch.w = evth[9];
   bunch.ctime = 25.; // Arbitrary emission time [ns]
   bunch.xol = bunch.yol = bunch.tol = 0.;
   bunch.dx = bunch.dy = bunch.dt = 0.;
   bunch.xol = bunch.xem + bunch.u/fabs(bunch.w)*(zls+rtel);
   bunch.yol = bunch.yem + bunch.v/fabs(bunch.w)*(zls+rtel);
   bunch.tol = bunch.ctime + dls/airlightspeed + rtel/fabs(bunch.w)/airlightspeed;
   raybnd_(&bunch.zem, &bunch.u, &bunch.v, &bunch.w, 
      &bunch.xol, &bunch.yol, &bunch.tol);
   bunch.dx = bunch.xol - bunch.xem;
   bunch.dy = bunch.yol - bunch.yem;
   bunch.dt = bunch.tol - bunch.ctime;
   printf("Photon bunch of size %f starts at (x=%f, y=%f, z=%f, t=%f)\n"
          "   in direction (u=%f, v=%f, w=%f)\n" 
          "   and arrives in obs.lev. at (%f,%f) at time %f\n",
         bunch.photons, bunch.xem,  bunch.yem, bunch.zem, bunch.ctime,
         bunch.u, bunch.v, bunch.w, 
         bunch.xol, bunch.yol, bunch.tol);
   /* Hand over the photon bunch to the IACT interface. */
   telout_(&bunch.photons, &bunch.weight, &bunch.xol, &bunch.yol,
      &bunch.u, &bunch.v, &bunch.tol, &bunch.zem,
      &bunch.lambda);

   /* With the event end the photon bunches will be written to file */
   evte[1] = evth[1];
   telend_(evte);
   nshow++;
   
   /* Report the end of the run */
   rune[1] = runh[1];
   rune[2] = nshow;
   telrne_(rune);
   
   return 0;
}

