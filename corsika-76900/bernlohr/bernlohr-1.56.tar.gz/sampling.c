/* ============================================================================

   Copyright (C) 2003, 2004, 2010  Konrad Bernloehr

   This file is part of the IACT/atmo package for CORSIKA.

   The IACT/atmo package is free software; you can redistribute it 
   and/or modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   This package is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this package. If not, see <http://www.gnu.org/licenses/>.

============================================================================ */

#include "initial.h"      /* This file includes others as required. */
#ifndef NO_FILEOPEN
#include "fileopen.h"
#endif
#include "sampling.h"

#ifdef __cplusplus
/* You can compile this file with a C++ compiler instead of a C compiler, if you want */
extern "C" {
#endif

double iact_rndm(int dummy);
#define rndm(i) iact_rndm(i)

/* As long as there is no (non-uniform) sampling implementation,
   there are lots of unused function parameters, which we can safely ignore. */

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"

/* ------------------------- sample_offset ---------------------------- */
/**
 *  @short Get uniformly sampled or importance sampled offset of array
 *         with respect to core, in the plane perpendicular to the shower axis.
 *
 *  @param sampling_fname Name of file with parameters, to be read on first call.
 *  @param core_range     Maximum core distance as used in data format check [cm].
 *                        If not obeying this maximum distance, make sure to switch on
 *                        the long data format manually.
 *  @param theta          Zenith angle [radians]
 *  @param phi            Shower azimuth angle in CORSIKA angle convention [radians].
 *  @param thetaref       Reference zenith angle (e.g. of VIEWCONE centre) [radians].
 *  @param phiref         Reference azimuth angle (e.g. of VIEWCONE centre) [radians].
 *  @param offax          Angle between central direction (typically VIEWCONE centre)
 *                        and the direction of the current primary [radians].
 *  @param E              Energy of primary particle [GeV]
 *  @param primary        Primary particle ID.
 *  @param xoff           X offset [cm] to be generated.
 *  @param yoff           Y offset [cm] to be generated.
 *  @param sampling_area  Area weight of the generated sample 
 *                        (normalized to Pi*core_range^2) [cm^2].
 */
/* ------------------------- sample_offset ---------------------------- */

void sample_offset (const char *sampling_fname, double core_range, 
   double theta, double phi, 
   double thetaref, double phiref, double offax, 
   double E, int primary,
   double *xoff, double *yoff, double *sampling_area)
{
   static int init_done = 0;
   double R, p;
   
   if ( !init_done )
   {
      FILE *f = fileopen(sampling_fname,"r");
      if ( f == NULL )
      {
         perror(sampling_fname);
         exit(1);
      }
      /* Read sampling parameters */
      /* ... (TO BE DONE) ... */
      fprintf(stderr,"Sampling parameter file '%s' opened but not used.\n",
         sampling_fname);
      fileclose(f);
      init_done = 1;
   }
   
#ifndef TEST_SAMPLING
   /* In the absence of a real implementation, use uniform distribution. */
   R = core_range*sqrt(rndm(0));
   p = (2.*M_PI) * rndm(1);
   *xoff = R * cos(p);
   *yoff = R * sin(p);
   *sampling_area = M_PI*(core_range*core_range);
#else
   /* Test uniform per radius, not uniform per area. */
   R = core_range*rndm(0);
   p = (2.*M_PI) * rndm(1);
   *xoff = R * cos(p);
   *yoff = R * sin(p);
   *sampling_area = 2.*M_PI*(core_range*R);
#endif
}

#pragma GCC diagnostic pop

#ifdef __cplusplus
}
#endif
