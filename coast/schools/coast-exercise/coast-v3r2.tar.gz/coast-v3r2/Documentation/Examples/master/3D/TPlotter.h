#ifndef __INCLUDE_TPLOTTER_H__
#define __INCLUDE_TPLOTTER_H__

#include <string>
#include <vector>

class TFile;
class TCanvas;
class TObjArray;

namespace crs {
  class CParticle;
  class MEventHeader;
  class MRunHeader;
  class MEventEnd;
};


// corsika routine:
// DOUBLE PRECISION FUNCTION THICK( ARG )
extern "C" double thick_ (const double &height/*cm*/); 
extern "C" double heigh_ (const double &depth/*g/cm*/);


class TPlotter {

public:
    
public:
  TPlotter ();
  ~TPlotter ();

  void SetFileName (std::string file) {fFileName=file;}
  void SetThinning (bool thinn) {fThinning=thinn;}
    
  void SetRunHeader (const crs::MRunHeader &header);
  void SetShowerHeader (const crs::MEventHeader &header);
  void SetShowerTrailer (const crs::MEventEnd &trailer);
    
  void SetEvent (int no) {fEventNo=no;}
  void SetShowerZenith (float zenith);
  void SetShowerAzimuth (float azimuth);
  void SetShowerEnergy (float energy) {fEnergy0=energy;}
  void SetObservationLevel (float level) {fObservationLevel=level;}
  void SetHeightFirstInt (float z) {fHeightFirstInt=z;}
  //void SetXmax (float xmax) {fX_max=xmax;}
  void SetPrimary (int id) {fPrimary=id;}

  bool IsThinned () const {return fThinning;}
    
  void Init ();
  void Write ();
  void Close ();
    
  void AddTrack (const crs::CParticle &pre, const crs::CParticle &post);

private:

  void Clear ();

  double MoliereRadius (double Density, double Temperature);

  double Temperature (double height);

  void Rotate (double x, double y, double z,
	       double &sx, double &sy, double &sz,
	       int inverse);


private:    
  bool fRotateToShowerSystem;

  bool fPrimaryTrack;
  bool fPrimaryTrackFirst;
  float fPrimaryTrackEnergy;
  int fPrimaryTrackId;
  float fFirstParticleX;
  float fFirstParticleY;
  float fFirstParticleZ;
  
  std::string fFileName;
  bool fThinning;
  int fEventNo;
  double fObservationLevel;
  double fHeightFirstInt;
  float fZenith;
  float fAzimuth;
  float fEnergy0;
  int fPrimary;

  double fCosZenith;
  double fSinZenith;
  double fCosAzimuth;
  double fSinAzimuth;
    
  TFile *fFile;
  TCanvas *fCanvas;
  double fXmin;
  double fXmax;
  double fYmin;
  double fYmax;
  double fZmin;
  double fZmax;
  bool fFirst;

  int fNmaxElec;
  int fNmaxMuon;
  int fNmaxHadr;

  double fEminElec;
  double fEminMuon;
  double fEminHadr;

  TObjArray *fLinesElec;
  TObjArray *fLinesMuon;
  TObjArray *fLinesHadr;

  int fNElec;
  int fNMuon;
  int fNHadr;

  static const int fgColorHadron;
  static const int fgColorElectron;
  static const int fgColorMuon;

};



#endif
