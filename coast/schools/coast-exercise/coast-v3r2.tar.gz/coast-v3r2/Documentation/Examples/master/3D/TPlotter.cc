#include <TPlotter.h>

#include <crs/CorsikaConsts.h>
#include <crs/CParticle.h>
#include <crs/MRunHeader.h>
#include <crs/MEventHeader.h>
#include <crs/MEventEnd.h>
using namespace crs;

#include <TFile.h>
#include <TCanvas.h>
#include <TView.h>
#include <TPolyLine3D.h>
#include <TSystem.h>
#include <TObjArray.h>

#include <string>
#include <iostream>
#include <sstream>
#include <iomanip>
using namespace std;


const int TPlotter::fgColorElectron = 3;
const int TPlotter::fgColorMuon     = 4;
const int TPlotter::fgColorHadron   = 2;


TPlotter::TPlotter () {

  fRotateToShowerSystem = true;

  // THIS is the maximum number of tracks to be plotted per shower !
  fNmaxElec = 50000;
  fNmaxMuon = 10000;
  fNmaxHadr = 10000;
  fEminElec = 0.*GeV;
  fEminMuon = 5.*GeV;
  fEminHadr = 5.*GeV;
    
  fLinesElec = new TObjArray();
  fLinesMuon = new TObjArray();
  fLinesHadr = new TObjArray();
  fLinesElec->SetOwner(kFALSE);
  fLinesMuon->SetOwner(kFALSE);
  fLinesHadr->SetOwner(kFALSE);
    
  Clear ();
}



TPlotter::~TPlotter () {

  Clear ();
  delete fFile;
}


void TPlotter::Clear () {

  fPrimaryTrack = true;
  fPrimaryTrackFirst = true;
  fFirstParticleX = 0;
  fFirstParticleY = 0;
  fFirstParticleZ = 0;

  fFirst = true;

  fEventNo = 0;
  fObservationLevel = 0;
  fHeightFirstInt = 0;
  fZenith = 0;
  fAzimuth = 0;
  fEnergy0 = 0;
  fPrimary = 0;

  fCosZenith = 0;
  fSinZenith = 0;
  fCosAzimuth = 0;
  fSinAzimuth = 0;

  fNElec = 0;
  fNMuon = 0;
  fNHadr = 0;
}



void TPlotter::SetShowerZenith (float zenith) {

  cout << " RU: zenith/deg: " << zenith/deg << endl;

  fZenith = zenith*rad;
  fCosZenith = cos (zenith);
  fSinZenith = sin (zenith);
}



void TPlotter::SetShowerAzimuth (float azimuth) {

  cout << " RU: azimuth/deg: " << azimuth/deg << endl;

  fAzimuth = azimuth*rad;
  fCosAzimuth = cos (azimuth);
  fSinAzimuth = sin (azimuth);
}


void TPlotter::SetRunHeader (const crs::MRunHeader &header) {
    
  int run = (int)header.GetRunID ();
    
  // create filename
  ostringstream fname;
  fname << "DAT" 
	<< setw (6) << setfill('0') << run;
    
  SetFileName (fname.str ());
}


void TPlotter::SetShowerHeader (const crs::MEventHeader &header) {

  // to flag the track of the primary particle
  fPrimaryTrack = true;
  fPrimaryTrackFirst = true;
  fFirstParticleX = 0;
  fFirstParticleY = 0;
  fFirstParticleZ = 0;

  SetEvent (header.GetEventNumber ());
  SetPrimary ((int)header.GetParticleID ());
  SetShowerZenith (header.GetTheta ()*rad);
  SetShowerAzimuth (header.GetPhi ()*rad);    
  SetShowerEnergy (header.GetEnergy ()*GeV);
  SetHeightFirstInt (header.GetZFirst ()*cm);
  SetObservationLevel (header.GetObservationHeight (
						    header.GetNObservationLevels ()-1)*cm);

}
    
    
void TPlotter::SetShowerTrailer (const crs::MEventEnd &trailer) {
    
  //cout << " RU: TRAILER " << endl;
  cout << " RU: xmax: " << trailer.GetXmax()/g*cm*cm << endl;
  //SetXmax (trailer.GetXmax ()*g/cm/cm);
}


void TPlotter::Init () {
    
  ostringstream file_name;
  file_name << fFileName 
	    << "_"
	    << fEventNo
	    << "_3d.root";
    
  fFile = TFile::Open (file_name.str ().c_str (), "RECREATE");
  fFile->cd ();    

  ostringstream cname;
  cname << "ev_" << fEventNo; 

  fCanvas = new TCanvas (cname.str ().c_str ());
  fCanvas->SetView (new TView ());

  fLinesElec->Delete();
  fLinesMuon->Delete();
  fLinesHadr->Delete();
}


void TPlotter::Close () {
}


void TPlotter::Write () {
    
  cout << " COAST: +++++++++++++++++++++++++++++++++++ " << endl;
  cout << " plotted em  " << std::min (fNmaxElec, fNElec) 
       << " of " << fNElec << "(max: " << fNmaxElec << ")" << endl;
  cout << "         mu  " << std::min (fNmaxMuon, fNMuon) 
       << " of " << fNMuon << "(max: " << fNmaxMuon << ")" << endl;
  cout << "         had " << std::min (fNmaxHadr, fNHadr) 
       << " of " << fNHadr << "(max: " << fNmaxHadr << ")" << endl;
  cout << " COAST: +++++++++++++++++++++++++++++++++++ " << endl;
    
  fCanvas->cd();
  fLinesElec->Draw();
  fLinesMuon->Draw();
  fLinesHadr->Draw();
  fCanvas->GetView ()->SetRange (fXmin, fYmin, fZmin, fXmax, fYmax, fZmax);
  fCanvas->Write ("", TFile::kOverwrite);
  fFile->Close ();
    
  Clear ();
}




//#define Rotate(x, y, sx, sy, cosa, sina) { \
inline
void TPlotter::Rotate (double x, double y, double z,
		       double &sx, double &sy, double &sz,
		       int inverse) {
    

  double sx_ =             x*fCosAzimuth + inverse * y*fSinAzimuth;
  double sy_ = - inverse * x*fSinAzimuth +           y*fCosAzimuth; 
  double sz_ =   z;


  sx =             sx_*fCosZenith - inverse * sz_*fSinZenith;
  sy = sy_;
  sz = + inverse * sx_*fSinZenith +           sz_*fCosZenith; 

}


void TPlotter::AddTrack (const crs::CParticle &pre, 
			 const crs::CParticle &post) {
    


  cout << " RU: "
       << " id=" << (int)pre.particleID
       << " E=" << pre.energy
       << " w=" << pre.weight
       << " x=" << pre.x
       << " y=" << pre.y
       << " z=" << pre.z
       << " t=" << pre.time
       << " X=" << pre.depth
       << "\n";


  /*
    Skip the track of the primary particle, which is in a different 
    reference system as the shower !!!
  */
  if (fPrimaryTrack) {
    
    if (fPrimaryTrackFirst) {
      fPrimaryTrackFirst = false;
      fPrimaryTrackEnergy = pre.energy;
      fPrimaryTrackId = (int)pre.particleID;
      cout << " RU: first primary: " << fPrimaryTrackEnergy << " " << fPrimaryTrackId << endl;
    }
    if (fPrimaryTrackId==(int)pre.particleID) {
      fFirstParticleX = post.x;
      fFirstParticleY = post.y;
      fFirstParticleZ = post.z;
      return;
    } 
    
    cout << " RU: Primary track end-pos: x=" << fFirstParticleX << " y=" << fFirstParticleY << " z=" << fFirstParticleZ << "\n";
    fPrimaryTrack = false;
  }

  double xPre = pre.x/km;
  double yPre = pre.y/km;
  double zPre = pre.z/km;

  double xPost = post.x/km;
  double yPost = post.y/km;
  double zPost = post.z/km;

  /*   ------------------------
       convert to shower frame
  */
  if (fRotateToShowerSystem) {
    
    double pre_shX, pre_shY, pre_shZ;
    Rotate (pre.x-fFirstParticleX, pre.y-fFirstParticleY, fFirstParticleZ-pre.z, 
	    pre_shX, pre_shY, pre_shZ, +1);
    
    double post_shX, post_shY, post_shZ;
    Rotate (post.x-fFirstParticleX, post.y-fFirstParticleY, fFirstParticleZ-post.z, 
	    post_shX, post_shY, post_shZ, +1);
    
    xPre = pre_shX/km;
    yPre = pre_shY/km;
    zPre = pre_shZ/km;
    
    xPost = post_shX/km;
    yPost = post_shY/km;
    zPost = post_shZ/km;
  }
  
  double e = post.energy/GeV;
  int particleID = (int)pre.particleID;
    
    
  if (particleID<4) {
    if (fEminElec>e)
      return;
  } else if (particleID<7) {
    if (fEminMuon>e)
      return;
  } else {
    if (fEminHadr>e)
      return;
  }

  /*
    cout << " RU: "
    << " " << pre.particleID
    << " " << xPre 
    << " " << yPre 
    << " " << zPre 
    << " " << post.particleID
    << " " << xPost 
    << " " << yPost 
    << " " << zPost 
    << endl;
  */

  /*   ------------------------
       direction of particle in shower frame
  */
  double dX = xPost - xPre; 
  double dY = yPost - yPre; 
  double dZ = zPost - zPre; 
  double length = sqrt (dX*dX + dY*dY + dZ*dZ);
    
  if (length==0) {
    /*   ------------------------ 
	 This happens for particles that are NOT tracked by Corsika
	 e.g. pi0 -> decay immediatly
	 SKIP them
    */
    return;
  }	
    
  int color = 0;
  if (particleID<4) {
    color = fgColorElectron;
    if (fNmaxElec<fNElec++)
      return;
  } else if (particleID<7) {
    color = fgColorMuon;
    if (fNmaxMuon<fNMuon++)
      return;
  } else {
    color = fgColorHadron;
    if (fNmaxHadr<fNHadr++)
      return;
  }
    
  TPolyLine3D *l = new TPolyLine3D (2);
  l->SetPoint (0, xPre, yPre, zPre);
  l->SetPoint (1, xPost, yPost, zPost);
  l->SetLineColor (color);
  //fCanvas->cd ();
  //l->Draw ();
  if (particleID<4) {
    fLinesElec->Add(l);
  } else if (particleID<7) {
    fLinesMuon->Add(l);
  } else {
    fLinesHadr->Add(l);
  }
    
  if (fFirst) {

    fXmin = std::min (xPre, xPost);
    fYmin = std::min (yPre, yPost);
    fZmin = std::min (zPre, zPost);

    fXmax = std::max (xPre, xPost);
    fYmax = std::max (yPre, yPost);
    fZmax = std::max (zPre, zPost);

    fFirst = false;

  } else {

    if (std::min (xPre, xPost)<fXmin)
      fXmin = std::min (xPre, xPost);
    if (std::min (yPre, yPost)<fYmin)
      fYmin = std::min (yPre, yPost);
    if (std::min (zPre, zPost)<fZmin)
      fZmin = std::min (zPre, zPost);

    if (std::max (xPre, xPost)<fXmax)
      fXmax = std::max (xPre, xPost);
    if (std::max (yPre, yPost)<fYmax)
      fYmax = std::max (yPre, yPost);
    if (std::max (zPre, zPost)<fZmax)
      fZmax = std::max (zPre, zPost);

  }
    
}



double TPlotter::MoliereRadius (double VDepth,
				double Temperature) {

  static double E_scale = 21.*MeV;
  static double X_rad_length = 37*g/cm/cm;
  static double e_crit = 81.*MeV;
  static double R_m = E_scale * X_rad_length / e_crit;   // [g/cm2]

  // correct for 2 radiation length
  VDepth -= 2. * X_rad_length * fCosZenith;
  if (VDepth<=0) VDepth = 1.e-8;

  static double MeanAirDensity = 28.95 * g/mol;
  static double g_earth = 9.81 * m/(s*s);
  static double R_gas = 8.314 * joule/mol/Kelvin;
  static double Na = 6.022e23 / mol;
  double Pressure = VDepth * g_earth;
  double Density = Pressure / (R_gas*Temperature/MeanAirDensity);

  return R_m / Density;
}


/*
  double TPlotter::MoliereRadius (double Temperature, 
  double Pressure) {
    
  static double exponent = 1./5.25588;
    
  Temperature /= Kelvin;
  Pressure /= millibar;
    
  double CorrectedPressure = Pressure - 73.94*fCosZenith;
  if (CorrectedPressure<=0) {
  //cout << " RU: CorrectedPressure<0: " << CorrectedPressure << endl;
  //cout << " T: " << Temperature << " P: " << Pressure << endl;
  CorrectedPressure = 0.01;
  Pressure = CorrectedPressure + 73.94*fCosZenith;
  }

  double Rm = 272.5 * Temperature * 
  pow (CorrectedPressure/Pressure, exponent) / CorrectedPressure;
    
  return Rm * m;
  }
*/

double TPlotter::Temperature (double height) {
  /*
    h1(km)   h2(km) 	dT/dh (K/km)
    0 	11 	-6.5
    11 	20 	0.0
    20 	32 	1.0
    32 	47 	2.8
    47 	51 	0.0
    51 	71 	-2.8
    71 	84.852 	-2.0

    Note: 84.852 km geopotential=86 km geometric

    These data along with the sea level standard values of
    Sea level pressure = 101325 N/m2
    Sea level temperature = 288.15 K
    Hydrostatic constant = 34.1631947 kelvin/km
    define the atmosphere. The sea level density of 1.225 kg/m3 is 
    derived from the fundamental quantities above
  */

  double temp = 288.15*Kelvin;

  if (height < 11*km) {

    temp += -6.5*(Kelvin/km) * height;
	
  } else if (height < 20*km) {

    temp += -6.5*(Kelvin/km) * 11*km;

  } else if (height < 32*km) {

    temp += -6.5*(Kelvin/km) * 11*km
      + 1.0*(Kelvin/km) * (height-20*km);

  } else if (height < 47*km) {

    temp += -6.5*(Kelvin/km) * 11*km
      + 1.0*(Kelvin/km) * (32*km-20*km)
      + 2.8*(Kelvin/km) * (height-32*km);

  } else if (height < 51*km) {

    temp += -6.5*(Kelvin/km) * 11*km
      + 1.0*(Kelvin/km) * (32*km-20*km)
      + 2.8*(Kelvin/km) * (47*km-32*km);

  } else if (height < 71*km) {

    temp += -6.5*(Kelvin/km) * 11*km
      + 1.0*(Kelvin/km) * (32*km-20*km)
      + 2.8*(Kelvin/km) * (47*km-32*km)
      - 2.8*(Kelvin/km) * (height-51*km);

  } else if (height < 84.852*km) {

    temp += -6.5*(Kelvin/km) * 11*km
      + 1.0*(Kelvin/km) * (32*km-20*km)
      + 2.8*(Kelvin/km) * (47*km-32*km)
      - 2.8*(Kelvin/km) * (71*km-51*km)
      - 2.0*(Kelvin/km) * (height-71*km);

  } else {

    temp += -6.5*(Kelvin/km) * 11*km
      + 1.0*(Kelvin/km) * (32*km-20*km)
      + 2.8*(Kelvin/km) * (47*km-32*km)
      - 2.8*(Kelvin/km) * (71*km-51*km)
      - 2.0*(Kelvin/km) * (84.852*km-71*km);

  }

  return temp;
	
}
