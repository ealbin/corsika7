#include <crsIO/TParticle.h>
using namespace crsIO;

#include <crs/MParticle.h>
#include <crs/CParticle.h>
#include <crs/CorsikaConsts.h>
#include <crs/MEventHeader.h>

#include <iostream>
#include <cmath>

using namespace std;

// -----------------
ClassImp(TParticle);


TParticle::TParticle (const crs::MParticle &right) {

  // CONVERT here ------------------
  ParticleID = right.GetParticleID ();
  HadronicGeneration = right.GetHadronicGeneration ();
  ObservationLevel = right.GetObservationLevel ();
  CorsikaID = ParticleID*1000+(HadronicGeneration%100)*10+ObservationLevel;
  
  Px = right.GetPx ();
  Py = right.GetPy ();
  Pz = right.GetPz ();
  
  x = right.GetX ();
  y = right.GetY ();
  Time = right.GetTime ();

  Weight = right.GetWeight ();
}

TParticle::TParticle (const crs::MEventHeader &header , const crs::CParticle &p) {

  HadronicGeneration = p.GetHadronicGeneration();
  ObservationLevel = p.GetObservationLevel();
  ParticleID = p.GetParticleId();
  CorsikaID = p.GetCorsikaId();

  crs::Coordinates newCoordinates = p.TransformCoordinates(header);
  Px = newCoordinates.Px;
  Py = newCoordinates.Py;
  Pz = newCoordinates.Pz;
  x =  newCoordinates.x;
  y =  newCoordinates.y;
  
  Time = p.GetTime();
  Weight = p.GetWeight();
  
  /*  if (header.GetFlagExtraMuonInformation()) {
      cout << "TParticle with additionnal muon information not yet implemented !! " << endl;
      }*/
  
  /*  
  ParticleID = int(p.particleID);
  HadronicGeneration = 0;
  ObservationLevel = 0;
  CorsikaID = ParticleID*1000+(HadronicGeneration%100)*10+ObservationLevel;
  double ETOT = p.energy;
  double PAMA = crs::gParticleMass[ParticleID];
  double PTOT = sqrt( (ETOT-PAMA)*(ETOT+PAMA) ) ;
  double STT  = sqrt( (1.-p.cosTheta)*(1.+p.cosTheta) );
  double PHIPAR ;
  if ( p.cosPhiY != 0.  ||  p.cosPhiX != 0. ) {
    PHIPAR = atan2( p.cosPhiY ,p.cosPhiX ); }
  else {
    PHIPAR = 0. ;} 

  double ARRANG = header.GetArrayRotation();
  double COSANG = cos(ARRANG);
  double SINANG = sin(ARRANG);

  Px = PTOT * STT * cos( PHIPAR + ARRANG );  
  Py = PTOT * STT * sin( PHIPAR + ARRANG );
  Pz = PTOT * p.cosTheta;

  x = p.x * COSANG + p.y * SINANG;
  y = p.y * COSANG - p.x * SINANG;

  Time = p.time * 1.E9;  //convert s to ns

  Weight = p.weight;
  */
}

TParticle::TParticle () :
    
  CorsikaID (0),
  ParticleID (0),
  ObservationLevel (0),
  HadronicGeneration (0),
  Px (0),
  Py (0),
  Pz (0),
  x (0),
  y (0),
  Time (0),
  Weight (0) {
}

