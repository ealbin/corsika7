/* $Id: CParticle.h,v 1.5 2007-10-24 10:13:31 pierog Exp $   */


#ifndef _INCLUDE_CPARTICLE_H__
#define _INCLUDE_CPARTICLE_H__

#include <crs/CorsikaTypes.h>
// #include <crs/MParticle.h> does not work so good

/*
  This is the CORSIKA internal particle definition:

  C  curpar(0)   = phix,    DIRECTION COSINE X-DIRECTION
  C  CURPAR(1)   = PARTICLE TYPE
  C  CURPAR(2)   = GAMMA,  LORENTZ FACTOR IN LAB
  C  CURPAR(3)   = COSTHE, COSINE THETA
  C  CURPAR(4)   = PHI,    PHI
  CCCC  curpar(4)   = phiy,   DIRECTION COSINE Y-DIRECTION     ????????????????
  C  CURPAR(5)   = H,      HEIGHT (TRUE HEIGHT)
  C  CURPAR(6)   = T,      ACCUMULATED TIME IN SEC
  C  CURPAR(7)   = X,      X-POSITION
  C  CURPAR(8)   = Y,      Y-POSITION
  C  CURPAR(9)   = CHI,    PENETRATED MATERIAL UNTIL DECAY OR REACTION
  C                (G/CM**2)  CALCULATED IN BOX2
  C  CURPAR(10)  = BETA,   V/C, CALCULATED IN BOX2
  C  CURPAR(11)  = GCM,    GAMMA  IN CM, CALCULATED IN NUCINT
  C  CURPAR(12)  = ECM,    ENERGY IN CM, CALCULATED IN NUCINT
  +IF, THIN.
  C  CURPAR(13)  = WEIGHT, WEIGHT FOR THINNING
  +ENDIF.
  +IF, CURVED.
  C  CURPAR(14)  = HAPP    APPARENT HEIGHT  IN CARTESIAN COORDINATE SYSTEM
  C  CURPAR(15)  = COSTAP  APPARENT ZENITH ANGLE IN CART.COORDINATE SYSTEM
  C  CURPAR(16)  = COSTEA  ANGLE PARTICLE TO MID DETECT AT CENTER EARTH
  +ENDIF.
  +IF, INTTEST.
  C  CURPAR(17)  = TRANSVERSE MOMENTUM


  In fact the array always has a length of 16 only in the INTTEST it is 
  increased to 17. But the data is only partly filled according to the CORSIKA
  program settings.
  
*/

namespace crs {

  class MEventHeader;
  
  struct Coordinates {
    Coordinates(double thepx=0, double thepy=0, double thepz=0, double thex=0, double they=0) 
      : Px(thepx), Py(thepy), Pz(thepz), x(thex), y(they) {}
    double Px;
    double Py;
    double Pz;
    double x;
    double y;
  };
  
  struct CParticle {
	
  public:
    CParticle() : 
         particleID(0),
	 x(0),
	 y(0),
	 z(0),
	 depth(0),
	 cosTheta(0),
	 cosPhiX(0),
	 cosPhiY(0),
	 time(0),
	 energy(0),
	 weight(0) {}
    void Dump () const;
    // MParticle TransformParticle(const crs::MEventHeader& header) const; does not work so well

  public:
	   
    CDOUBLEPRECISION particleID;
    CDOUBLEPRECISION x;
    CDOUBLEPRECISION y;
    CDOUBLEPRECISION z;
    CDOUBLEPRECISION depth;
    CDOUBLEPRECISION cosTheta;
    CDOUBLEPRECISION cosPhiX;
    CDOUBLEPRECISION cosPhiY;
    CDOUBLEPRECISION time;
    CDOUBLEPRECISION energy;
    CDOUBLEPRECISION weight;
    
    
    int GetParticleId() const { return (int)particleID; }
    int GetHadronicGeneration() const { return 0; }
    int GetObservationLevel() const { return 1; }
    int GetCorsikaId() const { return GetParticleId() * 1000 + (GetHadronicGeneration()%100) * 10 + GetObservationLevel();}
    double GetTime() const { return time * 1.e9; } // convert s to ns
    double GetWeight() const { return weight; } 
    Coordinates TransformCoordinates(const crs::MEventHeader& header) const;


    /*
      CDOUBLEPRECISION cosPhiX;
      CDOUBLEPRECISION particleID;
      CDOUBLEPRECISION gamma;
      CDOUBLEPRECISION cosTheta;
      CDOUBLEPRECISION phi;
      //CDOUBLEPRECISION cosPhiY;        ~~~~~~~~~
      CDOUBLEPRECISION height;
      CDOUBLEPRECISION time;
      CDOUBLEPRECISION x;
      CDOUBLEPRECISION y;
      CDOUBLEPRECISION chi;
      CDOUBLEPRECISION beta;
      CDOUBLEPRECISION gammaCM;
      CDOUBLEPRECISION energyCM;
      CDOUBLEPRECISION weight;
      CDOUBLEPRECISION heightApp;
      CDOUBLEPRECISION cosThetaApp;
      CDOUBLEPRECISION cosToCenterEarth;
      // CDOUBLEPRECISION p_t;   // for INTTEST
      */
  };

};


#endif
