/* $Id: MCerenkov.cc,v 1.1.1.1 2007-07-31 07:00:52 rulrich Exp $   */

#include <crs/MCerenkov.h>
#include <crs/TParticleBlockEntry.h>
using namespace crs;

#include <iostream>
#include <string>



MCerenkov::MCerenkov (const float *data, bool thinned) :
TParticleBlockEntry (data,  thinned ) {
}

MCerenkov::MCerenkov (const TParticleBlockEntry &p) :
TParticleBlockEntry (p) {
}

void MCerenkov::Dump () const {
    
  std::cout << *this
	    << std::endl;
}

 
std::string MCerenkov::GetParticleName () const {

  return std::string ("cerenkov");
}

