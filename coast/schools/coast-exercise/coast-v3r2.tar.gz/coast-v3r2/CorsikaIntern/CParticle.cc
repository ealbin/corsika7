/* $Id: CParticle.cc,v 1.3 2007-10-24 10:13:31 pierog Exp $   */

#include <crs/CParticle.h>
#include <crs/CorsikaConsts.h>
#include <crs/MEventHeader.h>

#include <iostream>

using namespace crs;
using namespace std;


void CParticle::Dump () const {

  cout << "ID: " << (int)particleID 
       << " energy " << energy
       << " x: " << x 
       << " y: " << y 
       << " h: " << z
       << " depth: " << depth
       << " t: " << time  
       << " w: " << weight
       << endl;
}


/*  nice try ...
MParticle TransformParticle(const crs::MEventHeader& header) const {
  
  CREAL* newParticleData = 
  
  return particle(newParticleData, header.IsThinned());
}
*/



crs::Coordinates CParticle::TransformCoordinates(const crs::MEventHeader& header) const {
  
  double ETOT = energy;
  double PAMA = crs::gParticleMass[GetParticleId()];
  double PTOT = sqrt( (ETOT-PAMA)*(ETOT+PAMA) ) ;
  double STT  = sqrt( (1.-cosTheta)*(1.+cosTheta) );
  double PHIPAR = 0;
  if ( cosPhiY != 0.  ||  cosPhiX != 0. ) {
    PHIPAR = atan2( cosPhiY, cosPhiX ); 
  } 
  
  double ARRANR = header.GetArrayRotation();
  double COSANG = cos(ARRANR);
  double SINANG = sin(ARRANR);
  
  return crs::Coordinates(PTOT * STT * cos( PHIPAR + ARRANR ), // Px
			  PTOT * STT * sin( PHIPAR + ARRANR ), // Py
			  PTOT * cosTheta,                     // Pz
			  x * COSANG + y * SINANG,             // x 
			  y * COSANG - x * SINANG);            // y
}

