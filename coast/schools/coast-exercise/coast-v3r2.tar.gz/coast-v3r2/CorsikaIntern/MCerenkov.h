#ifndef _INCLUDE_CORSIKA_MCERENKOV_
#define _INCLUDE_CORSIKA_MCERENKOV_


#include <crs/CorsikaTypes.h>
#include <crs/TParticleBlockEntry.h>

#include <ostream>


namespace crs {

  /** 
      \class MCerenkov
      \brief CORSIKA Cerenkov data

      One CORSIKA Cerenkov-bunch data object.

      \author Ralf Ulrich
      \date Thu Feb  3 13:04:50 CET 2005
      \version $Id: MCerenkov.h,v 1.1.1.1 2007-07-31 07:00:52 rulrich Exp $
  */

  class MCerenkov : public TParticleBlockEntry {

  public:
    MCerenkov (const CREAL *data, bool fThinned);
    MCerenkov (const TParticleBlockEntry &p);

    virtual void Dump () const;
	
  public:
    CREAL GetPhotonsInBunch () const 
    {return (fData [0]-99.e5)/10.;}
	
    CREAL GetX () const {return fData [1];} 
    CREAL GetY () const {return fData [2];}

    CREAL GetU () const {return fData [3];}
    CREAL GetV () const {return fData [4];}

    CREAL GetTime () const {return fData [5];}
	
    CREAL GetProductionHeight () const {return fData [6];}
	
    CREAL GetWeight () const {return (fThinned ? fData [7] : 1);}


  public:
    virtual std::string GetParticleName () const;
  };


  inline std::ostream &operator<< (std::ostream &o, const MCerenkov &p) {

    o << " ckov: " << p.GetPhotonsInBunch ()
      << " x: " << p.GetX ()
      << " y: " << p.GetY ()
      << " u: " << p.GetU () 
      << " v: " << p.GetV ()
      << " t: " << p.GetTime () 
      << " w: " << p.GetWeight ();
	
    return o;
	
  }

};    

#endif
