/* $Id: MParticleSubBlockOutput.cc,v 1.1 2007-10-19 11:13:40 rulrich Exp $   */


#include <crs/MEventHeader.h>

#include <crsRead/MParticleSubBlockOutput.h>

using namespace crsRead; 

/*
  MParticleSubBlockOutput::MParticleSubBlockOutput () 
  : TSubBlockIO(),
  fParticleWriteIndex(0) {
  }
*/


MParticleSubBlockOutput::MParticleSubBlockOutput (bool thinned, int AdditionalCharacters, 
						  const crs::MEventHeader& header) 
: TSubBlockIO(thinned, AdditionalCharacters),
  fParticleWriteIndex(crs::TBlock::fgNParticles),  // <- this is needed to initiate proper writing
  fEventHeader(&header) {                     // <- this is for particle coordinate transformations
}

