/**
   \file MParticleSubBlockOutput.h                                      

   Enables the writing of individual particles into CORSIKA subblocks
   
   \author Ralf Ulrich 
   \date Fri Oct 19 10:43:17 CEST 2007
   \version $Id: MParticleSubBlockOutput.h,v 1.2 2007-10-19 16:11:32 rulrich Exp $ 

*/


#ifndef _INCLUDE_MParticleSubBlockOutput_H_
#define _INCLUDE_MParticleSubBlockOutput_H_

#include <crsRead/TSubBlockIO.h>

#include <crs/CorsikaTypes.h>
#include <crs/TBlock.h>
#include <crs/CParticle.h>

#include <fstream>
#include <iostream>

namespace crs {
  class MEventHeader;
};


namespace crsRead {

  /**
     
     \class MParticleSubBlockOutput
     \brief Class to write individual particles into subblocks
     
  */


  class MParticleSubBlockOutput : public TSubBlockIO {
    
    // friend inline std::ofstream& operator<<(std::ofstream& ,MParticleSubBlockOutput&);
    friend inline MParticleSubBlockOutput& operator<<(MParticleSubBlockOutput&, const crs::CParticle& p);
    
  public:
    // MParticleSubBlockOutput();                                ///< Default constructor
    MParticleSubBlockOutput(bool Thinned, int NBlockSizeInfo, const crs::MEventHeader& header);
    
    bool IsFull() const {return fParticleWriteIndex>=crs::TBlock::fgNParticles;}
    
  private:
    MParticleSubBlockOutput(const MParticleSubBlockOutput&);                ///< copy constructor
    MParticleSubBlockOutput& operator=(const MParticleSubBlockOutput &sb);
    
  protected:
    int    fParticleWriteIndex;
    
    const crs::MEventHeader* fEventHeader;
  };
  
  
  
  /**
     \fn inline ofstream& operator<<( ofstream& s, MParticleSubBlockOutput& b)
     \brief Corsika data file streaming operator

     This function defines the operator<< to stream out CORSIKA sub-blocks
     into binary files.
       
     \author Ralf Ulrich
     \date Tue Jun 14 17:45:10 CEST 2005
     \version $Id: MParticleSubBlockOutput.h,v 1.2 2007-10-19 16:11:32 rulrich Exp $
  */
  inline MParticleSubBlockOutput& operator<<(MParticleSubBlockOutput& b, const crs::CParticle& p) {
    
    if (b.IsFull()) {
      /* std::cerr << "MParticleSubBlockOutput::ERROR trying to add more than " << crs::TBlock::fgNParticles 
		<< " to particle subblock! Check your code! " 
		<< std::endl;*/
      for (int i=0; i<b.fBlockSize; ++i) { ((CREAL*)b.fSubBlockData)[i] = 0; }
      b.fParticleWriteIndex = 0;
    }
    
    const int writeIndex = b.fParticleWriteIndex 
      * (b.fThinned ? crs::TBlock::fgNEntriesThinned : crs::TBlock::fgNEntriesNotThinned );
    
    CREAL* particleData = &(((CREAL*)b.fSubBlockData)[writeIndex]);
    
    crs::Coordinates newCoordinates = p.TransformCoordinates(*b.fEventHeader);
    particleData[0] = p.GetCorsikaId();
    particleData[1] = newCoordinates.Px;
    particleData[2] = newCoordinates.Py;
    particleData[3] = newCoordinates.Pz;
    particleData[4] = newCoordinates.x;
    particleData[5] = newCoordinates.y;
    particleData[6] = p.GetTime();
    if (b.fThinned) {
      particleData[7] = p.GetWeight();
    }
    
    b.fParticleWriteIndex++;
    
    return b;
  }
    
};


#endif
