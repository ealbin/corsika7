#ifndef _INCLUDE_CORSIAKIO_TCERENKOV_
#define _INCLUDE_CORSIAKIO_TCERENKOV_

#include <TObject.h>

namespace crs {
  class MCerenkov;
};


namespace crsIO {

  /** 
      \class TCerenkov
      \brief One Cerenkov bunch info.

      One Cerenkov bunch. 

      \author Ralf Ulrich
      \date Thu Feb  3 13:04:50 CET 2005
      \version $Id: TCerenkov.h,v 1.1.1.1 2005/08/09 11:21:28 rulrich Exp $
  */

  class TCerenkov : public TObject {

  public:
    TCerenkov (const crs::MCerenkov &ckov);
    TCerenkov ();

    float nPhotons; // Number of photons in this bunch
	
    float x; // cm
    float y; // cm
	
    float u; // direction cosine to x axis
    float v; // direction cosine to y axis
	
    float Time; // time since first interction   
	
    float ProductionHeight; // production height

    float Weight; // bunch weight
	
    ClassDef (TCerenkov, 1)
  };
};

#endif

