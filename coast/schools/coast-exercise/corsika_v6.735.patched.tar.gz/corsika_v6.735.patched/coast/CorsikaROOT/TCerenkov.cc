/* $Id: TCorsikaReader.cc,v 1.1.1.1 2005/08/09 11:21:28 rulrich Exp $   */

#include <crsIO/TCerenkov.h>
using namespace crsIO;

#include <crs/MCerenkov.h>


// -----------------
ClassImp (TCerenkov)

TCerenkov::TCerenkov (const crs::MCerenkov &ckov) {

  nPhotons = ckov.GetPhotonsInBunch ();
  x = ckov.GetX ();
  y = ckov.GetY ();

  u = ckov.GetU ();
  v = ckov.GetV ();
  Time = ckov.GetTime ();
  ProductionHeight = ckov.GetProductionHeight ();

  Weight = ckov.GetWeight ();
}


TCerenkov::TCerenkov () :
nPhotons (0),
  x (0),
  y (0),
  u (0),
  v (0),
  Time (0),
  ProductionHeight (0),
  Weight (0) {
}

