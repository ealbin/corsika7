#include <crsIO/TParticle.h>
using namespace crsIO;

#include <crs/MParticle.h>


// -----------------
ClassImp (TParticle)


TParticle::TParticle (const crs::MParticle &right) {

  // CONVERT here ------------------
  ParticleID = right.GetParticleID ();
  HadronicGeneration = right.GetHadronicGeneration ();
  ObservationLevel = right.GetObservationLevel ();
    
  Px = right.GetPx ();
  Py = right.GetPy ();
  Pz = right.GetPz ();

  x = right.GetX ();
  y = right.GetY ();
  Time = right.GetTime ();

  Weight = right.GetWeight ();
}


TParticle::TParticle () :
    
ParticleID (0),
  ObservationLevel (0),
  HadronicGeneration (0),
  Px (0),
  Py (0),
  Pz (0),
  x (0),
  y (0),
  Time (0),
  Weight (0) {
}

