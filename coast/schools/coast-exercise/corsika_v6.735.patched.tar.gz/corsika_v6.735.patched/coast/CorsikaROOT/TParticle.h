#ifndef _INCLUDE_CORSIKAIO_TPARTICLE_
#define _INCLUDE_CORSIKAIO_TPARTICLE_

#include <TObject.h>

namespace crs {
  class MParticle;
};

namespace crsIO {

  /** 
      \class TParticle
      \brief One Particle-info.

      One Particle. This class also provides simple conversion algorithms. 

      \author Ralf Ulrich
      \date Thu Feb  3 13:04:50 CET 2005
      \version $Id: TParticle.h,v 1.1.1.1 2006/02/21 15:28:05 rulrich Exp $
  */

  class TParticle : public TObject {
    
  public:
    TParticle (const crs::MParticle &right);
    TParticle ();

    unsigned char ParticleID;
    unsigned char ObservationLevel;
    unsigned char HadronicGeneration;
    
    float Px;
    float Py;
    float Pz;
    
    float x;
    float y;
    
    float Time;
    float Weight;
    
    ClassDef (TParticle, 3);
  };
};


#endif
