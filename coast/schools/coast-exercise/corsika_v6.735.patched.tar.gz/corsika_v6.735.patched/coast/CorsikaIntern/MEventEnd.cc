/* $Id: TCorsikaReader.cc,v 1.1.1.1 2005/08/09 11:21:28 rulrich Exp $   */

#include <crs/MEventEnd.h>
using namespace crs;

MEventEnd::MEventEnd (const TSubBlock &right) {

  // ctor
  fSubBlockData = right.fSubBlockData;
  fType = right.fType;
  fThinned = right.fThinned;
}

