#ifndef _INCLUDE_CORSIKA_IPARTICLEREADOUT_
#define _INCLUDE_CORSIKA_IPARTICLEREADOUT_

#include <crs/CorsikaTypes.h>


namespace crs {

  /** 
      \class IParticleReadout
      \brief CORSIKA common particle data readout interface

      One CORSIKA particle definition.

      \author Ralf Ulrich
      \date Sun Jun 19 12:06:45 CEST 2005
      \version $Id: IParticleReadout.h,v 1.1.1.1 2005/08/09 11:21:27 rulrich Exp $
  */

  class IParticleReadout {
	
  public:
    IParticleReadout () {}
    virtual ~IParticleReadout () {}


    virtual int GetObservationLevel () const 
    {return int (ValueAt (0))%10;}
    virtual int GetHadronicGeneration () const
    {return (int (ValueAt(0))%1000)/10;}
	

    virtual CREAL GetPx () const {return ValueAt (1);}
    virtual CREAL GetPy () const {return ValueAt (2);}
    virtual CREAL GetPz () const {return ValueAt (3);}
	
    virtual CREAL GetX () const {return ValueAt (4);}
    virtual CREAL GetY () const {return ValueAt (5);}
	

  public:
    float GetMass () const;         ///< mass in GeV
    int GetPDGCode () const;
    float GetKinEnergy () const;    ///< kin. energy in GeV
    float GetTheta () const;        ///< zenith angle in rad
	
  private:
    virtual CREAL ValueAt (int i) const = 0;

  };
    
    
    
};    



#endif
