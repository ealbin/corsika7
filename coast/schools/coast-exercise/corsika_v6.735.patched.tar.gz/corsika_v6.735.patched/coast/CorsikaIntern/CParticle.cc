/* $Id: TCorsikaReader.cc,v 1.1.1.1 2005/08/09 11:21:28 rulrich Exp $   */

#include <crs/CParticle.h>
using namespace crs;

#include <iostream>
using namespace std;


void CParticle::Dump () const {

  cout << "ID: " << (int)particleID 
       << " energy " << energy
       << " x: " << x 
       << " y: " << y 
       << " h: " << z
       << " depth: " << depth
       << " t: " << time  
       << " w: " << weight
       << endl;
}


