/* $Id: TCorsikaReader.cc,v 1.1.1.1 2005/08/09 11:21:28 rulrich Exp $   */

#include <crs/MEventHeader.h>
using namespace crs;

MEventHeader::MEventHeader (const TSubBlock &right) {

  // ctor
  fSubBlockData = right.fSubBlockData;
  fType = right.fType;
  fThinned = right.fThinned;
}
