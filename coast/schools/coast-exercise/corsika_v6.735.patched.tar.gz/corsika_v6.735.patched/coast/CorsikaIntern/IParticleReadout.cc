/* $Id: TCorsikaReader.cc,v 1.1.1.1 2005/08/09 11:21:28 rulrich Exp $   */

#include <crs/CorsikaConsts.h>
#include <crs/IParticleReadout.h>
using namespace crs;

#include <cmath>



float IParticleReadout::GetMass () const {

  int id = (int)ValueAt (0)/1000;
  if (id>0 && id<=gNParticles) 
    return gParticleMass [id-1];
    
  return -1;	    
}



int IParticleReadout::GetPDGCode () const {
    
  int id = (int)ValueAt (0)/1000;
  if (id>0 && id<=gNParticles)
    return gParticleCodes [id-1];
	
  return -1;
}



float IParticleReadout::GetKinEnergy () const {

  float Px = GetPx ();
  float Py = GetPy ();
  float Pz = GetPz ();
  double P2 = Px*Px + Py*Py + Pz*Pz;

  return std::sqrt (P2);
}


float IParticleReadout::GetTheta () const {
    
  return acos (GetPz ()/GetKinEnergy ());
}
