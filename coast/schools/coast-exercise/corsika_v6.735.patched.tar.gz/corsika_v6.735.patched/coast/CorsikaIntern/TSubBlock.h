#ifndef _INCLUDE_CORSIKA_TSUBBLOCH_H_
#define _INCLUDE_CORSIKA_TSUBBLOCH_H_

#include <crs/CorsikaTypes.h>

#include <string>

namespace crsRead {
  class TSubBlock;
}


namespace crs {

  class MRunHeader;
  class MRunEnd;
  class MEventHeader;
  class MEventEnd;
  class MParticleBlock;
  class MLongitudinalBlock;

  /** 
      \class TSubBlock
      \brief One CORSIKA sub-block, the container for all data

      All data is comming in sub-blocks of different types, that are
      encoded in the first REAL*4 of a sub-block. A sub-block is 
      able to contain 39 particles. The number of REAL*4 per particle is
      7 for normal CORSIKA but 8 for thinned CORSIKA.

      \author Ralf Ulrich
      \date Thu Feb  3 13:04:50 CET 2005
      \version $Id: TSubBlock.h,v 1.1.1.1 2005/08/09 11:21:26 rulrich Exp $
  */

  class TSubBlock {

    //friend class crsRead::TSubBlock;
	
    friend class MRunHeader;
    friend class MRunEnd;
    friend class MEventHeader;
    friend class MEventEnd;
    friend class MParticleBlock;
    friend class MLongitudinalBlock;
	
  public:

    typedef enum { 
      eRUNH, 	// Run Header
      eEVTH, 	// Event Header
      ePARTDATA,  // Particle Block
      eLONG,      // Longitudinal Block
      eEVTE, 	// Event End
      eRUNE, 	// Run End
      eNODATA     // empty SubBlock
    } SubBlockType;
	
    
    TSubBlock () : fSubBlockData (0), fType (eNODATA), fThinned (false) {}
    TSubBlock (const TSubBlock &);
    TSubBlock (const CREAL *subblockdata, bool thinned);
    virtual ~TSubBlock () {}

    SubBlockType GetBlockType () const {return fType;}
    std::string GetBlockTypeName () const;
    bool IsThinned () const {return fThinned;}

  private:
    //void operator= (const TSubBlock &);

  protected:  
    void FindBlockType ();// crsRead::TSubBlockIO also needs this !

  protected:
    const CREAL *fSubBlockData;
    SubBlockType fType;
    bool fThinned;

    static const std::string fgRunStart;
    static const std::string fgRunEnd;
    static const std::string fgEventStart;
    static const std::string fgEventEnd;
    static const std::string fgLongitudinal;
	
    static const int fgMaxObsLevels;
  };

};

#endif
