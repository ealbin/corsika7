/** @file listio.c
    @short Main function for listing data consisting of eventio blocks.

    The item type, version, length and ident are displayed.
    With command line option '-s' all sub-items are shown
    as well.
    Input is from standard input by default, output to standard output.

@verbatim
    Syntax: listio [-s[n]] [-p] [filename]
    List structure of eventio data files.
       -s : also list contained (sub-) items
       -sn: list sub-items up to depth n (n=0,1,...)
       -p : show positions of items in the file
    If no file name given, standard input is used.
@endverbatim

*/

/** @defgroup listio_c The listio program */
/** @{ */

#include "initial.h"
#include "io_basic.h"
#include "fileopen.h"

/** 
 * @short Main function 
 *
 * The main function of the listio program.
 */

#ifdef ANSI_C
int main (int argc, char **argv)
#else
int main (argc, argv)
   int argc;
   char **argv;
#endif
{
   int sub, show_pos;
   IO_BUFFER *iobuf;
   IO_ITEM_HEADER item_header;
#if defined(__USE_LARGEFILE64)
   off64_t pos = 0;
#else
   long pos = 0;
#endif
   FILE *input;

   sub = -1;
   show_pos = 0;
   while ( argc >= 2 )
   {
      if ( argv[1][0] != '-' )
         break;
      if ( strncmp(argv[1],"-s",2) == 0 )
      {
         if ( strlen(argv[1]) > 2 )
            sub = atoi(argv[1]+2);
         else
            sub = 20;
      }
      else if ( strncmp(argv[1],"-p",2) == 0 )
      {
         show_pos = 1;
      }
      else
      {
         fprintf(stderr,"Syntax: listio [-s[n]] [-p] [filename]\n");
         fprintf(stderr,"List structure of eventio data files.\n");
         fprintf(stderr,"   -s : also list contained (sub-) items\n");
         fprintf(stderr,"   -sn: list sub-items up to depth n (n=0,1,...)\n");
         fprintf(stderr,"   -p : show positions of items in the file\n");
         fprintf(stderr,"If no file name given, standard input is used.\n");
         exit(1);
      }
      argc--;
      argv++;
   }
   if ( (iobuf = allocate_io_buffer(1000)) == (IO_BUFFER *) NULL )
      exit(1);
   iobuf->max_length = 128000000;
   if ( argc > 1 )
   {
      if ( (input = fileopen(argv[1],READ_BINARY)) == (FILE *) NULL )
      {
         perror(argv[1]);
         exit(1);
      }
      iobuf->input_file = input;
   }
   else
      iobuf->input_file = stdin;
   
   if ( show_pos && sub < 0 )
      sub = 0;

   if ( sub < 0 )
      (void) list_io_blocks(iobuf);
   else
      while ( find_io_block(iobuf,&item_header) >= 0 )
      {
         if ( show_pos )
	 {
#if defined(__USE_LARGEFILE64)
            pos = ftello64(iobuf->input_file) - 16;
#else
            pos = ftell(iobuf->input_file) - 16;
#endif
         }
         if ( read_io_block(iobuf,&item_header) < 0 )
            break;
         list_sub_items(iobuf,&item_header,sub);
         if ( show_pos )
         {
            fflush(NULL);
#if defined(__USE_LARGEFILE64)
            if (sizeof(pos) > sizeof(long))
               printf("(I/O block started at byte offset %lld)\n",(long long)pos);
            else
               printf("(I/O block started at byte offset %ld)\n",(long)pos);
#else
            printf("(I/O block started at byte offset %ld)\n",pos);
#endif
         }
      }

   exit(0);
   return 0;
}

#ifdef OS_OS9
int perror(text)
    char *text;
{
    fprintf(stderr,"%s: Error\n",text);
    return 0;
}
#endif

/** @} */
