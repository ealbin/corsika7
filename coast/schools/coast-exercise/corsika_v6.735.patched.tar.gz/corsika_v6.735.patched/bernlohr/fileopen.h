/** @file fileopen.h
 *  @short Function prototypes for fileopen.c.
 *
 *  @author  Konrad Bernloehr 
 *  @date    CVS $Date: 2003/04/30 18:10:12 $
 *  @version CVS $Revision: 1.3 $
 */

#ifndef FILEOPEN_H__LOADED
#define FILEOPEN_H__LOADED 1

#ifdef __cplusplus
extern "C" {
#endif

/* fileopen.c */
void initpath(const char *default_path);
void listpath (char *buffer, int bufsize);
void addpath(const char *name);
FILE *fileopen(const char *fname, const char *mode);
int fileclose(FILE *f);

#ifdef __cplusplus
}
#endif

#endif
