void sample_offset (char *sampling_fname, double core_range, 
   double theta, double phi, 
   double thetaref, double phiref, double offax, 
   double E, int primary,
   double *xoff, double *yoff, double *sampling_area);
