#ifndef STRAUX_H__LOADED

#define STRAUX_H__LOADED 1

/*---------------------------------------------------------------------*/
/* PROTOTYPES */

#ifdef __cplusplus
extern "C" {
#endif

#ifdef ANSI_C

#ifndef CONST
# define CONST const
#endif

int abbrev (CONST char *s, CONST char *t);
int getword (CONST char *s, int *spos, char *word, int maxlen, char blank,
             char endchar);
int stricmp (CONST char *a, CONST char *b);


#endif

#ifdef __cplusplus
}
#endif

#endif
