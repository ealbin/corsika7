/* ========================================================= */
/** @file mc_tel.h 
 *  @short Definitions and structures for CORSIKA Cherenkov light interface.
 *
 *  This file contains definitions of data structures and of
 *  function prototypes as needed for the Cherenkov light
 *  extraction interfaced to the modified CORSIKA code.
 *
 *  @author  Konrad Bernloehr 
 *  @date    1997
 *  @date    CVS $Date: 2003/11/12 19:22:55 $
 *  @version CVS $Revision: 1.5 $
 */
/* ========================================================= */

/* SccsId: "%W%   %G%" */

#ifndef _MC_TEL_LOADED

#define _MC_TEL_LOADED 1

#ifndef _EVENTIO_BASIC_LOADED
# include "io_basic.h"
#endif

#ifndef ARGLIST
#if defined(__STDC__) || defined(__cplusplus) || defined(ANSI_C)
# define ARGLIST(s) s
#else
# define ARGLIST(s) ()
#endif
#define _remove_ARGLIST_ 1
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* Data types: */

#ifdef DOUBLEPREC
typedef double real;
#else
typedef float real;
#endif

typedef short INT16;
typedef unsigned short UINT16;
#ifdef OS_MSDOS
typedef long INT32;
typedef unsigned long UINT32;
#else
typedef int INT32;
typedef unsigned int UINT32;
#endif

/* Data structures: */
/**
 * Photons collected in bunches of identical direction, position, time,
 * and wavelength. The wavelength will normally be unspecified as
 * produced by CORSIKA (lambda=0).
*/

struct bunch
{
   float photons; /**< Number of photons in bunch */
   float x, y;    /**< Arrival position relative to telescope (cm) */
   float cx, cy;  /**< Direction cosines of photon direction */
   float ctime;   /**< Arrival time (ns) */
   float zem;     /**< Height of emission point above sea level (cm) */
   float lambda;  /**< Wavelength in nanometers or 0 */
};

/**
 *  The compact_bunch struct is equivalent to the bunch struct
 *  except that we try to use less memory.
 *  And that has a number of limitations:
 *  1) Bunch sizes must be less than 327.
 *  2) photon impact points in a horizontal plane through the centre
 *     of each detector sphere must be less than 32.7 m from the
 *     detector centre in both x and y coordinates. Thus,
 *        sec(z) * R < 32.7 m 
 *     is required, with 'z' being the zenith angle and 'R' the radius
 *     of the detecor sphere. When accounting for multiple scattering
 *     and Cherenkov emission angles, the actual limit is reached 
 *     even earlier than that.
 *  3) Only times within 3.27 microseconds from the time, when the 
 *     primary particle propagated with the speed of light would cross
 *     the altitude of the sphere centre, can be treated.
 *     For large zenith angle observations this limits horizontal
 *     core distances to about 1000 m.
 *  For efficiency reasons, no checks are made on these limits.
 */

struct compact_bunch
{
   short photons; /**< ph*100 */
   short x, y;    /**< x,y*10 (mm) */
   short cx, cy;  /**< cx,cy*30000 */
   short ctime;   /**< ctime*10 (0.1ns) after subtracting offset */
   short log_zem; /**< log10(zem)*1000 */
   short lambda;  /**< (nm) or 0 */
};

/** A photo-electron produced by a photon hitting a pixel. */

struct photo_electron
{
   int pixel;     /**< The pixel that was hit. */
   int lambda;    /**< The wavelength of the photon. */
   double atime;  /**< The time [ns] when the photon hit the pixel. */
};

/** The linked_string is mainly used to keep CORSIKA input. */

struct linked_string
{
   char *text;
   struct linked_string *next;
};

/* I/O item types: */

/* Never change the following numbers after MC data is created: */
#define IO_TYPE_MC_BASE     1200
#define IO_TYPE_MC_RUNH     (IO_TYPE_MC_BASE+0)
#define IO_TYPE_MC_TELPOS   (IO_TYPE_MC_BASE+1)
#define IO_TYPE_MC_EVTH     (IO_TYPE_MC_BASE+2)
#define IO_TYPE_MC_TELOFF   (IO_TYPE_MC_BASE+3)
#define IO_TYPE_MC_TELARRAY (IO_TYPE_MC_BASE+4)
#define IO_TYPE_MC_PHOTONS  (IO_TYPE_MC_BASE+5)
#define IO_TYPE_MC_LAYOUT   (IO_TYPE_MC_BASE+6)
#define IO_TYPE_MC_TRIGTIME (IO_TYPE_MC_BASE+7)
#define IO_TYPE_MC_PE       (IO_TYPE_MC_BASE+8)
#define IO_TYPE_MC_EVTE     (IO_TYPE_MC_BASE+9)
#define IO_TYPE_MC_RUNE     (IO_TYPE_MC_BASE+10)
#define IO_TYPE_MC_LONGI    (IO_TYPE_MC_BASE+11)
#define IO_TYPE_MC_INPUTCFG (IO_TYPE_MC_BASE+12)

/* Function prototypes: */

/* io_telescope.c */
int write_tel_block ARGLIST((IO_BUFFER *iobuf, int type, int num,
      real *data, int len));
int read_tel_block ARGLIST((IO_BUFFER *iobuf, int type, real *data,
      int maxlen));
int write_input_lines ARGLIST((IO_BUFFER *iobuf, 
      struct linked_string *list));
int read_input_lines ARGLIST((IO_BUFFER *iobuf, 
      struct linked_string *list));
int write_tel_pos ARGLIST((IO_BUFFER *iobuf, int ntel, double *x,
      double *y, double *z, double *r));
int read_tel_pos ARGLIST((IO_BUFFER *iobuf, int max_tel, int *ntel,
      double *x, double *y, double *z, double *r));
int write_tel_offset ARGLIST((IO_BUFFER *iobuf, int narray, double toff,
      double *xoff, double *yoff));
int write_tel_offset_w ARGLIST((IO_BUFFER *iobuf, int narray, double toff,
      double *xoff, double *yoff, double *weight));
int read_tel_offset ARGLIST((IO_BUFFER *iobuf, int max_array, int *narray,
      double *toff, double *xoff, double *yoff));
int read_tel_offset_w ARGLIST((IO_BUFFER *iobuf, int max_array, int *narray,
      double *toff, double *xoff, double *yoff, double *weight));
int begin_write_tel_array ARGLIST((IO_BUFFER *iobuf, IO_ITEM_HEADER *ih,
      int array));
int end_write_tel_array ARGLIST((IO_BUFFER *iobuf, IO_ITEM_HEADER *ih));
int begin_read_tel_array ARGLIST((IO_BUFFER *iobuf, IO_ITEM_HEADER *ih,
      int *array));
int end_read_tel_array ARGLIST((IO_BUFFER *iobuf, IO_ITEM_HEADER *ih));
int write_tel_photons ARGLIST((IO_BUFFER *iobuf, int array, int tel,
      double photons, struct bunch *bunches, int nbunches,
      int ext_bunches, char *ext_fname));
int write_tel_compact_photons ARGLIST((IO_BUFFER *iobuf, int array, int tel,
      double photons, struct compact_bunch *cbunches, int nbunches,
      int ext_bunches, char *ext_fname));
int read_tel_photons ARGLIST((IO_BUFFER *iobuf, int max_bunches, int *array,
      int *tel, double *photons, struct bunch *bunches, int *nbunches));
int write_shower_longitudinal (IO_BUFFER *iobuf, int event, int type, 
      double *data, int ndim, int np, int nthick, double thickstep);
int read_shower_longitudinal ARGLIST((IO_BUFFER *iobuf, int *event, 
      int *type, double *data, int ndim, int *np, int *nthick, 
      double *thickstep, int max_np));
int write_camera_layout ARGLIST((IO_BUFFER *iobuf, int itel, int type, 
      int pixels, double *xp, double *yp));
int read_camera_layout ARGLIST((IO_BUFFER *iobuf, int max_pixels, int *itel,
      int *type, int *pixels, double *xp, double *yp));
int write_photo_electrons ARGLIST((IO_BUFFER *iobuf, int array, int tel, 
      int npe, int pixels, int *pe_counts, int *tstart, double *t));
int read_photo_electrons ARGLIST((IO_BUFFER *iobuf, int max_pixel,
      int max_pe, int *array, int *tel, int *npe, int *pixels, int *pe_counts,
      int *tstart, double *t));

#ifdef _remove_ARGLIST_
#undef ARGLIST
#undef _remove_ARGLIST_
#endif

#ifdef __cplusplus
}
#endif

#endif
