/* ================================================================ */
/**
 * @file sim_skeleton.c
 * @short A (non-functional) skeleton program for reading CORSIKA IACT data.
 *
 * Copyright by Konrad Bernloehr (1997, 1999). All rights reserved.
 * This file may be modified but all modified version must be
 * declared as modified and by whom they were modified.
 *
 * This file contains a (non-functional) skeleton of the telescope simulation.
 * It serves only as an illustration of the essential usage of
 * CORSIKA related eventio functions to read CORSIKA data in
 * eventio format and how some of the required values are extracted.
 * Comment lines with '...' usually indicate that you should fill in
 * relevant code yourself.
 *
 * This file comes with no warranties.
*/
/* ================================================================ */

#include "initial.h"      /* This file includes others as required. */
#include "io_basic.h"     /* This file includes others as required. */
#include "mc_tel.h"
/* ... #include other header files .... */

#define MAX_BUNCHES 50000
#define MAX_PHOTOELECTRONS 100000
#define MAX_PIXELS 1024       /**< The largest no. of pixels per camers */
#define MAX_TEL 16            /**< The largest no. of telescopes/array. */
#define MAX_ARRAY 100         /**< The largest no. of arrays to be handled */

static double airlightspeed = 29.9792458/1.0002256; /* [cm/ns] at H=2200 m */

/** Refraction index of air as a function of height in km (0km<=h<=8km) */
#define Nair(hkm) (1.+0.0002814*exp(-0.0947982*(hkm)-0.00134614*(hkm)*(hkm)))

#ifndef Nint
#define Nint(x) ((x)>0?(int)((x)+0.5):(int)((x)-0.5))
#endif

/* External functions: */
void atmset_(int *iatmo, double *obslev); /* see atmo.c */
double RandFlat(void); /* Random number generator [0.:1[ */
double atmospheric_transmission (int iwl, double zem, double airmass); /* ... */

/* Dummy replacements for CORSIKA function linked with atmo.c */
double heigh_(double x) { return 0.; }
double thick_(double h) { return 0.; }
double rhof_(double h)  { return 0.; }

/* Trivial implementation of the RandFlat function with constant seeds. */
double RandFlat(void)
{
   static int init_needed = 1;
   if ( init_needed )
   {
      unsigned short s[3] = { 12345, 4321, 7890 };
      seed48(s);
      init_needed = 0;
   }
   return drand48();
}

/* Trivial implementation of atmospheric transmission: fully transparent */
double atmospheric_transmission (int iwl, double zem, double airmass)
{
   return 1.0;
}

/* Change the following data structures as required: */

/** Basic parameters of the CORSIKA run */

struct mc_run
{
   double height;          /**< Height of observation level [m] */
   double e_min;           /**< Lower limit of simulated energies [TeV] */
   double e_max;           /**< Upper limit of simulated energies [TeV] */
   double slope;           /**< Spectral index of power-law spectrum */
   double radius;          /**< Radius within which cores are thrown at random. [m] */
   int num_arrays;         /**< Number of arrays simulated. */
   double theta_min;       /**< Lower limit of zenith angle [degrees] */
   double theta_max;       /**< Upper limit of zenith angle [degrees] */
   double phi_min;         /**< Lower limit of azimuth angle [degrees] */
   double phi_max;         /**< Upper limit of azimuth angle [degrees] */
   double wlen_min;        /**< Lower limit of Cherenkov wavelength range [nm] */
   double wlen_max;        /**< Upper limit of Cherenkov wavelength range [nm] */
   double bunchsize;       /**< Cherenkov bunch size. */
};

/** Basic parameters of a simulated shower */

struct simulated_shower_parameters
{
   double energy;                /**< Shower energy [TeV] */
   double azimuth;               /**< Shower direction azimuth [deg] */
   double altitude;              /**< Shower direction altitude above horizon */
   double xcore, ycore, zcore;   /**< Shower core position [m] */
   double core_dist_3d;          /**< Distance of core from reference point */
   double tel_core_dist_3d[MAX_TEL];  //*< Offset of telescopes from shower axis */
   int particle;                 /**< Primary particle type [CORSIKA code] */
   double xmax;            /**< Depth of shower maximum from all particles [g/cm**2] */
   double emax;            /**< Depth of shower maximum from positrons and electrons */
   double cmax;            /**< Depth of maximum of Cherenkov light emission [g/cm**2] */
   double hmax;            /**< Height of shower maximum (from xmax above) [m] a.s.l. */
};

/**  Description of telescope position, array offets and shower parameters. */

struct telescope_array
{
   int ntel;               /**< Number of telescopes simulated per array */
   int max_tel;            /**< Maximum number of telescopes acceptable (MAX_TEL) */
   int narray;             /**< Number of arrays with random shifts per shower */
   double refpos[3];       /**< Reference position with respect to obs. level [cm] */
   double obs_height;      /**< Height of observation level [cm] */
   double xtel[MAX_TEL];   /**< X positions of telescopes ([cm] -> north) */
   double ytel[MAX_TEL];   /**< Y positions of telescopes ([cm] -> west) */
   double ztel[MAX_TEL];   /**< Z positions of telescopes ([cm] -> up) */
   double rtel[MAX_TEL];   /**< Radius of spheres enclosing telescopes [cm] */
   double toff;            /**< Time offset from first interaction to the moment */
                           /**< when the extrapolated primary flying with the vacuum */
                           /**< speed of light would be at the observation level. */
   double xoff[MAX_ARRAY]; /**< X offsets of the randomly shifted arrays [cm] */
   double yoff[MAX_ARRAY]; /**< Y offsets of the randomly shifted arrays [cm] */
   double azimuth;         /**< Nominal azimuth angle of telescope system [deg]. */
   double altitude;        /**< Nominal altitude angle of telescope system [deg]. */
   double source_azimuth;  /**< Azimuth of assumed source. */
   double source_altitude; /**< Altitude of assumed source. */
   struct simulated_shower_parameters shower_sim;
   struct mc_run mc_run;
   /* ... */
};

/** Parameters describing the telescope optics */

struct telescope_optics
{
   int telescope;           /**< Telescope sequence number */
   /* ... */
};

/** Parameters of a telescope camera (pixels, ...) */

struct pm_camera
{
   int telescope;           /**< Telescope sequence number */
   /* ... */
};

/** Parameters of the electronics of a telescope */

struct camera_electronics
{
   int telescope;           /**< Telescope sequence number */
   int simulated;           /**< Is 1 if the signal simulation was done. */
   
   /* ... */
};

struct linked_string corsika_inputs;

/* ========================== Utility functions ======================= */

/* ------------------- line_point_distance --------------------- */
/**
 *  Distance between a straight line and a point in space
 *
 *  @param  x1,y1,z1  reference point on the line
 *  @param  cx,cy,cz  direction cosines of the line
 *  @param  x,y,z     point in space
 *
 *  @return distance
 *
*/

double line_point_distance (double x1, double y1, double z1, 
   double cx, double cy, double cz,
   double x, double y, double z)
{
   double a, a1, a2, a3, b;
   
   a1 = (y-y1)*cz - (z-z1)*cy;
   a2 = (z-z1)*cx - (x-x1)*cz;
   a3 = (x-x1)*cy - (y-y1)*cx;
   a  = a1*a1 + a2*a2 + a3*a3;
   b = cx*cx + cy*cy + cz*cz;
   if ( a<0. || b<= 0. )
      return -1;
   return sqrt(a/b);
}

/* =================== Main program for the simulation =================== */
/**
 *  Main program of Cherenkov telescope simulation.
*/

int main(int argc, char **argv)
{
   IO_BUFFER *iobuf;
   IO_ITEM_HEADER item_header, sub_item_header, block_header;
   real runh[273], rune[273], evth[273], evte[273];

   /* Some data structures suitably declared to hold data specific */
   /* to the whole telescope array and optics, cameras, and electronics */
   /* of the individual telescopes. */ 
   static struct telescope_array array;
   static struct telescope_optics tel_optics[MAX_TEL];
   struct telescope_optics *optics;
   static struct pm_camera camera[MAX_TEL];
   struct pm_camera *cam;
   static struct camera_electronics electronics[MAX_TEL];
   struct camera_electronics *el;

   double distance;
   int nbunches;
   int itc, itel, iarray, jarray, ibunch;
   int lambda;
   double photons;
   double wl_bunch, airmass, cx, cy, cz, prob;
   double px, py, pz;
   double tel_dist, tel_delay;
   char *input_fname = NULL;
   FILE *data_file;
   static double power_diff, event_weight, elow;
   static struct bunch bunches[MAX_BUNCHES];
   static int particle_type;
   static double primary_energy;
   static double wl_lower_limit, wl_upper_limit;
   int run = -1, event = -1;
   double alt = -90., az = 0.;
   static double power_law = 2.7;
   double quantum_efficiency[1000], mirror_reflectivity[1000];
   static int have_atm_profile = 0;
   int event_end_available = 0;
   double toffset;

   /* ... Declare other variables required ... */

   /* ... Initialize configuration of optics, camera, and electronics ... */
   
      /* Trivial mirror reflectivity and quantum efficiency */
      for ( lambda = 200; lambda <= 999; lambda++ )
      {
         mirror_reflectivity[lambda] = 0.8;
         quantum_efficiency[lambda] = 
            0.25*exp(-0.5*(lambda-400.)*(lambda-400.)/(100.*100.));
      }

   /* ... Initialize random number generator ... */

   /* ... Initialize histograms ... */

   /* ... Simulate calibration procedure ... */

   /* I/O buffer for input needed */
   if ( (iobuf = allocate_io_buffer(0)) == NULL )
   {
      fprintf(stderr,"Input I/O buffer not allocated\n");
      exit(1);
   }
   iobuf->max_length = 20000000;
   
   if ( argc > 1 )
      input_fname = argv[1];

   /* Start the big loop over all input files */
   for ( /* ... */ ; input_fname != NULL;
         /* ... loop over file names on command line or config file ... */ )
   {
    printf("Input file: %s\n",input_fname);
    if ( (data_file = fopen(input_fname,"r")) == NULL )
    {
       perror(input_fname);
       exit(1);
    }
    input_fname = NULL;

    iobuf->input_file = data_file;

    for(;;) /* Loop over all data in the input file */
    {
      optics = NULL;
      cam = NULL;
      el = NULL;

      /* Find and read the next block of data. */
      /* In case of problems with the data, just give up. */
      if ( find_io_block(iobuf,&block_header) != 0 )
         break;
      if ( read_io_block(iobuf,&block_header) != 0 )
         break;

      /* What did we actually get? */
      switch ( block_header.type )
      {
         /* CORSIKA run header */
         case IO_TYPE_MC_RUNH:
            read_tel_block(iobuf,IO_TYPE_MC_RUNH,runh,273);
            { int nht = runh[4];
              if ( nht>0 && nht <= 10 )
                array.obs_height = runh[4+nht];
              else
                array.obs_height = -100;
            }
            run = (int) runh[1];
            printf("Run %d: observation level is at %6.1f m\n",
                 run,0.01*array.obs_height);
            airlightspeed = 29.9792458 / Nair(1e-5*array.obs_height);
            if ( power_law > 0. )
               power_law *= -1.;
            power_diff = power_law - runh[15];
            elow = runh[16];
            printf(
           "Events created between %5.3f and %5.3f TeV following a power law\n",
               (double)runh[16]/1e3,(double)runh[17]/1e3);
            printf("of E^%5.2f are now weighted by E^%5.2f\n",
               (double)runh[15],power_diff);
	    /* CORSIKA run information in run header */
	    array.mc_run.height = array.obs_height*0.01;
	    array.mc_run.e_min = runh[16]*0.001;
	    array.mc_run.e_max = runh[17]*0.001;
	    array.mc_run.slope = runh[15];
	    /* Further information has to wait for event header */
	    array.mc_run.radius = 0.;
	    array.mc_run.num_arrays = 0;
	    array.mc_run.theta_min = array.mc_run.theta_max = -1.;
	    array.mc_run.phi_min = array.mc_run.phi_max = -1.;
	    array.mc_run.wlen_min = array.mc_run.wlen_max = 0.;
	    /* ... Update your configuration accordingly ... */
            break;


      	 /* CORSIKA inputs */
	 case IO_TYPE_MC_INPUTCFG:
	    read_input_lines(iobuf,&corsika_inputs);
	    if ( corsika_inputs.text != NULL )
	    {
	       struct linked_string *xl, *xln;
	       printf("\nCORSIKA was run with the following input lines:\n");
	       for (xl = &corsika_inputs; xl!=NULL; xl=xln)
	       {
		  printf("   %s\n",xl->text);
		  free(xl->text);
		  xl->text = NULL;
		  xln = xl->next;
		  xl->next = NULL;
		  if ( xl != &corsika_inputs )
		     free(xl);
	       }
	       fflush(stdout);
	    }
	    break;

         /* Telescope positions (relative positions in array) */
         case IO_TYPE_MC_TELPOS:
            array.max_tel = MAX_TEL;
            read_tel_pos(iobuf,MAX_TEL,&array.ntel,array.xtel,array.ytel,
                array.ztel,array.rtel);
            printf("\nSimulated telescope array:\n");
            for (itel=0; itel<array.ntel; itel++)
               printf(
            "   Telescope %d at x=%6.2f m, y=%6.2f m, z=%6.2f m with r=%5.2f m\n",
               camera[itel].telescope,0.01*array.xtel[itel],
               0.01*array.ytel[itel],0.01*array.ztel[itel],
               0.01*array.rtel[itel]);
            printf(
            "Array viewing direction: azimuth=%6.2f deg, altitude=%6.2f deg\n\n",
               array.azimuth,array.altitude);
	    /* ... Adapt your configuration accordingly ... */
            break;

         /* CORSIKA event header */
         case IO_TYPE_MC_EVTH:
            read_tel_block(iobuf,IO_TYPE_MC_EVTH,evth,273);
            event = evth[1];
            wl_lower_limit = evth[95];
            wl_upper_limit = evth[96];
            primary_energy = evth[3];
	    if ( !have_atm_profile )
	    {
	       int iatmo = (int)(evth[76]/1000+0.5);
	       if ( iatmo <= 0 )
	          iatmo = 6; /* US standard atmosphere */
	       atmset_(&iatmo,&array.obs_height);
	       have_atm_profile = 1;
	    }
            array.shower_sim.energy = 0.001 * primary_energy; /* in TeV */
	    array.shower_sim.xmax = array.shower_sim.emax = 
	       array.shower_sim.cmax = 0.;
	    array.shower_sim.hmax = 0.;
            particle_type = Nint(evth[2]);
            toffset = (evth[6]-array.obs_height) / cos(evth[10]) / 29.9792458;
            /* Event weight is now with respect to a 1 TeV shower. */
            event_weight = pow(array.shower_sim.energy,power_diff);
            printf(
            "Event %d: particle type %d with energy %5.2f TeV (weight %5.3f),\n",
                (int)evth[1],particle_type,0.001*primary_energy,event_weight);
            alt = 90. - (180./M_PI)*evth[10];
            az  = 180. - (180./M_PI)*(evth[11]-evth[92]);
            az -= floor(az/360.) * 360.;
            printf("   zenith angle %4.2f deg, azimuth %4.2f deg\n",
               90.-alt, az);

	    array.mc_run.theta_min = evth[80];
	    array.mc_run.theta_max = evth[81];
	    array.mc_run.phi_max = 180. - (evth[82]-evth[92]);
	    array.mc_run.phi_min = 180. - (evth[83]-evth[92]);
	    array.mc_run.bunchsize = evth[84];
	    array.mc_run.wlen_min = evth[95];
	    array.mc_run.wlen_max = evth[96];

            array.shower_sim.azimuth = az;
            array.shower_sim.altitude = alt;
	    array.shower_sim.particle = particle_type;

	    event_end_available = 0;
            break;

         /* Offsets of telescope array instances for the following event */
         case IO_TYPE_MC_TELOFF:
            read_tel_offset(iobuf,MAX_ARRAY,&array.narray,
                &array.toff,array.xoff,array.yoff);
            toffset = array.toff; /* Should be about the same again as above */
      	    array.mc_run.num_arrays = array.narray;
            if ( array.narray == 1 )
               printf("Each shower is used only once.\n");
            else
               printf("Each shower is used %d times.\n", array.narray);
            for (iarray=0; iarray<array.narray; iarray++)
               printf("Shower core offset %d: %4.2f m, %4.2f m\n",
                  iarray+1, -0.01*array.xoff[iarray], -0.01*array.yoff[iarray]);
            break;

         /* Photon data for a complete array (one of perhaps many instances) */
         case IO_TYPE_MC_TELARRAY:
            begin_read_tel_array(iobuf, &item_header, &iarray);
            printf("Now beginning with shower %d as seen from array %d\n",
               event, iarray);

            array.shower_sim.xcore = -0.01 * array.xoff[iarray]; /* in meters */
            array.shower_sim.ycore = -0.01 * array.yoff[iarray]; /* in meters */
            /* Observation level is now defining z=0.: */
            array.shower_sim.zcore = 0.; /* Note: this is below lowest telescope */

            array.shower_sim.core_dist_3d = 
               line_point_distance(array.shower_sim.xcore,
                  array.shower_sim.ycore, array.shower_sim.zcore,
                  cx=cos(alt*(M_PI/180.))*cos(az*(M_PI/180.)),
                  cy=-cos(alt*(M_PI/180.))*sin(az*(M_PI/180.)),
                  cz=sin(alt*(M_PI/180.)), 0.01*array.refpos[0],
                  0.01*array.refpos[1], 0.01*array.refpos[2]);
            /* Distances of telescopes from shower axis */
            for (itel=0; itel<array.max_tel; itel++)
               array.shower_sim.tel_core_dist_3d[itel] = 
                  line_point_distance(array.shower_sim.xcore,
                     array.shower_sim.ycore, array.shower_sim.zcore,
                     cx, cy, cz, 0.01*array.xtel[itel],
                     0.01*array.ytel[itel], 0.01*array.ztel[itel]);

            for (itel=0; itel<array.max_tel; itel++)
               electronics[itel].simulated = 0;
            for (itc=0; itc<array.ntel; itc++)
            {
               sub_item_header.type = IO_TYPE_MC_PHOTONS;
               if ( search_sub_item(iobuf,&item_header,&sub_item_header) < 0 )
                  break;
               /* Read the photon bunches for one telescope */
               if (read_tel_photons(iobuf,MAX_BUNCHES,&jarray,&itel,
                     &photons,bunches,&nbunches) < 0)
               {
                  fprintf(stderr,"Error reading %d photon bunches\n",nbunches);
                  continue;
               }

               if ( itel >= array.max_tel || itel < 0 )
               {
                  fprintf(stderr,
      "Cannot process data for telescope #%d because only %d are configured.\n",
                    itel+1,array.max_tel);
                  continue;
               }
               printf("Telescope %d has %d bunches with %4.2lf photons in total.\n",
                  itel+1, nbunches, photons);

               optics = &tel_optics[itel];
               cam = &camera[itel];
               el = &electronics[itel];

	       /* ... Other telescope-specific initializations ... */

               for ( ibunch=0; ibunch<nbunches; ibunch++ )
               {
                  /* Wavelength of this bunch or 0. if not set yet. */
                  wl_bunch = bunches[ibunch].lambda;
                  cx = bunches[ibunch].cx;
                  cy = bunches[ibunch].cy;
                  cz = -1.*sqrt(1.-cx*cx-cy*cy); /* direction is downwards */
                  /* Use secans(zenith angle) for airmass, */
                  /* i.e. assume a plane atmosphere. */
                  airmass = -1./cz;
                  /* Distance between point of emission and */
                  /* the CORSIKA observation level */
                  distance = (bunches[ibunch].zem-array.obs_height) * airmass;
                  /* Distance between CORSIKA observation level and */
                  /* telescope fixed position. */
                  tel_dist = array.ztel[itel] * airmass;
                  /* Position where photon hits telescope level. */
                  /* This level is at ztel in the CORSIKA frame. */
                  px = bunches[ibunch].x + tel_dist*cx;
                  py = bunches[ibunch].y + tel_dist*cy;
                  pz = tel_dist*cz;
                  /* Note that, although tracing starts at the CORSIKA */
                  /* level, the bunch time corresponds to the crossing */
                  /* of the telescope level. */
                  tel_delay = tel_dist / airlightspeed;
		  /* Note also that the photon bunch might be created */
		  /* behind the telescope mirror. Check in raytracing. */

                  for (; bunches[ibunch].photons>0; bunches[ibunch].photons-=1.)
                  {
                     if ( wl_bunch == 0. )
                        /* According to 1./lambda^2 distribution */
                        lambda = 1./(1./wl_lower_limit-RandFlat()*
                          (1./wl_lower_limit-1./wl_upper_limit));
		     else if ( wl_bunch < 0. )
		        /* This indicates that quantum efficiency, mirror */
			/* reflectivity, and atmospheric transmission */
			/* have already been applied in CORSIKA (which */
			/* was CMZ extracted then with the CEFFIC option). */
			lambda = -1.;
                     else 
                        /* Wavelength already generated in Corsika */
                        lambda = wl_bunch;

                     if ( lambda >= 1000 )
                        continue;
                     else if ( lambda >= 0 )
		     {
                	/* Detection probability in most optimistic case: */
                	prob = atmospheric_transmission(lambda,
                        	 bunches[ibunch].zem, airmass) *
                               quantum_efficiency[lambda] *
                               mirror_reflectivity[lambda];
		     }
		     else
		     	prob = 1.;

                     if ( bunches[ibunch].photons < 1. )
                        prob *= bunches[ibunch].photons;

                     if ( prob < 1. )
                     	if ( RandFlat() > prob )
                           continue;
                     
                     /*
                     if ( lambda < 0 )
                        printf("Processing photo-electron from CORSIKA CEFFIC option.\n");
                     else
                        printf("Detectable photon of %d nm wavelength.\n", lambda);
                     */

                     /* ... Trace photon through telescope to camera ... */

                     /* ... See if a camera pixel was hit ... */

		     /* ... Collect photo-electrons for that pixel ... */
		  }
	       }

               /* ... Simulate PM signals in FADC and discriminators ... */

               /* ... Simulate the telescope trigger ... */

            } /* End of loop over telescopes */

            /* ... Enough telescopes to trigger the array? ... */

            /* ... Filling of histograms etc. for one array instance ... */
	    /* Note: data structures are reused for next instance. */

            end_read_tel_array(iobuf, &item_header);
            break;

         /* CORSIKA event trailer */
         case IO_TYPE_MC_EVTE:
            read_tel_block(iobuf,IO_TYPE_MC_EVTE,evte,273);
	    /* All array instances for this shower are finished */
            break;

         /* CORSIKA run trailer */
         case IO_TYPE_MC_RUNE:
            read_tel_block(iobuf,IO_TYPE_MC_RUNE,rune,273);
            break;

         /* Unknown / any other material */
         default:
            break;
      } /* End of switch over all input data types */
    } /* End of loop over all data in the input file */          
    fclose(iobuf->input_file);
    iobuf->input_file = NULL;
   } /* End of big loop over input files */

   /* ... Save histograms ... */
   
   /* ... Save random number generator status ... */

   return 0;
}
