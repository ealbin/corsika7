/*-- Author :    JIM HINTON, U CHICAGO           13/11/01*/
/*====================================================================*/

/*     stacee.c                                                       */

/*--------------------------------------------------------------------*/
/* STACEE_OUT.C - code to convert the output of CORSIKA into standard */
/* STACEE binary format:                                              */
/*                                                                    */
/* Writes bank version 6.                                             */
/* Writes photon version CABE                                         */
/*                                                                    */
/* Original MOCCA version: Corbin Covault                             */
/* Original Corsika version          (acfe): Jim Hinton 2000          */
/* Updated/Corrected Corsika version (bafa): Lowell Boone 2002        */
/* Updated/Corrected Corsika version (cabe): Carsten Mueller 2004     */
/*                                                                    */
/*--------------------------------------------------------------------*/

#include <math.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#if defined(__GNUC__)&&__GNUC__ > 3
#include <stdlib.h>
#endif

/*-------------------------------------------------------------------*/
/* Definitions - header formats and miscellaneous */

#define BSYNC1 (0xEADA)
#define BSYNC2 (0xBABE)
#define BNAME1 'M'*256+'O'
#define BNAME2 'C'*256+'H'
#define BLENHI 0U
#define BLENLO 256U
#define BVERS  6U

#define RSYNC  (0xACFD)
#define ESYNC  (0xCABE)
#define WSYNC  (0xACFC)
#define CORSIKA_CODE 1000U

#define MAX9 1023
#define BITS15 32768
#define MAX15 65535
#define BITS17 131072
#define MAX17 262143

#define RAD2DEG 57.29578
#define SPEED_C 29.97925   /* in cm/ns */
#define MAG_DECL 10.21     /* Angle from Grid North to Magnetic North */
#define SUCCESS 0                     /* (Albuquerque NM, April 2004) */
#define FAILURE 1

#define topbits(A) ((A)&(0xffff0000))>>16
#define bottombits(A) ((A)&(0x0000ffff))

/*-------------------------------------------------------------------*/
/* Type definitions */

typedef unsigned short ushort;
typedef unsigned long ulong;
typedef unsigned int uint;

/*-------------------------------------------------------------------*/
/* Global variables */

FILE   *fp;  /* Output file pointer       */
double  t0;  /* Global timing offset [ns] */

/*-------------------------------------------------------------------*/
/* Function prototypes */

#ifdef __REDHAT2__
void run_header_out__(int *run,double *primid,int *maxshowers, double *emin,
                   double *emax,double *spec,double *azim,double *zmin,
                   double *zmax,double *bx,double *bz,double *depground,
                   double *bypassgcm,double *ethin,double *estop,
                   double *step,double *numin,double *numax,double *cerx,
                   double *cery,int *abs_flag,int *qe_flag,int *seed);
void shower_header_out__(int *evnum, double *evenergy, double *evazim,
                         double *evzenith);
void calc_time_offset__(double *heighp, double *obslev, double *evzenith);
void photon_out__(double *x, double *y, double *nx,
                  double *ny, double *ns, double *wave_len);
void finish_out__(void);
#else
void run_header_out_(int *run,double *primid,int *maxshowers, double *emin,
                   double *emax,double *spec,double *azim,double *zmin,
                   double *zmax,double *bx,double *bz,double *depground,
                   double *bypassgcm,double *ethin,double *estop,
                   double *step,double *numin,double *numax,double *cerx,
                   double *cery,int *abs_flag,int *qe_flag,int *seed);
void shower_header_out_(int *evnum, double *evenergy, double *evazim,
                         double *evzenith);
void calc_time_offset_(double *heighp, double *obslev, double *evzenith);
void photon_out_(double *x, double *y, double *nx,
                  double *ny, double *ns, double *wave_len);
void finish_out_(void);
#endif
void target_info(void);

void wordwrite(ushort *word);

/*-------------------------------------------------------------------*/
/* Functions */

#ifdef __REDHAT2__
void run_header_out__(run,primid,maxshowers,emin,emax,spec,azim,zmin,zmax,
                   bx,bz,depground,bypassgcm,ethin,estop,step,numin,numax,
                   cerx,cery,abs_flag,qe_flag,seed)
#else
void run_header_out_(run,primid,maxshowers,emin,emax,spec,azim,zmin,zmax,
                   bx,bz,depground,bypassgcm,ethin,estop,step,numin,numax,
                   cerx,cery,abs_flag,qe_flag,seed)
#endif

     int *run,*maxshowers,*abs_flag,*qe_flag,*seed;
     double *emin,*emax,*spec,*azim,*zmin,*zmax,*primid;
     double *ethin,*estop,*step,*bypassgcm,*depground,*numin,*numax,*bx,*bz;
     double *cerx,*cery;

     /*

       ALL WORDS ARE UNSIGNED SHORT (2-bytes from 0x0000 to 0xffff)

       Bank Header:

       Word   semi-name   Description
       ----   ----------  ---------------------------------------------
       0      sync1       0xeada  -- binary file identifier sync word for BANK
       1      sync2       0xbabe  -- BANK header sync part 2
       2      bname1      `MO' of MOCH bank name
       3      bname2      `CH' of MOCH bank name
       4      blenhi      high bits length of bank (should be zero)
       5      blenlo      low bits length of bank (show be 256 for Version 4)
       6      spare       This is spare
       7      bvers       This is bank version. Now version 6.

       Run Header record -- at the beginning of every run file:

       Word   semi-name   Description
       ----   ----------  ---------------------------------------------
       0      sync        0xacfd  -- binary file identifier sync word
       1      vcode       Version code for mocca * 100
       2      runhi       High bits of run number
       3      runlo       Low bits. Run number = (0x10000)*runhi+runlo
       4      yearday     UT (Year-1990)*1000+day that Run is started
       5      hour        Hour * 100 plus minute that we started
       6      kemin       min E primary in GeV
       7      kemax       max E primary in GeV
       8      index       Spectral index *1000
       9      azim        Azimuth*100
       10     zenmin      Minimum Zenith *100
       11     zenmax      Maximum zenith *100
       12     ethin       In GeV *100
       13     erough      In MeV times 100
       14     grough      In MeV times 100
       15     estop       In Mev times 100
       16     randseed    (0.0 to 1.0) times 10000
       17     bypassgcm   In grams times 10
       18     depground   In grams times 10
       19     pid         Primary Particle id
       20     stepsize
       21     maxshowers (should always be 1)
       22     wave_flag   Atmospheric attenuation
       23     cerenk_radius  Radius out which to keep C photon
       24     cerenk_det_eff  Detector effeciency
       25     cerenk_def_eff_wave  Is this wavelength dependent?
       26     nu_min      Wavelength min
       27     nu_max      Wavelength max
       28     bgauss      Field strength
       29     magdip      Magnetic field dip angle
       30     comrun      Common Run Number for collecting event files
       31     rtype       Run type (Cherenkov, whatever)
       32     eventyear   Simulated Year of Event
       33     eventdoy    Simulated Day of Year for Event
       34     eventhour   Simulated  Hour for Event
       35     eventminute Simulated Minute for Event
       36     eventsecond Simulated Second for Event
       37     eventmilsec Simulated Milliseconds for Event
       38     eventmicsec Simulated Microseconds for Event
       39     targetra    Right ascension of target
       40     targetdec   Dec of target
       41     targetaz    Azimuth of target
       42     targetel    Elevation of target
       43     targetradius Radius out from target within where events happen
       44     targetid    ID code for target
       45     spare
       46     spare
       47     spare
       48     sync        0xacfc  -- indicates start of efficiency table
       49-153   Efficiency at each wavelength  (105 words)
       154-239  spare

     */

{
  FILE *wfp;
  char filename[10],char_run[7],line[100];
  double yearday,hourmin,q[8];
  double bgauss,magdip,radius;
  double moc_azim,moc_z1,moc_z2;
  int i,j,len;
  ushort v;

  time_t tp;
  struct tm *ts;

  /* Convert CORSIKA azimuth to (clockwise from grid N), and both
     angles to degrees */
  moc_azim = 180.0 - (*azim*RAD2DEG) + MAG_DECL;
  while (moc_azim<0.0) moc_azim += 360.0;
  while (moc_azim>=360.0) moc_azim -= 360.0;
  moc_z1 = *zmin * RAD2DEG;
  moc_z2 = *zmax * RAD2DEG;

  /* Open file */

  strcpy(filename,"COR000000");
  sprintf(char_run,"%d",*run);
  len = strlen(char_run);
  strcpy(filename+(9-len),char_run);
  printf("Opening STACEE Cerenkov output file: %s \n",filename);
  if ((fp = fopen(filename,"w"))==NULL) {
    printf("Can't open output file\n");
    exit(FAILURE);
  }

  /* Convert CORSIKA run parameters into MOCCA equivalents */

  bgauss = sqrt((*bx)*(*bx)+(*bz)*(*bz));
  magdip = RAD2DEG*atan2(*bz,*bx);
  radius = 0.0025*(*cerx+*cery);

  /* Find current time:
     4   yearday     UT (Year-1990)*1000+day that Run is started
     5   hourmin     Hour * 100 plus minute that we started */

  (void) time(&tp);
  ts=localtime(&tp);
  yearday = (double)((ts->tm_year-90)*1000+ts->tm_yday);
  hourmin = (double)((ts->tm_hour)*100 + ts->tm_min);

  /* Write bank header */

  v=(ushort)BSYNC1;
  wordwrite(&v);
  v=(ushort)BSYNC2;	
  wordwrite(&v);
  v=(ushort)BNAME1;
  wordwrite(&v);
  v=(ushort)BNAME2;	
  wordwrite(&v);
  v=(ushort)BLENHI;	
  wordwrite(&v);
  v=(ushort)BLENLO;
  wordwrite(&v);
  v=(ushort)(0);   /*Spare*/
  wordwrite(&v);
  v=(ushort)BVERS;
  wordwrite(&v);

  /* Write run header */

  v=(ushort)RSYNC;
  wordwrite(&v);                                   /* 0 */
  v=(ushort)CORSIKA_CODE;
  wordwrite(&v);                                   /* 1 */
  v=(ushort)((ulong)(topbits(*run)));
  wordwrite(&v);                                   /* 2 */
  v=(ushort)((ulong)(bottombits(*run)));
  wordwrite(&v);                                   /* 3 */
  v=(ushort)(yearday);
  wordwrite(&v);                                   /* 4 */
  v=(ushort)(hourmin);
  wordwrite(&v);                                   /* 5 */
  v=(ushort)(*emin);
  wordwrite(&v);                                   /* 6 */
  v=(ushort)(*emax);
  wordwrite(&v);                                   /* 7 */
  v=(ushort)(*spec*1000);
  wordwrite(&v);                                   /* 8 */
  v=(ushort)(moc_azim*100);
  wordwrite(&v);                                   /* 9 */
  v=(ushort)(moc_z1*100);
  wordwrite(&v);                                   /* 10 */
  v=(ushort)(moc_z2*100);
  wordwrite(&v);                                   /* 11 */
  v=(ushort)(*ethin*100);
  wordwrite(&v);                                   /* 12 */
  v=(ushort)(0); /* E(rough) - no such parameter in CORSIKA */
  wordwrite(&v);                                   /* 13 */
  v=(ushort)(0); /* G(rough) - no such parameter in CORSIKA */
  wordwrite(&v);                                   /* 14 */
  v=(ushort)(*estop*100);
  wordwrite(&v);                                   /* 15 */
  v=(ushort)(*seed*10000);
  wordwrite(&v);                                   /* 16 */
  v=(ushort)(*bypassgcm*10);
  wordwrite(&v);                                   /* 17 */
  v=(ushort)(*depground*10);
  wordwrite(&v);                                   /* 18 */
  v=(ushort)(*primid+1);
  wordwrite(&v);                                   /* 19 */
  v=(ushort)(*step*1000);
  wordwrite(&v);                                   /* 20 */
  v=(ushort)(*maxshowers);
  wordwrite(&v);                                   /* 21 */
  v=(ushort)(*abs_flag);
  wordwrite(&v);                                   /* 22 */
  v=(ushort)(radius*10.0);
  wordwrite(&v);                                   /* 23 */
  v=(ushort)(0); /* Detector efficiency NOT USED */
  wordwrite(&v);                                   /* 24 */
  v=(ushort)(*qe_flag);
  wordwrite(&v);                                   /* 25 */
  v=(ushort)(*numin*10.0);
  wordwrite(&v);                                   /* 26 */
  v=(ushort)(*numax*10.0);
  wordwrite(&v);                                   /* 27 */
  v=(ushort)(bgauss*1000.0);
  wordwrite(&v);                                   /* 28 */
  v=(ushort)(magdip*100.0);
  wordwrite(&v);                                   /* 29 */

  target_info();                                  /* 30-47 */

  /* Efficiency vs wavelength table */

  if (!(wfp=fopen("quanteff.dat","r"))) {
    fprintf(stderr,"Error: can't open quanteff.dat\n");
    exit(FAILURE);
  }
  v=(ushort)WSYNC;
  wordwrite(&v);                                   /* 48 */

  printf("%s",fgets(line,100,wfp));
  for (i=0; i<13; i++) {
    printf("%s",fgets(line,100,wfp));
    sscanf(line,"%lf %lf %lf %lf %lf %lf %lf %lf",
            q,&q[1],&q[2],&q[3],&q[4],&q[5],&q[6],&q[7]);
    for (j=0;j<8;j++) {
      v=(ushort)(q[j]*10000.0);
      wordwrite(&v);                               /* 49-152 */
    }
  }
  fscanf(wfp,"%lf",q);
  printf("%.3f \n\n",q[0]);
  v=(ushort)(q[0]);
  wordwrite(&v);                                   /* 153 */

  /* Spare */

  v=(ushort)(0);
  for (i=154; i<240; i++) {
    wordwrite(&v);                                 /* 154-239 */
  }
  fflush(stdout);
}

/*-------------------------------------------------------------------*/

void target_info()
{
  /* Write out the target information part of the header.

   NOTE: This information is read in from a text file called
   'runinfo.dat', which should have been written by the script used
   for driving CORSIKA, and which has to be in the directory from
   which CORSIKA is run. There is currently no more elegant way of
   propagating these variables, as the CORSIKA program itself does
   not know about them. You may not need them for your application.
   If 'runinfo.dat' is not found, all of these variables will be
   filled with zeroes.

  */

  int commonrunnumber,runtype;
  int eventyear,eventday,eventhour,eventminute,eventsecond,
    eventmilsec,eventmicsec;
  float targetra,targetdec,targetaz,targetzen,targetradius;
  int targetid;

  FILE *run;
  ushort v;
  int i;

  if ((run=fopen("runinfo.dat","r"))==NULL) {
    v=(ushort)(0);
    for (i=30; i<48; i++) {
      wordwrite(&v);
    }
  } else {
    /* read in extra run parameters */
    fscanf(run,"%*[^=]= %d\n",&commonrunnumber);
    fscanf(run,"%*[^=]= %d\n",&runtype);
    fscanf(run,"%*[^=]= %d\n",&eventyear);
    fscanf(run,"%*[^=]= %d\n",&eventday);
    fscanf(run,"%*[^=]= %d\n",&eventhour);
    fscanf(run,"%*[^=]= %d\n",&eventminute);
    fscanf(run,"%*[^=]= %d\n",&eventsecond);
    fscanf(run,"%*[^=]= %d\n",&eventmilsec);
    fscanf(run,"%*[^=]= %d\n",&eventmicsec);
    fscanf(run,"%*[^=]= %f\n",&targetra);
    fscanf(run,"%*[^=]= %f\n",&targetdec);
    fscanf(run,"%*[^=]= %f\n",&targetaz);
    fscanf(run,"%*[^=]= %f\n",&targetzen);
    fscanf(run,"%*[^=]= %f\n",&targetradius);
    fscanf(run,"%*[^=]= %d\n",&targetid);

    v=(ushort)(commonrunnumber);
    wordwrite(&v);                                   /* 30 */
    v=(ushort)(runtype);
    wordwrite(&v);                                   /* 31 */
    v=(ushort)(eventyear);
    wordwrite(&v);                                   /* 32 */
    v=(ushort)(eventday);
    wordwrite(&v);                                   /* 33 */
    v=(ushort)(eventhour);
    wordwrite(&v);                                   /* 34 */
    v=(ushort)(eventminute);
    wordwrite(&v);                                   /* 35 */
    v=(ushort)(eventsecond);
    wordwrite(&v);                                   /* 36 */
    v=(ushort)(eventmilsec);
    wordwrite(&v);                                   /* 37 */
    v=(ushort)(eventmicsec);
    wordwrite(&v);                                   /* 38 */
    v=(ushort)(targetra*100.0);
    wordwrite(&v);                                   /* 39 */
    v=(ushort)(targetdec*100.0);
    wordwrite(&v);                                   /* 40 */
    v=(ushort)(targetaz*100.0);
    wordwrite(&v);                                   /* 41 */
    v=(ushort)(targetzen*100.0);
    wordwrite(&v);                                   /* 42 */
    v=(ushort)(targetradius*100.0);
    wordwrite(&v);                                   /* 43 */
    v=(ushort)(targetid);
    wordwrite(&v);                                   /* 44 */
    for(i=45; i<48; i++) {   /* fill spare words with zeroes */
      v=(ushort)0;
      wordwrite(&v);                                 /* 45-47 */
    }
  }
}

/*-------------------------------------------------------------------*/

#ifdef __REDHAT2__
void shower_header_out__(evnum,evenergy,evazim,evzenith)
#else
void shower_header_out_(evnum,evenergy,evazim,evzenith)
#endif
     int *evnum;
     double *evenergy,*evazim,*evzenith;

/*
  Primary event record  -- start every event: Sync needed to locate:

  Word   Name        Description
  ----   ----------  ---------------------------------------------
  0      esync       0xacfe  sync word
  1      evnum       event number for this run
  2      evenergy    primary energy in GeV
  3      evazim      Azimuth * 100
  4      evzenith    Zenith *100
  5-7    (spares)
*/

{
  double moc_azim, moc_zen;
  ushort v;
  int i;

  /* Convert CORSIKA azimuth to (clockwise from grid N) and both
     angles to degrees */
  moc_azim = 180.0 - (*evazim*RAD2DEG) + MAG_DECL;
  while (moc_azim<0.0) moc_azim += 360.0;
  while (moc_azim>=360.0) moc_azim -= 360.0;
  moc_zen = *evzenith * RAD2DEG;

  /* DEBUG */
  printf ("STACEE: Event=%d, E=%f GeV, azimuth=%f, zenith=%f \n",
           *evnum,*evenergy,moc_azim,moc_zen);

  v=(ushort)ESYNC;
  wordwrite(&v);                                /* 0 */
  v=(ushort)(*evnum);
  wordwrite(&v);                                /* 1 */
  v=(ushort)(*evenergy);
  wordwrite(&v);                                /* 2 */
  v=(ushort)(moc_azim*100);
  wordwrite(&v);                                /* 3 */
  v=(ushort)(moc_zen*100);
  wordwrite(&v);                                /* 4 */
  v=(ushort)0;
  for(i=5;i<8;++i) {
    wordwrite(&v);
  }
  fflush(fp);
}

/*-------------------------------------------------------------------*/

#ifdef __REDHAT2__
void calc_time_offset__(heighp, obslev, evzenith)
#else
void calc_time_offset_(heighp, obslev, evzenith)
#endif
     double *heighp, *obslev, *evzenith;
{
  t0 = ((*heighp-*obslev)/cos(*evzenith))/SPEED_C;
}

/*-------------------------------------------------------------------*/

#ifdef __REDHAT2__
void photon_out__(x, y, nx, ny, ns, wave_len)
#else
void photon_out_(x, y, nx, ny, ns, wave_len)
#endif
     double *x,*y,*nx,*ny,*ns,*wave_len;
{

  /* NOTE: MOCCA and CORSIKA have different coordinate schemes
     MOCCA:    x = geogr. EAST,   y = geogr. NORTH
     CORSIKA:  x = magnet. NORTH, y = magnet. WEST
     But rotation is done in CORSIKA now.
  */

  int xpos_int, ypos_int, nx_int, ny_int, ld_int, ns_int;
  ushort word[6], ttop, xtop, ytop, bottom;

/*    Current Packing scheme (0xcabe):

        15 14 13 12 11 10  9  8  7  6  5  4  3  2  1  0
        _______________________________________________
        <------------ xpos (lower 16 bits) ----------->
        <------------ ypos (lower 16 bits) ----------->
        <------------ time (lower 16 bits) ----------->
        <-------------- nx (16 bits) ----------------->
        <-------------- ny (16 bits) ----------------->
        th tg xh xg yh yg <------- L (10 bits) ------->

 ref:  (xpos = xh xg xf xe xd xc xb xa x9 x8 x7 x6 x5 x4 x3 x2 x1 x0)
       (ypos = yh yg yf ye yd yc yb ya y9 y8 y7 y6 y5 y4 y3 y2 y1 y0)
       (time = th tg tf te td tc tb ta t9 t8 t7 t6 t5 t4 t3 t2 t1 t0)

*/

  ns_int = (*ns - t0 + 4000.0) * 20.0;
  if ((ns_int < 0) || (ns_int > MAX17)) return;		/* out of range */

  xpos_int = *x + BITS17;                               /* [x] = cm */
  if ((xpos_int < 0) || (xpos_int > MAX17)) return;	/* out of range */

  ypos_int = *y + BITS17;                               /* [y] = cm */
  if ((ypos_int < 0) || (ypos_int > MAX17)) return;	/* out of range */

  nx_int = (*nx + 1.0) * BITS15;
  if (nx_int < 0) {
     nx_int = 0;
  }
  else if (nx_int > MAX15) {
     nx_int = MAX15;
  }

  ny_int = (*ny  + 1.0) * BITS15;
  if (ny_int < 0) {
     ny_int = 0;
  }
  else if (ny_int > MAX15) {
     ny_int = MAX15;
  }

  ld_int = (int) (*wave_len + 0.5);


/* Copy lower 16 bits (0-15) of xpos, ypos and time into slots 15 to 0
   of words 1,2 and 3 */
   word[0]= MAX15 & (uint)(xpos_int);
   word[1]= MAX15 & (uint)(ypos_int);
   word[2]= MAX15 & (uint)(ns_int);
/* Copy lower 16 bits (0-15) of nx and ny into slots 15 to 0
   of words 4 and 5 */
   word[3]= MAX15 & (uint)(nx_int);
   word[4]= MAX15 & (uint)(ny_int);
/* The 6th word contains the top 2 bits of x, y and t, and the wavelength */
   ttop = (((196608) & (uint)(ns_int)) >> 2);
   xtop = (((196608) & (uint)(xpos_int)) >> 4);
   ytop = (((196608) & (uint)(ypos_int)) >> 6);
   bottom = (MAX9 & (uint)(ld_int));
   word[5] = ttop | xtop | ytop | bottom;


  if (fwrite(word,sizeof(ushort),6,fp)!=6) {  /* write data words to file */
    fprintf(stderr,"Error: stacee.c FAILED to write out binary data\n");
    exit(FAILURE);
  }
}

/*-------------------------------------------------------------------*/

void wordwrite(word)
     ushort *word;
{
  if (fwrite(word,sizeof(ushort),1,fp)!=1) {
    fprintf(stderr,"Error: stacee.c FAILED to write out binary data\n");
  }
}

/*-------------------------------------------------------------------*/

#ifdef __REDHAT2__
void finish_out__(void)
#else
void finish_out_(void)
#endif
{
  fclose(fp);
  printf("closing STACEE format binary output file\n");
}

