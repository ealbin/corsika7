/*-- Author :    P. Homola, Uni Krakow           22/11/2001*/
/*====================================================================*/

/*      preshw.c                                                      */

/*--------------------------------------------------------------------*/
/* HEADER DECLARATIONS & DEFINITIONS                                  */
#if defined(__GNUC__)&&__GNUC__ > 3
#include <stdlib.h>
#endif
#include <stdio.h>
#include <math.h>
/*--------------------------------------------------------------------*/
#define PI 3.141592653589793l
#define R_e 637131500.0l        /* earth radius in cm                 */
#define deg2rad PI/180.0;       /* degrees to radians                 */
#define rad2deg 180.0/PI;       /* radians to degrees                 */
#define c_light 29979245800.0l  /* speed of light in vacuum in cm/s   */
#define m_e 9.1093897e-28l      /* electron rest mass in g            */
#define m_e_erg_inv 1.22142e+6l /* inverse electron rest mass in ergs */
#define alpha_fs 0.00729735308l /* fine structure constant            */
                                /* (dimensionless)                    */
#define h_bar 1.054557266e-27l  /* Planck constant x 1/2PI (h-bar)    */
                                /* in erg*s (1J=10^7erg)              */
#define e_SI 1.60217733e-19l    /* elementary charge in C             */
#define e_CGS 4.803e-10l        /* elementary charge in CGS units;    */
                                /* 1C=2.998e+9 CGS units of charge    */
#define B_cr 4.414e+13l         /* critical magnetic field acc. to    */
                                /* Erber, Rev.Mod.Phys. 38 (1966) 626 */
                                /* B_cr=m_e^2*c^3/(e*h_bar) in G      */
#define eV2erg 1.60219e-12l     /* electronvolts to ergs              */
#define eV2GeV 1.0e-9l          /* eV to GeV                          */
#define GeV2erg 1.60219e-3l     /* GeV to ergs                        */
#define r0 2.8179409238e-13l    /* classical electron radius [cm]     */
#define km2cm 1.0e+5l           /* km to cm                           */
/*--------------------------------------------------------------------*/

float getrand(long *, int);     /* get random number from (0,1)       */
                                /* choosing an appropriate generator  */
float kappa(float);             /* auxiliary function used in brems-  */
                                /* strahlung calculation procedure    */
double brem(float, double, double);
                                /* computes bremsstrahlung radiation  */
void conv(double part_out[50000][7],int id);
                                /* computes gamma conversion probabil.*/
float B_transverse(double B[4], float tn[4]);
                                /* getting B component perpendicular  */
                                /* to the gamma trajectory            */
extern float ran2(long *);     /* random number generator used only  */
                                /* in stand-alone mode (Num. Recip.)  */
void cross(float a[4], float b[4], float c[4]);
                                /* cross product of vectors           */
float dot(float a[4], float b[4]);
                                /* dot product of vectros             */
void norm(float a[4], float n[4]);
                                /* returns normalized vector          */
float normv(float a[4]);        /* returns vector's length            */
void glob2loc(float glob[4], float loc[4], float theta, float phi);
                                /* conv. global cart. coord. to local */
void sph2car(float r_s[], float r_c[]);
                                /* converts spherical to cart. coords.*/
void car2sph(float car[4], float sph[4]);
                                /* inverse to sph2car                 */
void locsphC2glob(float locsph[4], float glob[4], float theta, float phi,
                  float sing, float cosg, float sitec[4]);
                                /* local spherical (CORSIKA frame) to */
                                /* global cart. coords.               */
double ppp(float efrac, float B_tr, float E_g0);
                                /* returns gamma convers. probability,*/
                                /*  used within ppfrac                */
float ppfrac(long *s, int corsika, float B_tr, float E_g0);
                                /* returns gamma convers. probability */
                                /* using ppp()                        */
#ifdef __REDHAT__
extern void igrf__(int *,int *,float *,float *,float *,float *,float *,
                   float *);    /* external procedure by Tsyganenko   */
#else
extern void igrf_(int *,int *,float *,float *,float *,float *,float *,
                  float *);     /* external procedure by Tsyganenko   */
#endif
                                /* computes magnetic field according  */
                                /* to the IGRF model, used within     */
                                /* b_igrf                             */
#ifdef __REDHAT__
extern void dbska__(double *,int *,int *,int *,double cernbess[101]);
#else
extern void dbska_(double *,int *,int *,int *,double cernbess[101]);
#endif
                                 /* external CERNlib bessel function  */
void b_igrf(int igrf_year, float igrf_r, float igrf_theta,
            float igrf_phi, double bcar[4]);
                                /* returns magn. field in sph. coords.*/
                                /*  accord. IGRF model using igrf_()  */
void bsph2car(float colat, float longit, float bsph[4], double bcar[4]);
                                /* converts b in spherical coords.    */
                                /* into B in cart. coords.,           */
                                /* used in b_igrf only                */
static double rndm();           /* calls random generator of CORSIKA  */

/*--------------------------------------------------------------------*/
/*------------------- PRESHOWER MAIN BODY ----------------------------*/
/*--------------------------------------------------------------------*/
/* in C language: float: 32 bits,  range 3.4*1e-38  to 3.4*1e+38      */
/*                double: 64 bits, range 1.7*1e-308 to 1.7*1e+308     */
/*--------------------------------------------------------------------*/
/* DESCRIPTION of the procedure:                                      */
/* Propagation of ultra high energy gamma before its entering the     */
/* earth's atmosphere is simulated, taking into account gamma         */
/* conversion into e+/- pair and subsequent bremsstrahlung of the     */
/* electrons in the geomagnetic field. As a result we obtain a bunch  */
/* (a preshower) of particles, mainly electrons and a few gammas,     */
/* instead of the primary gamma. The information about all the        */
/* particles in the preshower is returned to CORSIKA or saved (if in  */
/* stand-alone mode).                                                 */
/* Literature:                                                        */
/* P. Homola et al., Comp. Phys. Comm. 173 (2005) 71                  */
/* P. Homola et al., astro-ph/0311442 (2003)                          */
/*                                                                    */
/* Piotr Homola <Piotr.Homola@ifj.edu.pl>                             */
/*--------------------------------------------------------------------*/
/*                                                                    */
/* INPUT:                                                             */
/*  int *id: particle id (always id=1 (gamma))                        */
/*  double pE_gamma: initial energy of particle in GeV                */
/*  float *pthe_loc, *pphi_loc: zenith and azimuth angles of the      */
/*             shower (in radians) in the local coordinate system     */
/*             (as defined in CORSIKA)                                */
/*  float *ptoa: top of the atmosphere in cm                          */
/*  double *pglong: longitude position in deg. of experiment          */
/*             (Greenwich = 0., eastward is positive)                 */
/*  double *pglat:  latitude position in deg. of experiment           */
/*             (Northpole = +90., Southpole = -90.)                   */
/*  float *pigrf_year: the year in which the magnetic field is to be  */
/*             computed (this parameter is an input for the igrf      */
/*             procedure)                                             */
/*  int *iiprint: print flag = 0: suppress printing from preshw       */
/*                           = 1: enable   printing from preshw       */
/*  int *pcorsika:  1: source compatible with CORSIKA - random        */
/*                     generator from CORSIKA is used (rndm);         */
/*                  0: random generator from NR (ran2) ok for         */
/*                     stand-alone version                            */
/*  int *pnruns:    number of runs                                    */
/*                                                                    */
/* OUTPUT:                                                            */
/*  part_out: double array 50000x7, n: from 0 to the last secondary,  */
/*             max 49999:                                             */
/*  part_out[n][0]: particle id: 1 gamma, 2 e+, 3 e-                  */
/*  part_out[n][1]: Energy [GeV]                                      */
/*  part_out[n][2]: cos(pi_the_loc) for particle trajectory (not used */
/*             since all preshower particles are assumed to have      */
/*             trajectories the same as the primary particle)         */
/*  part_out[n][3]: pi_phi_loc as above                               */
/*  part_out[n][4]: t as above, relative to t=0 for prim. part.       */
/*             passing top of atm (not used since all the particles   */
/*             are assumed to enter the atmosphere at same time)      */
/*  part_out[n][5]: x_loc: coordinates of the particle in cm in the   */
/*             local system (not used - all preshower particles are   */
/*             assumed to have trajectories the same as the primary   */
/*             particle, thus x_loc=0 and y_loc=0)                    */
/*  part_out[n][6]: y_loc, related to the shower axis at the top of   */
/*             atmosphere (not used, see above)                       */
/*  float *r_zero: [km] height above sea level for the simulation     */
/*             starting point                                         */
/*  float *r_fpp: [km] height a.s.l. for the first pair production    */
/*             (0 for surviving gammas)                               */
/*  int *N_part_out: number of preshower particles at the top of the  */
/*             atmosphere (number of entries in part_out array)       */
/*--------------------------------------------------------------------*/
/* FRAMES of REFERENCE:                                               */
/* local: centered at the observatory site (theta,phi,R_earth)        */
/*            x-axis towards geogr. N, y-axis westward, z-axis upward */
/*            phi_local=0 for y=0, x>0                                */
/* local CORSIKA: centered at observatory site (theta,phi,R_earth)    */
/*             x towards magnetic North (along the projection of the  */
/*             local B line on the xy plane), y - westward, z-upward; */
/*             'local CORSIKA' is 'local' rotated around z-axis by    */
/*             DECLINATION angle (the angle between geographical      */
/*             North and the local direction to the magnetic North)   */
/*             phi_local=0 for y=0, x<0 (difference of 180 deg        */
/*             comparing to 'local')                                  */
/* global: centered in the Earth's center,                            */
/*             z - Earth's axis towards North, x - towards Greenwich, */
/*             y - eastward from x; phi=0 for y=0,x>0                 */
/*             (at Greenwich), theta=0 at geogr. North                */
/*====================================================================*/

#ifdef __REDHAT__
void preshw__(int *id, double *pE_gamma, float *pthe_loc,
              float *pphi_loc, float *ptoa, double *pglong,
              double *pglat, float *pigrf_year,
              int *iiprint, int *pcorsika, int *pnruns,
              double part_out[50000][7], float *r_zero, float *r_fpp,
              int *N_part_out)
#else
void preshw_(int *id, double *pE_gamma, float *pthe_loc,
             float *pphi_loc, float *ptoa, double *pglong,
             double *pglat, float *pigrf_year,
             int *iiprint,int *pcorsika, int *pnruns,
             double part_out[50000][7], float *r_zero, float *r_fpp,
             int *N_part_out)
#endif

/*--------------------------------------------------------------------*/
{
  float order,x,B_tr,r_0,theta,phi,r_curr,r_curr_0,
        r_step,E_slice,rand_b,rand,p_conv,the_loc,phi_loc,glong,
        glat,toa,tr_par,step_conv,step_brem,sing,cosg,the_deg,
        phi_deg,surv_percent,ppf,r1,r2;
  float wektor[4],vz[4],sites[4],sitec[4],r_loc[4],r_glob[4],
        r_glob_0[4],tn[4],B_site_f[4],B_site_loc[4],vy[4],vy_C[4],
        r_glob_sph[4];
  double Bglob[4],B_site[4];
  double alpha_gamma,unit_dist,Y_gamma,*i,*k,*di,*dk,i_ok,k_ok,di_ok,
         dk_ok,E_gamma,E_conv_tresh,chi_limit,E_prev,E_e,E_sg,E_sg0,
         I_brem,dE,E_int,E_ch,frac,Etot_g,Etot_e,Ee_max,Eg_max,E_0,
         prob_g,prob_factor,prob_brem_total,bess_arg,kk,T_Y;
  int file_part_out,multirun_file,ii,jj,mm,nrun,conversion,last_ii,
      first_conv,n_surv,n_phot,n_eplus,n_eminus,corsika,
      igrf_year,part_out_size,iprint;
  long *seed1,seed_ok;
  FILE *file_1,*file_3;
  char fname_1[30],fname_3[30];
  double cernbess[101];
  int bn1=1;
  int bd=3;
  int bnl=0;
/*-----------ADVANCED PARAMETERS, compile after changing -------------*/
  nrun=*pnruns;         /*number of runs                              */
  E_sg0=(1e+12)*eV2erg; /* preshower particles below this energy      */
                        /* level are neglected                        */
  r_0=5*R_e;            /* starting distance in Earth's radii (the    */
                        /* length of trajectory from the beginning to */
                        /* the Earth's surface)                       */
  step_conv=10*km2cm;   /* the step size for tracking the primary     */
                        /* gamma until its conversion                 */
  step_brem=km2cm;      /* the stepsize for tracking all the preshower*/
                        /* particles (after first conversion)         */
  multirun_file=0;      /* 1: if in multirun mode write output        */
                        /*    (n_surv, fpp,...) to file multirun.dat; */
                        /* 0: no writing                              */
  chi_limit=0.1;        /* a parameter important in computing         */
                        /* pair prod. function T                      */
  igrf_year=*pigrf_year;/* input parameter for the field routine      */
                        /* restrictions (limitations of the IGRF      */
                        /* routine): 1965 <= igrf_year <= 2005;       */
                        /* if one sets igrf_year outside this interval*/
                        /* the igr_year value is reset automatically  */
                        /* to the relevant limit, e.g. user sets      */
                        /* igrf_year=1960 -> the procedure resets     */
                        /* igrf_year=1965                             */
  iprint=*iiprint;      /* 1: printing enabled                        */
                        /* 0: printing disabled (but errors printed)  */
  corsika=*pcorsika;    /* 1: source compatible with CORSIKA - random */
                        /*    generator from CORSIKA is used (rndm);  */
                        /* 0: random generator from NR (ran2) ok for  */
                        /*    stand-alone version                     */
  file_part_out=0;      /* 1: part_out written to file part_out.dat;  */
                        /* 0: no writing                              */
  part_out_size=49999;  /* upper limit for the size of the preshower  */
                        /* array (part_out[][]); exit the program if  */
                        /* there are more particles than              */
                        /* part_out_size                              */
  E_conv_tresh=1e+16;   /* (eV) below this threshold gammas are not   */
                        /* checked for conversion                     */
/*--------------------------------------------------------------------*/
/*----------------- OPENING FILES ------------------------------------*/
/* open multirun file: a line contains the summary of a run           */
/*   (stand alone mode only)                                          */
/*--------------------------------------------------------------------*/
  if (multirun_file==1) {
    sprintf(fname_3,"multirun.dat");
    if ((file_3=fopen(fname_3,"w")) == NULL) {
      printf(" Can not open file<br>\n");
    }
  }
/*--------------------------------------------------------------------*/
/* a file to save data on each particle in the preshower at the top   */
/*  of atmosphere (toa) level:                                        */
/*--------------------------------------------------------------------*/
  if (file_part_out==1) {
    sprintf(fname_1,"part_out.dat");
    if ((file_1=fopen(fname_1,"w")) == NULL) {
      printf(" Can not open file<br>\n");
    }
  }
/*------------- read and preprocess input parameters -----------------*/
/* initial gamma energy in eV                                         */
  E_gamma=*pE_gamma/eV2GeV;     /* now E-gamma in eV                  */
  the_loc=*pthe_loc;            /* shower trajectory in radians       */
  phi_loc=*pphi_loc+PI;
/* in CORSIKA phi=0 means shower coming from magnetic SOUTH,          */
/* in preshower all calculations are made for phi=0 -> shower from    */
/* mag. NORTH, have to convert phi before starting simulations        */
  the_deg=the_loc*rad2deg;      /* shower trajectory in degrees       */
  phi_deg=phi_loc*rad2deg;
  phi_deg=phi_deg-360;          /* more suitable format               */
  toa=*ptoa;                    /* top of atmosphere                  */
/* geographical position of the observatory site in global spherical  */
/* coord. theta and phi                                               */
  glong=*pglong;                /* site longitude                     */
  glat=*pglat;                  /* site latitude                      */
  theta=(90.0-glat)*deg2rad;    /* site spherical theta, 0 at North   */
  phi=glong*deg2rad;            /* site spherical phi, 0 at Greenwich,*/
                                /* positive eastwards                 */
  sites[1]=R_e;                 /* sites: global spherical coords. of */
  sites[2]=theta;               /* the observatory                    */
  sites[3]=phi;
  sph2car(sites,sitec);         /* get sitec: global cart. coords. of */
                                /* the observatory                    */
/*------------ computing DECLINATION g -------------------------------*/
/* declination of the local magnetic field is the angle between the   */
/* local field and the local direction to the geographic north        */
/* (positive declination means that the local field points eastward   */
/* with respect to the geographic north (detailed definition at       */
/* www.ngdc.noaa.gov). Declination is needed to transform local       */
/* coordinates (for local frame see the CORSIKA manual) to the global */
/* ones.                                                              */

/* 1. get local B (B_site) vector in global coord.                    */
  b_igrf(igrf_year,sites[1],sites[2],sites[3],B_site);
/* input float: sites: site global, spherical coordinates             */
/* output double: B_site: local field vector in global cartesian      */
/* coordinates                                                        */

/* 2. convert B_site[] from double to float (B_site_f[]) to suit the  */
/*    format of glob2loc:                                             */
  B_site_f[1]=B_site[1];
  B_site_f[2]=B_site[2];
  B_site_f[3]=B_site[3];

/* 3. get B in local coords (B_site_loc)                              */
  glob2loc(B_site_f,B_site_loc,theta,phi);

/* 4. get normalized local CORSIKA y-axis (vy_C)                      */
/* local z axis: z axis in local cart. coords                         */
  vz[1]=0.0;
  vz[2]=0.0;
  vz[3]=1.0;
  cross(vz,B_site_loc,wektor);
  norm(wektor,vy_C);

/* 5. get the declination: the angle between vy and vy_C - using      */
/*    cross product of vy and vy_C                                    */
/* local y axis: y axis in local cart. coords                         */
  vy[1]=0.0;
  vy[2]=1.0;
  vy[3]=0.0;
  cross(vy,vy_C,wektor);
/* check the sign of the DECLINATION angle g                          */
  if (wektor[3]>0.0) {
    sing=normv(wektor);
  } else {
    sing=-normv(wektor);
  }
  cosg=dot(vy,vy_C);
/*------------ end of computing DECLINATION angle g ------------------*/

/*--------------------------------------------------------------------*/
/* getting the trajectory unit vector (tn[]) and length (r_zero):     */
/* and starting altitude                                              */
/* r_loc: starting point of primary gamma trajectory in local coords. */
  r_loc[1]=r_0;
  r_loc[2]=the_loc;
  r_loc[3]=phi_loc;
/* transform. r_loc to global coords -> r_glob_0                      */
  locsphC2glob(r_loc,r_glob_0,theta,phi,sing,cosg,sitec);
/* r_glob (starting point of the primary gamma trajectory in global   */
/* coord.) is used, together with sitec - geographical position of    */
/* the observatory - to find the unit vector tn[] of the gamma (and   */
/* subsequently preshower) trajectory                                 */
/*                                                                    */
/* unit vector of the preshower trajectory:                           */
  tn[1]=sitec[1]-r_glob_0[1];
  tn[2]=sitec[2]-r_glob_0[2];
  tn[3]=sitec[3]-r_glob_0[3];
  norm(tn,tn);
  r_curr_0=normv(r_glob_0);     /* the distance from the simulation   */
                                /* starting point to Earth's center   */
  *r_zero=(r_curr_0-R_e)/km2cm; /* simulation starting distance above */
                                /* sea level (in km)                  */

/*--------------------------------------------------------------------*/
/*                printing out preshower info                         */
/*--------------------------------------------------------------------*/
/* standard output */
  if (iprint==1) {
    printf(" ------------------ PRESHOWER ------------------- \n");
    printf(" B model: IGRF n = 10 year = %d \n", igrf_year);
    printf(" B[Gauss] in local cart. coord.: ");
    printf(" Bx = %5.3f, By = %5.3f, Bz = %5.3f \n",
             B_site_loc[1],B_site_loc[2],B_site_loc[3]);
    printf(" B[microTesla] in CORSIKA format: BX = %5.3f, BZ = %5.3f \n",
             100.*sqrt(B_site_loc[1]*B_site_loc[1]
                      +B_site_loc[2]*B_site_loc[2]),
            -100.*B_site_loc[3]);
    printf(" declination angle g: sin(g) = %f, cos(g) = %f\n",
           sing,cosg);
    if (corsika==1) {
      printf(" random generator: CORSIKA \n");
    } else {
      printf(" random generator: Numerical Recipes \n");
    }
    printf(" initial trajectory in local frame [deg]: ");
    printf(" zenith = %5.1f azimuth = %5.1f \n", the_deg, phi_deg);
    printf(" initial trajectory azimuth in CORSIKA [deg]: %5.1f \n",
             phi_deg+180);
    printf(" top of atmosphere from CORSIKA: %6.2f km \n", toa);
    printf(" site: longitude: %6.2f; latitude %6.2f \n", glong,glat);
    printf(" simulation starting altitude: %5.0f km a.s.l. \n",
           *r_zero);
    printf(" primary gamma energy: E_gamma = %8.2e eV \n",E_gamma);
    printf(" ------------------------------------------------ \n");
  }
/* part_out.dat header */
if (file_part_out==1) {
  fprintf(file_1," ------------------ PRESHOWER ------------------- \n");
  fprintf(file_1," B model: IGRF n = 10 year = %d \n", igrf_year);
  if (corsika==1) {
    fprintf(file_1," random generator: CORSIKA \n");
  } else {
    fprintf(file_1," random generator: Numerical Recipes \n");
  }
  fprintf(file_1," B[Gauss] in local cart. coord.: ");
  fprintf(file_1," Bx = %5.3f, By = %5.3f, Bz = %5.3f \n",
           B_site_loc[1],B_site_loc[2],B_site_loc[3]);
  fprintf(file_1,
         " B[microTesla] in CORSIKA format: BX = %5.3f, BZ = %5.3f \n",
    100.*sqrt(B_site_loc[1]*B_site_loc[1]+B_site_loc[2]*B_site_loc[2]),
         -100.*B_site_loc[3]);
  fprintf(file_1,
         " declination angle g: sin(g) = %f, cos(g) = %f\n",sing,cosg);
  fprintf(file_1,
         " primary gamma energy: E_gamma = %8.2e eV \n",E_gamma);
  fprintf(file_1," initial trajectory in local frame [deg]: ");
  fprintf(file_1,
         " zenith = %5.1f azimuth = %5.1f \n", the_deg, phi_deg);
  fprintf(file_1,
         " initial trajectory azimuth in CORSIKA format [deg]: %5.1f \n",
         phi_deg+180);
  fprintf(file_1," top of atmosphere: %6.2f km \n", toa);
  fprintf(file_1," site: longitude: %6.2f; latitude %6.2f \n",
         glong,glat);
  fprintf(file_1," simulation starting altitude: %5.0f km a.s.l. \n",
         *r_zero);
  fprintf(file_1," ------------------------------------------------ \n");
  fprintf(file_1," columns: \n");
  fprintf(file_1," 1. particle id (1-gamma/2-positron/3-electron) \n");
  fprintf(file_1," 2. particle energy [eV] \n");
  fprintf(file_1," ------------------------------------------------ \n");
}

/* multirun.dat header */
if (multirun_file==1) {
  fprintf(file_3," ------------------ PRESHOWER ------------------- \n");
  fprintf(file_3," B model: IGRF n = 10 year = %d \n", igrf_year);
  if (corsika==1) {
    fprintf(file_3," random generator: CORSIKA \n");
  } else {
    fprintf(file_3," random generator: Numerical Recipes \n");
  }
  fprintf(file_3," B[Gauss] in local cart. coord.: ");
  fprintf(file_3," Bx = %5.3f, By = %5.3f, Bz = %5.3f \n",
           B_site_loc[1],B_site_loc[2],B_site_loc[3]);
  fprintf(file_3,
     " B[microTesla] in CORSIKA format: BX = %5.3f, BZ = %5.3f \n",
     100.*sqrt(B_site_loc[1]*B_site_loc[1]+B_site_loc[2]*B_site_loc[2]),
     -100.*B_site_loc[3]);
  fprintf(file_3," declination angle g: sin(g) = %f, cos(g) = %f\n",
          sing,cosg);
  fprintf(file_3," primary gamma energy: E_gamma = %8.2e eV \n",
          E_gamma);
  fprintf(file_3," initial trajectory in local frame [deg]: ");
  fprintf(file_3," zenith = %5.1f azimuth = %5.1f \n",
          the_deg, phi_deg);
  fprintf(file_3,
     " initial trajectory azimuth in CORSIKA format [deg]: %5.1f \n",
     phi_deg+180);
  fprintf(file_3," top of atmosphere: %6.2f km \n", toa);
  fprintf(file_3," site: longitude: %6.2f; latitude %6.2f \n",
     glong,glat);
  fprintf(file_3," simulation starting altitude: %5.0f km a.s.l. \n",
     *r_zero);
  fprintf(file_3," ------------------------------------------------ \n");
  fprintf(file_3," columns: \n");
  fprintf(file_3," 1. run number \n");
  fprintf(file_3,
     " 2. altitude of the first gamma conversion in km a.s.l. \n");
  fprintf(file_3,
     " 3. total number of particles at the top of the atmosphere \n");
  fprintf(file_3," 4. number of gammas \n");
  fprintf(file_3," 5. number of electrons \n");
  fprintf(file_3," 6. maximum electron energy \n");
  fprintf(file_3," 7. maximum gamma energy \n");
  fprintf(file_3," 8. fraction of energy carried by electrons \n");
  fprintf(file_3,
     " 9. total energy carried by preshower particles = primary gamma energy \n");
  fprintf(file_3," 10. total energy carried by electrons \n");
  fprintf(file_3," 11. total energy carried by gammas \n");
  fprintf(file_3," ------------------------------------------------ \n");
}

/*------------------ INITIALIZATION ----------------------------------*/
first_conv=0;
i=&i_ok;
k=&k_ok;
di=&di_ok;
dk=&dk_ok;
x=0.0;
order=0.0;
n_surv=0;
n_phot=1;
n_eplus=0;
n_eminus=0;
seed_ok=-1000000;
seed1=&seed_ok;

/*--------------------------------------------------------------------*/
/*             PRESHOWER CREATION - main loop over # of runs          */
/*--------------------------------------------------------------------*/

for (mm=0;mm<nrun;mm++) {
/* initialize                                                         */
  tr_par=0.0;                   /* trajectory parameter, current path */
                                /* length travelled by the preshower  */
  n_phot=1;
  n_eplus=0;
  n_eminus=0;
  conversion=0;
  first_conv=0;
  jj=0;
  last_ii=0;                    /* highest not empty field in part_out*/
  r_step=step_conv;             /* initial simulation step            */
/* have to reload:                                                    */
  E_gamma=*pE_gamma/eV2GeV;     /* now E-gamma in eV                  */
  the_loc=*pthe_loc;
  phi_loc=*pphi_loc+PI;
/* in corsika phi=0 means shower coming from magnetic SOUTH, in       */
/* preshower all calculations are made for                            */
/* phi=0 -> shower from mag. NORTH,                                   */
/* have to convert phi from the CORSIKA format before starting        */
/* simulations                                                        */
/*--------------------------------------------------------------------*/
  if (iprint==1) {
    if (nrun >= 2) {
      printf(" preshower run: %d \n", mm+1);
    }
  }
/* initialization of preshower array part_out[];                      */
/* first row: the initial gamma (the input id is always 1)            */
  part_out[0][0]=*id;           /* particle id: 1 gamma, 2 e+, 3 e-   */
  part_out[0][1]=E_gamma;       /* Energy [eV]                        */
  part_out[0][2]=cos(the_loc);  /* particle zen. angle in local syst. */
  part_out[0][3]=phi_loc-PI;    /* particle azi. angle in local syst. */
/* PI: have to return phi in the convention of CORSIKA                */
  part_out[0][4]=0.0;           /* t as above                         */
  part_out[0][5]=0.0;           /* x_loc: coordinates of the particle */
                                /* in cm in the local system          */
  part_out[0][6]=0.0;           /* y_loc, related to the shower axis  */
                                /* at the top of atm.                 */
/* next rows: zeros for the beginning                                 */
  for (ii=1;ii<10000;ii++) {
    for (jj=0;jj<7;jj++) {
      part_out[ii][jj]=0.0;
    }
  }
  r_curr=r_curr_0;
/*--------------------------------------------------------------------*/
/* PRESHOWER propagation: LOOP 1:  over steps along the trajectory    */
/*  repetition until top of atmosphere is reached                     */
/*--------------------------------------------------------------------*/
  while (r_curr>R_e+toa*km2cm)
    {                           /* 1                                  */
    unit_dist=r_step;           /* update unit distance, equivalent to*/
                                /* the simulation step                */
    ii=0;                       /* initialize a counter               */
/* Get the current distance r_curr of the simulation point to the     */
/* Earth's center. Simulation point is taken always in the middle of  */
/* the propagation step (r_step) ->                                   */
    r1=tr_par;                  /* current distance along the track   */
    r2=r1+r_step;               /* current distance along the track   */
                                /* increased by the step              */
    tr_par=(r1+r2)/2;           /* the middle distance along the track*/
/* tr_par is updated to r2 at the end of this loop                    */
/* parametric equation of the trajectory                              */
    r_glob[1]=r_glob_0[1]+tr_par*tn[1];
    r_glob[2]=r_glob_0[2]+tr_par*tn[2];
    r_glob[3]=r_glob_0[3]+tr_par*tn[3];
/* current distance of the simulation point to the Earth's center     */
    r_curr=normv(r_glob);
/* get B component transverse to the particle motion (B_tr)           */
/* get B in IGRF model, Bglob                                         */
    car2sph(r_glob,r_glob_sph); /* as an input need position in       */
                                /* spher. coord.                      */
    b_igrf(igrf_year,r_glob_sph[1],r_glob_sph[2],r_glob_sph[3],Bglob);
    B_tr=B_transverse(Bglob,tn);/* transverse component of B in [G]   */
/*--------------------------------------------------------------------*/
/* PRESHOWER propagation: LOOP 2:  over preshower particles, exit     */
/*  when there is no entry in the particle array part_out[][]         */
/*--------------------------------------------------------------------*/

    while (part_out[ii][0]>0.0)
     {                          /* 2                for each particle */
/* switch to different particle types                                 */
     switch ((int)part_out[ii][0])
      {                         /* 3                                  */
      case 1:
/*--------------------------------------------------------------------*/
/*-----------------         GAMMA        -----------------------------*/
/*--------------------------------------------------------------------*/

      E_gamma=part_out[ii][1];  /* gamma energy in eV                 */
/* only gammas above threshold E_conv_tresh are checked if conversion */
/* occurred                                                           */
      if (E_gamma>E_conv_tresh)
       {                        /* 4                                  */
/* get conversion probability (Erber 66, Stanev 97)                   */
/* 1. pair production parameter - dimless (Stanev 97),                */
/*    E_gamma in eV, B_tr in G                                        */
        Y_gamma=E_gamma*eV2erg*B_tr*0.5/(m_e*c_light*c_light*B_cr);
/* note: Y_gamma is chi in Erber 66                                   */
/*--------------------------------------------------------------------*/
/* 2. pair production function T(Y_gamma):                            */
/* for low values of Y_gamma  better  use Erber 3.3c for eval. T,     */
/* ATTENTION: it is important which limit one takes for using         */
/* the simple form of T: e.g. using 0.5 instead of 0.1 the conversion */
/* probability can change (increase) even by several %                */
       if (Y_gamma<chi_limit) {
         T_Y=0.46*exp(-4/(3*Y_gamma)); /* Erber 3.3c                  */
       } else {
/* argument of modified Bessel function used below (Erber)            */
         bess_arg=2/(3*Y_gamma);
/* call of DBSKA: CERNLIB Bessel function of order 1/3                */
/* external numerical procedure calculating modified Bessel function  */
#ifdef __REDHAT__
         dbska__(&bess_arg,&bn1,&bd,&bnl,cernbess);
#else
         dbska_(&bess_arg,&bn1,&bd,&bnl,cernbess);
#endif
         kk=cernbess[0];
         T_Y=0.16*kk*kk*(1/Y_gamma);   /* pair production function,   */
                                       /* Erber 3.3d                  */
       }
/*--------------------------------------------------------------------*/
/* 3. gamma ray attenuation coefficient - fraction of gammas that     */
/* undergo pair production in transverse magnetic field B_tr,         */
/* per unit distance (cm), (Stanev (1), Erber (3.4))                  */
       alpha_gamma=0.5*alpha_fs*m_e*c_light*B_tr*T_Y/(h_bar*B_cr);
/*--------------------------------------------------------------------*/
/* 4. pair production probability over a distance unit_dist           */
       p_conv=alpha_gamma*unit_dist;
/*--------------------------------------------------------------------*/
       rand=getrand(seed1,corsika);    /* get random number           */
       if (rand<=p_conv) {
         conversion=1;          /* conversion flag                    */
/* determine 0<ppf<1: the fraction of energy assigned to each         */
/* particle in pair production process Daugherty, Astrophys. J., 1983 */
	 ppf=ppfrac(seed1, corsika, B_tr, E_gamma*eV2erg);
                                /* update part_out                    */
         part_out[ii][0]=2.0;   /* e+ replaces the gamma              */
         E_0=part_out[ii][1];   /* save primary energy to print later */
         part_out[ii][1]*=ppf;  /* energy of e+                       */
	 last_ii++;             /* one more particle appears, last_ii */
                                /* is the number of last entry in     */
                                /* part_out                           */
/* SECURITY: last_ii cannot exceed output array size part_out_size    */
         if (last_ii>part_out_size) {
	                        /* error message                      */
	   printf(" -----------------------------------\n");
           printf(" PRESHOWER ABORT: # of particles (%d) >", last_ii);
           printf("  the output array size \n");
	   exit(1);             /* exit the program                   */
	 }	
	 part_out[last_ii][0]=3.0; /* e- added at the end             */
         part_out[last_ii][2]=cos(the_loc);
                               /* particle direction: zenith          */
         part_out[last_ii][3]=phi_loc-PI;
                               /* particle direction: azimuth         */
         part_out[last_ii][1]=part_out[ii][1]*(1/ppf-1);
                               /* particle energy                     */	
                               /* print out some values               */
         if (iprint==1) {
	   printf(" conv.: %5.0Lf km a.s.l: ",(r_curr-R_e)/km2cm);
           printf(" Egamma = %8.2e -> Ee+ = %8.2e, Ee- = %8.2e \n",
                   E_0, part_out[ii][1],part_out[last_ii][1]);
           printf(" frac. = %4.2f\n", ppf);
         }
                               /* particle counters                   */
	 n_phot--;
	 n_eplus++;
	 n_eminus++;
         if (first_conv==0) {  /* saving distance for first pair prod */
	   *r_fpp=(r_curr-R_e)/km2cm;
	   first_conv=1;
	   r_step=step_brem;   /* change the step: use shorter step   */
                               /* for all  the next particles         */
	 }
       }                       /* end of pp & test_alpha conditions   */
       if ((conversion==0)&&(r_curr<R_e+toa*km2cm)) {
                               /* gamma did'n convert before entering */
                               /* the atmosphere                      */
            n_surv++;          /* count surviving gammas (in          */
                               /* imultirun  mode)                    */
            if (iprint==1) {
 	      printf(" gamma SURVIVED ! \n");
            }
            *r_fpp=toa;        /* first interaction at the top of     */
                               /* atmosphere (toa)                    */
       }
      }                        /* end conv_thresh condition / 4 /     */
      break;
      case 2:
/* no break: the same bremsstrahlung treatment done for cases 2 & 3   */
      case 3:
/*--------------------------------------------------------------------*/
/*-------       ELECTRON  (Sokolov, Ternov, 1986)     ----------------*/
/*--------------------------------------------------------------------*/

      E_e=part_out[ii][1]*eV2erg;
                               /* for calculations need E in ergs     */
      E_sg=E_sg0;              /* sg = secondary gamma, particles     */
                               /* below energy E_sg0 are neglected    */
      E_prev=E_sg;             /* initial 'previous' energy           */
/* calculate the total probability of emitting a bremsstrahl. gamma   */
/*  (sg) - prob_brem_total. - do a loop in log steps changing brem.   */
/*  gamma energy                                                      */
      prob_brem_total=0.0;     /* initialize total probability        */
      E_slice=0.01;            /* logarithmic step of integration the */
                               /* probability function                */
      while (E_sg*pow(10.0,E_slice)<E_e) {
                               /* loop over brem. gamma energies      */
        E_sg=E_sg*pow(10.0,E_slice);
                               /* current brem. gamma energy          */
/* spectral distribution of radiated energy: I_brem is the energy     */
/*   emitted into gammas of energies between E_sg and E_sg+dE,        */
/*   per unit distance:                                               */
/*   I_brem=(E_prev*dN)/(dE*unit_dist); dN, being the number of       */
/*   emitted gammas, below is used as probability of emitting a       */
/*   gamma - prob_g, small simulation step provides dN << 1           */
        I_brem=brem(B_tr,E_e,E_sg);
        dE=E_sg-E_prev;        /* in ergs                             */
        I_brem=I_brem*unit_dist;
                               /* energy emitted within               */
                               /* unit distance unit_dist             */
        prob_factor=dE/E_prev; /* auxilliary                          */
        prob_g=I_brem*prob_factor;
                               /* probability of emitting gamma of    */
                               /*energy in interval (E_sg, E_sg+dE)   */
        E_prev=E_sg;           /* save E_sg for the next round        */
        prob_brem_total=prob_brem_total+prob_g;
                               /* total probability emitting a gamma  */
      }
      rand_b=getrand(seed1,corsika);
                               /* get random number                   */
      if (rand_b<=prob_brem_total) {
/* if a gamma  was emitted its energy is determined by the spectrum   */
/* I_brem:                                                            */
/*  the probability density function, I_brem*unit_dist*prob_factor,   */
/*  is integrated until randomly chosen fraction is reached,          */
/*  the energy E_ch at which integration ends is assigned to newly    */
/*  emitted gamma  - most lines are the same as above in the calc. of */
/*  prob_brem_total                                                   */
        n_phot++;              /* increase gamma  counter             */
        rand_b=getrand(seed1,corsika);
                               /* get random number                   */
        E_int=0.0;             /* initialize integrated energy        */
        E_sg=E_sg0;
        E_prev=E_sg;
        E_slice=0.01;
        frac=0.0;
        while (frac<rand_b) {
          dE=E_sg*pow(10.0,E_slice)-E_sg;
          E_sg=E_sg*pow(10.0,E_slice);
          I_brem=brem(B_tr,E_e,E_sg);
          prob_factor=dE/E_prev;
          I_brem=I_brem*unit_dist*prob_factor;
	  E_int=E_int+I_brem;  /* integrated probab. dens. function  */
          frac=E_int/prob_brem_total;
                               /* normalized probability             */
          E_prev=E_sg;
        }
        E_ch=E_sg-dE;
/* the energy of the emitted particle: the last energy for which      */
/* integral E_int < rand_b*prob_brem_total                            */
/*      updating preshower particle array part_out[][]                */
        part_out[ii][1]-=E_ch/eV2erg;
                               /* update primary e energy             */
        last_ii++;             /* one more particle appears           */
/* SECURITY: last_ii cannot exceed the output array size part_out_size*/
        if (last_ii>part_out_size) {
	                       /* error message                       */
	  printf(" -----------------------------------\n");
          printf(" PRESHOWER ABORT: # of particles (%d) >", last_ii);
          printf("  the output array size \n");
	  exit(1);             /* exit the program                   */
	}	
        part_out[last_ii][0]=1.0;
                               /* a gamma  added at the end           */
        part_out[last_ii][2]=cos(the_loc);
                               /* particle direct.: cosine            */
        part_out[last_ii][3]=phi_loc-PI;
                               /* particle direct.: local azimuth     */
        part_out[last_ii][1]=E_ch/eV2erg;
                               /* gamma  energy                       */
      }                        /* end 'if a gamma  was emitted'       */
      break;
     };                        /* end 3 swich                         */
     ii++;
     if (first_conv==1) {
       first_conv=2;
       break;                  /* after the first conversion no need  */
                               /* to loop over particles              */
     }
    }                          /* end 2 while for each particle       */
    *N_part_out=last_ii+1;     /* # of entries in part_out array      */
    tr_par=r2;                 /* updating preshower track length     */
                               /* parameter                           */
  }                            /* end 1 after reaching toa            */
  Ee_max=0.0;                  /* reset maximum electron energy in run*/
  Eg_max=0.0;                  /* reset maximum gamma energy in run   */
  Etot_g=0.0;                  /* reset total energy in gammas        */
  Etot_e=0.0;                  /* reset total energy in e+/-          */
  jj=0;
/* store preshower particles data in a file, compute energy sums      */
/* (gammas and electrons) and maximum energies                        */
  while (part_out[jj][0]>0.0) {
    for (ii=0;ii<2;ii++) {
      if (file_part_out==1) {
        fprintf(file_1,"%8.2e ",part_out[jj][ii]);
      }
      if (ii==1) {             /* energy                              */
        if (part_out[jj][0]==1) {
          Etot_g+=part_out[jj][ii];
                               /* increase total energy in gammas     */
          if (Eg_max<part_out[jj][ii]) {
	    Eg_max=part_out[jj][ii];
                               /* update maximum gamma energy         */
	  }
        }
        if (part_out[jj][0]>1) {
          Etot_e+=part_out[jj][ii];
                               /* increase total energy in electrons  */
          if (Ee_max<part_out[jj][ii]) {
	    Ee_max=part_out[jj][ii];
                               /* update maximum electron energy      */
	  }
        }
      }
    }
    if (file_part_out==1) {
      fprintf(file_1,"\n");
    }
    part_out[jj][1]*=eV2GeV;   /* output energy in GeVs               */
    jj++;
  }
  if (iprint==1) {
    printf(" summary (energies in eV): \n");
    printf(" Etot_g = %8.2e, Etot_e = %8.2e, sum = %8.2e,", Etot_g,
            Etot_e, Etot_g+Etot_e);
    printf(" Eg_max = %8.2e, Ee_max = %8.2e\n", Eg_max,Ee_max);
  }
/* print to multi-run file                                            */
  if (multirun_file==1) {
    fprintf(file_3,
       "%3d %8.2f %4d %4d %2d %8.2e %8.2e %6.4f %8.2e %8.2e %8.2e \n",
           mm+1,*r_fpp,*N_part_out,n_phot,n_eplus+n_eminus,Ee_max,
           Eg_max,Etot_e/(Etot_g+Etot_e),Etot_g+Etot_e,Etot_e,Etot_g);
  }
  if (iprint==1) {
    if (corsika==0) {
      printf(" run = %d; first conv. at = %5.0f km a.s.l.,",
        mm+1,*r_fpp);
    }
    printf(" n_part = %d; n_phot = %d; n_e+ = %d; n_e- = %d \n",
            *N_part_out,n_phot,n_eplus,n_eminus);
  }
}                              /* end run loop                        */
/*--------------------------------------------------------------------*/
/*      PRESHOWER CREATION - end of main loop over # of runs          */
/*--------------------------------------------------------------------*/
/* in multi-run mode determine percentage of surviving (those which   */
/* didn't undergo pair-production) gamma                              */
if (iprint==1) {
  if (nrun >= 2) {
    surv_percent=(float)n_surv/(float)nrun;
    printf(" # of surviving gammas = %d; frac. = %f \n",
           n_surv,surv_percent);
  }
  printf(" --- END of PRESHOWER output -------------------- \n");
}
if (file_part_out==1) {fclose(file_1);}
if (multirun_file==1) {fclose(file_3);}
fflush(stdout);
fflush(stderr);
}
/*====================================================================*/
/*                 PROCEDURES AND FUNCTIONS                           */
/*====================================================================*/

float getrand(long *seed1, int corsika)

/*--------------------------------------------------------------------*/
/*  get random number from (0,1)                                      */
/* choose random number generator depending on the working mode:      */
/* PRESHOWER-CORSIKA: rnmd(0) - the same generator as in CORSIKA      */
/* PRESHOWER stand-alone - generator from Numerical Recipes           */
/*--------------------------------------------------------------------*/
{
   float rand;
   if (corsika==1) {              /* random generator: the one used   */
      rand = rndm(0);             /* in CORSIKA                       */
   } else {                       /* random generator from Numerical  */
      rand=ran2(seed1);           /* Recipes                          */
   }
   return rand;
}
/*====================================================================*/

float kappa(float x)

/*--------------------------------------------------------------------*/
/* Returns bremsstrahlung auxiliary function according to Erber       */
/* numerical values  (Table I, p. 632) + 0.003; 0.005; 3.0 from       */
/* calculations of Piotr Homola, the function is slightly modified in */
/* order to be used in computation of bremsstrahlung expression given */
/* by Sokolov.                                                        */
/* interpolation between points: linear                               */
/*--------------------------------------------------------------------*/
{
   int i;
   float kapp,x1,x2,y1,y2;
   float k[31][31]={
      {0.001,0.003,0.005,0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,
       0.1, 0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,
       1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0},
      {0.213,0.308,0.361,0.445,0.547,0.614,0.663,0.701,0.733,0.760,
       0.782,0.801,0.818,0.903,0.924,0.905,0.871,0.831, 0.788,0.742,
       0.696,0.651,0.3,0.129,0.053,0.0214,0.00845,0.00338,0.00129,
       0.00049,0.00019}
    };

   if (x<k[0][0]) {               /* k[0][0]=.001,approximation: x<<1 */
      kapp=2.1495*pow(x,1.0/3.0)-1.8138*x;
                                  /* (Erber A27)                      */
   } else if (x>=k[0][0] && x<=k[0][30]) {
                                  /* k[0][28]=10.0                    */
      for (i=0;i<31;i++) {
         if ((x>=k[0][i]) && (x<k[0][i+1])) {
                                  /* x between points i, i+1, linear  */
                                  /* interpolation                    */
            x1=k[0][i];
            x2=k[0][i+1];
            y1=k[1][i];
            y2=k[1][i+1];
            kapp=y1+(x-x1)*(y2-y1)/(x2-x1);
         }
      }
   } else if (x>k[0][30]) {      /* k[0][30]=10.0, approximation: x>>1*/
      kapp=1.2533*sqrt(x)*exp(-x);
                                 /* Erber A30                         */
   };
/* the below is different from kappa used for Erber bremsstrahlung    */
/* expression, in order to have the Sokolov's one we have to divide   */
/* original Erber's  kappa by its argument                            */
   kapp/=x;
   return kapp;
}
/*====================================================================*/

float B_transverse(double B[4], float tn[4])

/*--------------------------------------------------------------------*/
/* compute B component perpendicular to the preshower trajectory      */
/*--------------------------------------------------------------------*/
{
   float B_mod,B_ii,B_tr;
   B_mod=sqrt(B[1]*B[1]+B[2]*B[2]+B[3]*B[3]); /* B value              */
   B_ii=tn[1]*B[1]+tn[2]*B[2]+tn[3]*B[3];     /* B paralell (tn - unit*/
                                              /*   trajectory vector) */
   B_tr=sqrt(B_mod*B_mod-B_ii*B_ii);          /* B transverse         */
   return B_tr;
}
/*====================================================================*/

void cross(float a[4], float b[4], float c[4])

/*--------------------------------------------------------------------*/
/*    calculates vector cross product c = a x b                       */
/*--------------------------------------------------------------------*/
{
   c[1]=a[2]*b[3]-a[3]*b[2];
   c[2]=a[3]*b[1]-a[1]*b[3];
   c[3]=a[1]*b[2]-a[2]*b[1];
}
/*====================================================================*/

float dot(float a[4], float b[4])

/*--------------------------------------------------------------------*/
/* returns dot product of two vectors                                 */
/*--------------------------------------------------------------------*/
{
   return a[1]*b[1]+a[2]*b[2]+a[3]*b[3];
}
/*====================================================================*/

void norm(float a[4], float n[4])

/*--------------------------------------------------------------------*/
/* returns normalized vector                                          */
/*--------------------------------------------------------------------*/
{
   float av;
   av=sqrt(a[1]*a[1]+a[2]*a[2]+a[3]*a[3]);
   n[1]=a[1]/av;
   n[2]=a[2]/av;
   n[3]=a[3]/av;
}
/*====================================================================*/

float normv(float a[4])

/*--------------------------------------------------------------------*/
/* returns norm of a vector                                           */
/*--------------------------------------------------------------------*/
{
  return sqrt(a[1]*a[1]+a[2]*a[2]+a[3]*a[3]);
}
/*====================================================================*/

void glob2loc(float glob[4], float loc[4], float theta, float phi)

/*--------------------------------------------------------------------*/
/* converts global cartesian coords. to local cartesian               */
/* 3dim rotation                                                      */
/*--------------------------------------------------------------------*/
{
   loc[1]=glob[1]*cos(theta)*cos(phi)
         +glob[2]*cos(theta)*sin(phi)
         -glob[3]*sin(theta);
   loc[2]=glob[2]*cos(phi)-glob[1]*sin(phi);
   loc[3]=glob[1]*sin(theta)*cos(phi)
         +glob[2]*sin(theta)*sin(phi)
         +glob[3]*cos(theta);
}
/*====================================================================*/

void locsphC2glob(float locsph[4], float glob[4], float theta,
                  float phi, float sing, float cosg, float y[4])

/*--------------------------------------------------------------------*/
/* local spherical (CORSIKA frame) to global cart. coords.            */
/*--------------------------------------------------------------------*/
{
   float w[4],loc[4];
   sph2car(locsph,loc);              /* local spher. to local cart.   */
   w[1]=cosg*loc[1]-sing*loc[2];     /* rotation by declination angle */
   w[2]=cosg*loc[2]+sing*loc[1];
   w[3]=loc[3];
/* rotation by the geographic position angles                         */
   glob[1]=w[1]*cos(theta)*cos(phi)
          -w[2]*sin(phi)
          +w[3]*sin(theta)*cos(phi);
   glob[2]=w[1]*cos(theta)*sin(phi)
          +w[2]*cos(phi)
          +w[3]*sin(theta)*sin(phi);
   glob[3]=w[3]*cos(theta)-w[1]*sin(theta);
   glob[1]+=y[1];                    /* y[] are the observatory site  */
   glob[2]+=y[2];                    /* global carhesian coords.      */
   glob[3]+=y[3];
}
/*====================================================================*/

void sph2car(float r_loc_sph[], float r_loc_cart[])

/*--------------------------------------------------------------------*/
/* converts spherical to cartesian coords.                            */
/*--------------------------------------------------------------------*/
{
   r_loc_cart[1]=r_loc_sph[1]*sin(r_loc_sph[2])*cos(r_loc_sph[3]);
   r_loc_cart[2]=r_loc_sph[1]*sin(r_loc_sph[2])*sin(r_loc_sph[3]);
   r_loc_cart[3]=r_loc_sph[1]*cos(r_loc_sph[2]);
}
/*====================================================================*/

void car2sph(float car[4], float sph[4])

/*--------------------------------------------------------------------*/
/* inverse to sph2car                                                 */
/*--------------------------------------------------------------------*/
{
   double sq;
   sq=car[1]*car[1]+car[2]*car[2];
   sph[1]=(float)sqrt(sq+car[3]*car[3]);
   if (sq==0.0) {
      sph[3]=0.0;
      if (car[3]<0.0) {
         sph[2]=PI;
      } else {
         sph[2]=0.0;
      }
      return;
   }
   sq=sqrt(sq);
   sph[3]=(float)atan2(car[2],car[1]);
   sph[2]=(float)atan2(sq,car[3]);
   if (sph[3]<0.0) {
      sph[3]+=2*PI;
   }
   return;
}
/*====================================================================*/

void bsph2car(float colat, float longit, float bsph[4], double bcar[4])

/*--------------------------------------------------------------------*/
/*  calculates cartesian field components from spherical ones         */
/*  INPUT:   colat,longit - spherical angles of the point in radians  */
/*           bsph[4] -  spherical components of the field             */
/*           bcar[4] - cartesian components of the field              */
/* used in b_igrf only                                                */
/*--------------------------------------------------------------------*/
{
   float s,c,sf,cf,be;
   s=sin(colat);
   c=cos(colat);
   sf=sin(longit);
   cf=cos(longit);
   be=bsph[1]*s+bsph[2]*c;
   bcar[1]=be*cf-bsph[3]*sf;
   bcar[2]=be*sf+bsph[3]*cf;
   bcar[3]=bsph[1]*c-bsph[2]*s;
   return;
}
/*====================================================================*/

void b_igrf(int igrf_year, float igrf_r, float igrf_theta,
            float igrf_phi, double bcar[4])

/*--------------------------------------------------------------------*/
/* calling a fortran procedure IGRF by                                */
/* N.A.Tsyganenko, USRA, Greenbelt, USA                               */
/* IGRF - geomagnetic field model, www.ngdc.noaa.gov                  */
/*--------------------------------------------------------------------*/
{
   float br,btheta,bphi;
   float bsph[4];
   int n,iy;
   iy=igrf_year;                 /* year of the simulation            */
   n=10;                         /* highest order of spher. harmonics */
   igrf_r=igrf_r/R_e;            /* r in units of R_e                 */
/* call igrf routine (external, in fortran)                           */
#ifdef __REDHAT__
   igrf__(&iy,&n,&igrf_r,&igrf_theta,&igrf_phi,&br,&btheta,&bphi);
#else
   igrf_(&iy,&n,&igrf_r,&igrf_theta,&igrf_phi,&br,&btheta,&bphi);
#endif
   bsph[1]=(1e-5)*br;            /* change units to G                 */
   bsph[2]=(1e-5)*btheta;
   bsph[3]=(1e-5)*bphi;
/* need to transform from  B in spherical coords. to cartesian        */
   bsph2car(igrf_theta,igrf_phi,bsph,bcar);
/* returns bcar[]: magnetic field in global cart. coords.             */
}
/*====================================================================*/

double brem(float B_tr, double E_e, double E_sg)

/*--------------------------------------------------------------------*/
/* bremsstrahlung spectrum according to Sokolov                       */
/* B_tr: transverse magnetic field                                    */
/* E_e: electron energy                                               */
/* E_sg: energy of the emitted bremsstrahlung gamma                   */
/*--------------------------------------------------------------------*/
{
  double *i,*k,*di,*dk,i_ok,k_ok,di_ok,dk_ok,k_2_3_y,dy_dhv,
         kap_y,I_brem,ksi,y,fy,p3,Wcl;
  double cernbess[101];
  int bn2=2;
  int bd=3;
  int bnl=0;

  i=&i_ok;
  k=&k_ok;
  di=&di_ok;
  dk=&dk_ok;
  ksi=1.5*(B_tr/B_cr)*(E_e*m_e_erg_inv);
  y=E_sg/(E_e*ksi*(1.0-E_sg/E_e)); /* argument of Bessel function     */
/* call of DBSKA: CERNLIB Bessel function of order 2/3                */
/* external numerical procedure calculating modified Bessel function  */
#ifdef __REDHAT__
  dbska__(&y,&bn2,&bd,&bnl,cernbess);
#else
  dbska_(&y,&bn2,&bd,&bnl,cernbess);
#endif
  k_2_3_y=cernbess[0];

  p3=1.0+y*ksi;
  p3=pow(p3,3.0);
  kap_y=kappa(y);               /* Erber's kappa without multip. by y */
  fy=(kap_y+k_2_3_y*ksi*y*ksi*y/(1.+ksi*y))*(9.*sqrt(3.)/(8*PI))*y/p3;
  Wcl=B_tr*B_tr*E_e*E_e*r0*r0*m_e_erg_inv*m_e_erg_inv*2.0/3.0;
  dy_dhv=E_e/(ksi*(E_e-E_sg)*(E_e-E_sg));
  I_brem=fy*Wcl*dy_dhv;
  return I_brem;
}
/*====================================================================*/

double ppp(float efrac, float B_tr, float E_g0)

/*--------------------------------------------------------------------*/
/* returns pair production probability according to Daugherty'83      */
/* (equivalent to Erber'66 as shown in Tsai, Erber'74, this function  */
/* is used only  within ppfrac (computation of efrac) while in the    */
/* main program the probability is computed using expression Erber'66 */
/* E_g0 is the primary gamma energy                                   */
/* B_tr is the transverse B component                                 */
/* efrac is the fractional energy of one electron                     */
/*--------------------------------------------------------------------*/
{
  double *i,*k,*di,*dk,i_ok,k_ok,di_ok,dk_ok,k_2_3_y,ppprob;
  double y,chi,cernbess[101];
  int bn2=2;
  int bd=3;
  int bnl=0;

  i=&i_ok;
  k=&k_ok;
  di=&di_ok;
  dk=&dk_ok;
  chi=0.5*(B_tr/B_cr)*(E_g0*m_e_erg_inv); /* same as in Erber         */
  y=1.0/(3.0*chi*efrac*(1.0-efrac));      /* bessel function argument */
/* call of DBSKA: CERNLIB Bessel function of order 2/3                */
/* external numerical procedure calculating modified Bessel function  */
#ifdef __REDHAT__
  dbska__(&y,&bn2,&bd,&bnl,cernbess);
#else
  dbska_(&y,&bn2,&bd,&bnl,cernbess);
#endif
  k_2_3_y=cernbess[0];

  ppprob = k_2_3_y * m_e * c_light * alpha_fs * B_tr * sqrt(3.0)
           * (2.0+efrac*(1.0-efrac))
           /(h_bar*B_cr*9.0*PI*chi*efrac*(1.0-efrac));
                                         /* Eq. 19                    */
  return ppprob;
}
/*====================================================================*/

float ppfrac(long *s, int corsika, float B_tr, float E_g0)

/*--------------------------------------------------------------------*/
/* determines the fractional energy of a pair member,                 */
/* Daugherty, Astroph. J. 273, 1983                                   */
/*--------------------------------------------------------------------*/
{
  double ppprob,ppprob_max;
  float estep,efrac_i,r1,r2;
  int nestep,ii;
  estep=0.001;                   /* step in electron/positron energy  */
  nestep=ceil(0.5/estep)+1;      /* # of steps                        */
  efrac_i=0.0;
  ppprob_max=0;

  for(ii=1;ii<=nestep;ii++) {
    efrac_i=ii*estep;
    ppprob=ppp(efrac_i,B_tr,E_g0);
    if (ppprob_max<ppprob) {
      ppprob_max=ppprob;
    }
  }                              /* end of seeking maximum - needed   */
                                 /* for normalization                 */
  r1=getrand(s,corsika);
  r2=getrand(s,corsika);
  ppprob=ppp(r1,B_tr,E_g0)/ppprob_max;

/* get fractional energy of a pair member according to distribution   */
  while (r2>ppprob) {
    r1=getrand(s,corsika);
    r2=getrand(s,corsika);
    ppprob=ppp(r1,B_tr,E_g0)/ppprob_max;
  }
  return r1;
}
/*====================================================================*/
/*                         OTHER FUNCTIONS                            */
/*====================================================================*/

#ifdef __REDHAT__
extern void rmmard__(double *, int *, int *);
#else
extern void rmmard_(double *, int *, int *);
#endif

/*--------------------------------------------------------------------*/
/* external use of the RMMARD random number generator of CORSIKA      */
/* a function to call external rmmard_;                               */
/* returns random number from (0,1);  used only in CORSIKA mode       */
/*--------------------------------------------------------------------*/
static double rndm()
{
   static double rtmp[10];
   int num = 1;
   int seq = 2;                /* Use sequence number 2 of RMMARD     */
#ifdef __REDHAT__
   rmmard__(rtmp,&num,&seq);   /* Call Fortran subroutine             */
#else
   rmmard_(rtmp,&num,&seq);    /* Call Fortran subroutine             */
#endif
   return rtmp[0];
}
/*====================================================================*/
#define zero 0.

float ran2(long *idum)

/*--------------------------------------------------------------------*/
/* dummy routine                                                      */
/*--------------------------------------------------------------------*/
{ return zero;
}
