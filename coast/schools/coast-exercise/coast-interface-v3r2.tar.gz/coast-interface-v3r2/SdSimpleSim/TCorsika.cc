/***************************************************************************
 *                                                                         *
 *  Copyright and any other appropriate legal protection of these          *
 *  computer programs and associated documentation are reserved in         *
 *  all countries of the world.                                            *
 *                                                                         *
 *  These programs or documentation may not be reproduced by any method    *
 *  without prior written consent of Forschungszentrum Karlsruhe or its    *
 *  delegate. Commercial and military use are explicitly forbidden.        *
 *                                                                         *
 *  Forschungszentrum Karlsruhe welcomes comments concerning the REAS      *
 *  code but undertakes no obligation for maintenance of the programs,     *
 *  nor responsibility for their correctness, and accepts no liability     *
 *  whatsoever resulting from the use of its programs.                     *
 *                                                                         *
 ***************************************************************************/

#include <TCorsika.h>
#include <crs/CorsikaConsts.h>

#include <iostream>
#include <iomanip>

using namespace crs;
using namespace std;


const double TCorsika::fTopOfAtmosphere = 112.8292 * km;  // hardcoded from CORSIKA


TCorsika::TCorsika(double cosZenith, 
                   double height1,
                   double obsLevel,
                   bool slant, 
                   bool curved,
                   bool skimming) :
  fVerbosityLevel(0),
  fCosZenith(cosZenith),
  fHeightFirstInteraction(height1),
  fObservationLevel(obsLevel),
  fSlant(slant),
  fCurved(curved),
  fSkimming(skimming),
  heightTable(crlongi_.HLONG),
  depthTable(crslant_.THCKRL),
  distanceTable(crslant_.RLONG),
  TableLength(crlongi_.NSTEP+1),
  fDecreasingHeightTable(heightTable[TableLength-1]<heightTable[0])	// set to true if height is decreasing with increasing slant depth
 {
  
  if ((curved||skimming) && !slant) {
    cerr << " COAST: *************************** \n"
         << " COAST: ** \n"
         << " COAST: ** impossible to run \n"
         << " COAST: ** CURVED or SKIMMING geometries \n"
         << " COAST: ** without the SLANT option! \n"
         << " COAST: *************************** \n"
         << " COAST: aborting ... " << endl;
    exit(11);
  }

  // Check CRSLANT_ for existence
  
  if (curved||skimming) {
    const char* test = (char*) &crslant_;
    if (test[0]=='W' &&
        test[1]=='R' &&
        test[2]=='O' &&
        test[3]=='N' &&
        test[4]=='G') {
      cerr << " COAST: *************************** \n"
           << " COAST: ** \n"
           << " COAST: ** impossible to run \n"
           << " COAST: ** CURVED or SKIMMING geometries \n"
           << " COAST: ** without the SLANT option! \n"
           << " COAST: *************************** \n"
           << " COAST: aborting ... " << endl;
      exit(10);
    }
  }
}



// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//                slant depth profle interpolation
//
// slantDepth, distance: starting at top of atmosphere, 
//                       increasing in direction of motion of the shower
// vertical height: vertical height above sea level
// vertical depth:  vertical depth in gcm^-2
// 
// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

// universal irrespective of shower geometry
double TCorsika::GetVerticalDepthOfHeight(double height) const {
  // ---------------------------------------------------
  // pure vertical CORSIKA
  return thick_(height/cm)*g/cm/cm;
}


/*
  Get slant depth in a distance of the first interactionpoint
  in case of skimming incidence take tabulated atmosphere
*/
double TCorsika::GetSlantDepthOfDistance(double distance) const {
  // ---------------------------------------------------
  if (not fCurved)
  {
    // pure vertical CORSIKA
    double height = fTopOfAtmosphere - distance*fCosZenith;
    double vertDepth = thick_(height/cm) * g/cm/cm;
    return vertDepth / fCosZenith;
  }

  // take tabulated atmosphere
  return GetTabulatedSlantDepthOfDistance(distance/cm) * g/cm/cm;
}


double TCorsika::GetDistanceOfSlantDepth(double slantDepth) const {
  // ---------------------------------------------------
  if (not fCurved)
  {
    // pure vertical CORSIKA
    return (fTopOfAtmosphere - heigh_(slantDepth/g*cm*cm*fCosZenith)*cm) / fCosZenith; 
  }

  // take tabulated atmosphere
  return GetTabulatedDistanceOfSlantDepth(slantDepth/g*cm*cm) * cm;
}



double TCorsika::GetVerticalHeightOfDistance(double distance) const {

  // ---------------------------------------------------
  if (not fCurved)
  {
    // pure vertical CORSIKA
    return fTopOfAtmosphere - distance*fCosZenith;
  }

  // take tabulated atmosphere
  return GetTabulatedHeightOfDistance(distance/cm) * cm;
}


void TCorsika::DumpAtmosphereTable() const {

  // set up some plausibility tests to identify problems reading out common block
  double stepSize = (depthTable[crlongi_.NSTEP]-depthTable[0])/(TableLength-1);
  double previousDistance = -1.0;

  cout << " COAST: Atmosphere definition table for curved atmosphere: \n";
  for (int i=0; i<TableLength; ++i) {
    cout << " COAST:" 
         << " i=" << setw(4) << i
         << " h=" << setw(9) << heightTable[i]/100000 << " km, "
         << " d=" << setw(9) << distanceTable[i]/100000 << " km, "
         << " x=" << setw(5) << depthTable[i] << " g/cm2"
         << endl;

    // check if RLONG-table is strictly monotonously rising
    if (distanceTable[i] <= previousDistance)
    {
      cout << "Error: RLONG-table used in COAST is not strictly monotonous! "
           << "Aborting ...\n";
      exit(10);
    }
    else
    {
      previousDistance = distanceTable[i];
    }

    // check if THCKRL-table is equidistant
    if (fabs(depthTable[i]-i*stepSize)>(1.0e-5*stepSize))
    {
      cout << "Error: THCKRL-table used in COAST is not equidistantly spaced! "
           << "Aborting ...\n";
      exit(10);
    }
  }
}

double TCorsika::GetSlantDepthOfHeight(double height) const {
  if (fCurved) { 
    return GetTabulatedSlantDepthOfHeight(height/cm)*g/cm/cm; 
  }
  return GetSlantDepthOfDistance((fTopOfAtmosphere-height)/fCosZenith);
}

/*
double TCorsika::GetFirstLevelSlantDepth() const {
  if (fCurved) { 
    return GetTabulatedSlantDepthOfHeight(fHeightFirstInteraction/cm)*g/cm/cm; 
  }
  return GetSlantDepthOfDistance((fTopOfAtmosphere-fHeightFirstInteraction)/fCosZenith);
}*/


double TCorsika::GetLastLevelSlantDepth() const {
  if (fCurved) { 
    return GetTabulatedSlantDepthOfHeight(fObservationLevel/cm)*g/cm/cm; 
  }
  return GetSlantDepthOfDistance((fTopOfAtmosphere-fObservationLevel)/fCosZenith);
}

double TCorsika::GetHeightOfSlantDepth(double slantdepth) const
 {
  if (fCurved) { 
    return GetTabulatedHeightOfSlantDepth(slantdepth/g*cm*cm)*cm; 
  }
  return heigh_(slantdepth/g*cm*cm*fCosZenith)*cm;
}

double TCorsika::GetDistanceOfHeight(double height) const
 {
  if (fCurved) { 
    return GetTabulatedDistanceOfHeight(height); 
  }
  return (fTopOfAtmosphere-height)/fCosZenith;
}


long TCorsika::GetBin(double Value, double* Table) const
{
  // outside table?
  if ((Value < Table[0]) || (Value > Table[TableLength-1]))
  {
    std::cout << "\nError: Out of range in AtmoTable!\n";
    std::cout << "Asked for value " << Value << " when table covers values from " 
              << Table[0] << " to " << Table[TableLength-1] << ".\n";
    std::cout << "Aborting ...\n";
    exit(10);
  }

  long lastLowerBin = 0;
  long lastUpperBin = TableLength-1;
  long currentBin = TableLength/2;
  bool finished;
  do	// interval search for the correct bin
  {
    finished = true;
    if (Value < Table[currentBin])
    {
      lastUpperBin = currentBin;
      currentBin = (lastLowerBin+lastUpperBin)/2;
      finished = false;
    }
    else
    {
      if (Value > Table[currentBin+1])
      {
        lastLowerBin = currentBin;
        currentBin = (lastLowerBin+lastUpperBin)/2;        // cannot (and must not) point further than to second last bin (AtmoTableLength-2)
        finished = false;
      }
    }
  } while  (not finished);
  return currentBin;  // return index of next-lower bin
}

long TCorsika::GetBinReverse(double Value, double* Table) const
{
  // outside table?
  if ((Value > Table[0]) || (Value < Table[TableLength-1]))
  {
    std::cout << "\nError: Out of range in AtmoTable!\n";
    std::cout << "Asked for value " << Value << " when table covers values from " 
              << Table[0] << " to " << Table[TableLength-1] << ".\n";
    std::cout << "Aborting ...\n";
    exit(10);
  }

  long lastLowerBin = 0;
  long lastUpperBin = TableLength-1;
  long currentBin = TableLength/2;
  bool finished;
  do	// interval search for the correct bin
  {
    finished = true;
    if (Value > Table[currentBin])
    {
      lastUpperBin = currentBin;
      currentBin = (lastLowerBin+lastUpperBin)/2;
      finished = false;
    }
    else
    {
      if (Value < Table[currentBin+1])
      {
        lastLowerBin = currentBin;
        currentBin = (lastLowerBin+lastUpperBin)/2;        // cannot (and must not) point further than to second last bin (AtmoTableLength-2)
        finished = false;
      }
    }
  } while  (not finished);
  return currentBin;  // return index of next-lower bin
}



double TCorsika::GetTabulatedSlantDepthOfDistance (double distance) const
{
  if (fVerbosityLevel>=11) {
    cout << "TCorsika::GetTabulatedSlantDepthOfDistance d=" 
         << distance/m << " m" << endl;
  }
  long currentBin = GetBin(distance, distanceTable);
  double lowerD = distanceTable[currentBin];
  double upperD = distanceTable[currentBin+1];
  double lowerX = depthTable[currentBin];
  double upperX = depthTable[currentBin+1];
  // linear interpolation
  return (lowerX+(distance-lowerD)*(upperX-lowerX)/(upperD-lowerD));
}

double TCorsika::GetTabulatedDistanceOfSlantDepth (double slantdepth) const
{
  if (fVerbosityLevel>=11) {
    cout << "TCorsika::GetTabulatedDistanceOfSlantDepth x="
         << slantdepth << " g/cm2" << endl;
  }
  long currentBin = GetBin(slantdepth, depthTable);
  double lowerX = depthTable[currentBin];
  double upperX = depthTable[currentBin+1];
  double lowerD = distanceTable[currentBin];
  double upperD = distanceTable[currentBin+1];
  // linear interpolation
  return (lowerD+(slantdepth-lowerX)*(upperD-lowerD)/(upperX-lowerX));
}


double TCorsika::GetTabulatedHeightOfDistance (double distance) const
{
  if (fVerbosityLevel>=11) {
    cout << "TCorsika::GetTabulatedHeightOfDistance d="
         << distance/m << " m" << endl;
  }
  long currentBin = GetBin(distance, distanceTable);
  double lowerD = distanceTable[currentBin];
  double upperD = distanceTable[currentBin+1];
  double lowerH = heightTable[currentBin];
  double upperH = heightTable[currentBin+1];
  // linear interpolation
  return (lowerH+(distance-lowerD)*(upperH-lowerH)/(upperD-lowerD));
}

double TCorsika::GetTabulatedHeightOfSlantDepth (double slantdepth) const
{
  if (fVerbosityLevel>=11) {
    cout << "TCorsika::GetTabulatedHeightOfSlantDepth x="
         << slantdepth/g*cm*cm << " g/cm^2" << endl;
  }
  long currentBin = GetBin(slantdepth, depthTable);
  double lowerX = depthTable[currentBin];
  double upperX = depthTable[currentBin+1];
  double lowerH = heightTable[currentBin];
  double upperH = heightTable[currentBin+1];
  // linear interpolation
  return (lowerH+(slantdepth-lowerX)*(upperH-lowerH)/(upperX-lowerX));
}

double TCorsika::GetTabulatedSlantDepthOfHeight(double height) const
{
  if (fVerbosityLevel>=11) {
    cout << "TCorsika::GetTabulatedSlantDepthOfHeight h="
         << height/m << " m" << endl;
  }
  if (fSkimming)
  {
    cout << "\Error: Must not call TCorsika::GetTabulatedSlantDepthOfHeight() for skimming geometries!\n\nAborting ...\n";
    exit(10);
  }
  long currentBin = 0;
  if (fDecreasingHeightTable)
  {
    // "downward" going shower
    currentBin = GetBinReverse(height, heightTable);
  }
  else
  {
    // "upward" going shower
    currentBin = GetBin(height, heightTable);
  }

  double lowerH = heightTable[currentBin];
  double upperH = heightTable[currentBin+1];
  double lowerX = depthTable[currentBin];
  double upperX = depthTable[currentBin+1];
  // linear interpolation
  return (lowerX+(height-lowerH)*(upperX-lowerX)/(upperH-lowerH));
}

double TCorsika::GetTabulatedDistanceOfHeight(double height) const
{
  if (fVerbosityLevel>=11) {
    cout << "TCorsika::GetTabulatedDistanceOfHeight h="
         << height/m << " m" << endl;
  }
  if (fSkimming)
  {
    cout << "\Error: Must not call TCorsika::GetTabulatedDistanceOfHeight() for skimming geometries!\n\nAborting ...\n";
    exit(10);
  }
  long currentBin = 0;
  if (fDecreasingHeightTable)
  {
    // "downward" going shower
    currentBin = GetBinReverse(height, heightTable);
  }
  else
  {
    // "upward" going shower
    currentBin = GetBin(height, heightTable);
  }

  double lowerH = heightTable[currentBin];
  double upperH = heightTable[currentBin+1];
  double lowerD = distanceTable[currentBin];
  double upperD = distanceTable[currentBin+1];
  // linear interpolation
  return (lowerD+(height-lowerH)*(upperD-lowerD)/(upperH-lowerH));
}



double TCorsika::MoliereRadius(double VDepth,
                                      double Temperature) const {

  return 100.*m; // FIXED MOLIERE RADIUS

  /*
    static double E_scale = 21.*MeV;
    static double X_rad_length = 37*g/cm/cm;
    static double e_crit = 81.*MeV;
    static double R_m = E_scale * X_rad_length / e_crit;   // [g/cm2]

    // correct for 2 radiation length
    VDepth -= 2. * X_rad_length * fCosZenith;
    if (VDepth<=0) VDepth = 1.e-8;

    static double MeanAirDensity = 28.95 * g/mol;
    static double g_earth = 9.81 * m/(s*s);
    static double R_gas = 8.314 * joule/mol/Kelvin;
    static double Na = 6.022e23 / mol;
    double Pressure = VDepth * g_earth;
    double Density = Pressure / (R_gas*Temperature/MeanAirDensity);

    return R_m / Density;
  */
}


/*
  double TPlotter::MoliereRadius (double Temperature, 
  double Pressure) {
    
  static double exponent = 1./5.25588;
    
  Temperature /= Kelvin;
  Pressure /= millibar;
    
  double CorrectedPressure = Pressure - 73.94*fCosZenith;
  if (CorrectedPressure<=0) {
  //cout << " COAST: CorrectedPressure<0: " << CorrectedPressure << endl;
  //cout << " T: " << Temperature << " P: " << Pressure << endl;
  CorrectedPressure = 0.01;
  Pressure = CorrectedPressure + 73.94*fCosZenith;
  }

  double Rm = 272.5 * Temperature * 
  pow (CorrectedPressure/Pressure, exponent) / CorrectedPressure;
    
  return Rm * m;
  }
*/

double TCorsika::Temperature (double height) const {
  /*
    h1(km)   h2(km) 	dT/dh (K/km)
    0 	11 	-6.5
    11 	20 	0.0
    20 	32 	1.0
    32 	47 	2.8
    47 	51 	0.0
    51 	71 	-2.8
    71 	84.852 	-2.0

    Note: 84.852 km geopotential=86 km geometric

    These data along with the sea level standard values of
    Sea level pressure = 101325 N/m2
    Sea level temperature = 288.15 K
    Hydrostatic constant = 34.1631947 kelvin/km
    define the atmosphere. The sea level density of 1.225 kg/m3 is 
    derived from the fundamental quantities above
  */

  double temp = 288.15*Kelvin;

  if (height < 11*km) {

    temp += -6.5*(Kelvin/km) * height;
	
  } else if (height < 20*km) {

    temp += -6.5*(Kelvin/km) * 11*km;

  } else if (height < 32*km) {

    temp += -6.5*(Kelvin/km) * 11*km
      + 1.0*(Kelvin/km) * (height-20*km);

  } else if (height < 47*km) {

    temp += -6.5*(Kelvin/km) * 11*km
      + 1.0*(Kelvin/km) * (32*km-20*km)
      + 2.8*(Kelvin/km) * (height-32*km);

  } else if (height < 51*km) {

    temp += -6.5*(Kelvin/km) * 11*km
      + 1.0*(Kelvin/km) * (32*km-20*km)
      + 2.8*(Kelvin/km) * (47*km-32*km);

  } else if (height < 71*km) {

    temp += -6.5*(Kelvin/km) * 11*km
      + 1.0*(Kelvin/km) * (32*km-20*km)
      + 2.8*(Kelvin/km) * (47*km-32*km)
      - 2.8*(Kelvin/km) * (height-51*km);

  } else if (height < 84.852*km) {

    temp += -6.5*(Kelvin/km) * 11*km
      + 1.0*(Kelvin/km) * (32*km-20*km)
      + 2.8*(Kelvin/km) * (47*km-32*km)
      - 2.8*(Kelvin/km) * (71*km-51*km)
      - 2.0*(Kelvin/km) * (height-71*km);

  } else {

    temp += -6.5*(Kelvin/km) * 11*km
      + 1.0*(Kelvin/km) * (32*km-20*km)
      + 2.8*(Kelvin/km) * (47*km-32*km)
      - 2.8*(Kelvin/km) * (71*km-51*km)
      - 2.0*(Kelvin/km) * (84.852*km-71*km);

  }

  return temp;
	
}
