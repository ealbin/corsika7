/***************************************************************************
 *   Copyright (C) 2006 by Tim Huege                                       *
 *   tim.huege@ik.fzk.de, s.lafebre@astro.ru.nl                            *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <TFile.h>
#include <TH3D.h>
#include <TCanvas.h>
#include <TLine.h>
#include <TStyle.h>
#include <TTree.h>

#include <cmath>
#include <string>
#include <vector>
#include <map>
#include <sstream>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstdlib>

using namespace std;


void histprofile(string filename, string histtype);

void histprofile(string filename, string histtype)
{
    if ((histtype != "hA") && (histtype != "hT"))
    {
      cout << "\nError: specify either 'hA' for angle histograms or 'hT' for time histograms! Aborting ...\n\n";
      exit(10);
    }

    TFile *file = TFile::Open (filename.c_str(), "READ");
    
    TTree *dataTree = (TTree*)file->Get("data_layer");
    TTree *electree = (TTree*)file->Get ("data_electron");
    TTree *positree = (TTree*)file->Get ("data_positron");

    long layers = static_cast<long>(dataTree->GetEntries());

    Float_t rm, time, depth;
    dataTree->SetBranchAddress("rm", &rm);
    dataTree->SetBranchAddress("time", &time);
    dataTree->SetBranchAddress("depth", &depth);

    // map empty TH3D into TTree branch
    TH3D *pelechisto = 0;
    TH3D *pposihisto = 0;

    if (histtype == "hT")
    {
      electree->SetBranchAddress ("hTelectron", &pelechisto);
      positree->SetBranchAddress ("hTpositron", &pposihisto);
    }
    else
    {
      electree->SetBranchAddress ("hAelectron", &pelechisto);
      positree->SetBranchAddress ("hApositron", &pposihisto);
    }

    cout << "\n#depth\telectrons\tpositrons\t%ufx\t%ofx\t%ufy\t%ofy\t%ufz\t%ofz\n\n";


    double elecsum = 0.0, posisum = 0.0;
    for (int i = 0; i<layers; ++i)
    {
      dataTree->GetEntry (i);
      electree->GetEntry (i);
      positree->GetEntry (i);
      double elecintegral=0, posiintegral=0, ufx=0, ofx=0, ufy=0, ofy=0, ufz=0, ofz=0;
			for (long ii=0; ii<=pelechisto->GetNbinsX()+1; ++ii)
			{
				for (long j=0; j<=pelechisto->GetNbinsY()+1; ++j)
				{
					for (long k=0; k<=pelechisto->GetNbinsZ()+1; ++k)
					{
						double elecs = pelechisto->GetBinContent(pelechisto->GetBin(ii,j,k));
						double posis = pposihisto->GetBinContent(pposihisto->GetBin(ii,j,k));
						if (ii==0) { ufx+=elecs+posis; }
						if (ii==pelechisto->GetNbinsX()+1) { ofx+=elecs+posis; }
						if (j==0) { ufy+=elecs+posis; }
						if (j==pelechisto->GetNbinsY()+1) { ofy+=elecs+posis; }
						if (k==0) { ufz+=elecs+posis; }
						if (k==pelechisto->GetNbinsZ()+1) { ofz+=elecs+posis; }
						elecintegral += elecs;
						posiintegral += posis;
					}
				}
			}
      elecsum += elecintegral;
      posisum += posiintegral;
      ufx /= (elecintegral+posiintegral);
      ofx /= (elecintegral+posiintegral);
      ufy /= (elecintegral+posiintegral);
      ofy /= (elecintegral+posiintegral);
      ufz /= (elecintegral+posiintegral);
      ofz /= (elecintegral+posiintegral);
      cout << setw(6) << depth << "\t" << elecintegral << "\t" << posiintegral << "\t" << ufx << "\t" << ofx << "\t" << ufy << "\t" << ofy << "\t" << ufz << "\t" << ofz << "\n";
    }

    cout << "\n#elecsum: " << elecsum << "\tposisum: " << posisum << "\telec/posi: " << elecsum/posisum << "\n";

}

int main (int argc, char** argv) {

	if (argc != 3) {
		cout << "\nUsage: histprofile <histfile> <hT/hA>\n" << endl;
		return 0;
	}

	histprofile(argv[1],argv[2]);
	return 0;
}
