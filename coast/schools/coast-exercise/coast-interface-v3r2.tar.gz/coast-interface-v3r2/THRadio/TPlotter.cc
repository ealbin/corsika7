/***************************************************************************
 *                                                                         *
 *  Copyright and any other appropriate legal protection of these          *
 *  computer programs and associated documentation are reserved in         *
 *  all countries of the world.                                            *
 *                                                                         *
 *  These programs or documentation may not be reproduced by any method    *
 *  without prior written consent of Forschungszentrum Karlsruhe or its    *
 *  delegate. Commercial and military use are explicitly forbidden.        *
 *                                                                         *
 *  Forschungszentrum Karlsruhe welcomes comments concerning the REAS      *
 *  code but undertakes no obligation for maintenance of the programs,     *
 *  nor responsibility for their correctness, and accepts no liability     *
 *  whatsoever resulting from the use of its programs.                     *
 *                                                                         *
 ***************************************************************************/

/*
  RU, Do 23. Aug 12:42:47 CEST 2007
  TODO/CHECK
  - photon primaries are first tracked to their first interaction, then the
    Event-Header is passed to COAST -> COAST follows the first secondary to 
    its first interaction
  -> nuclear primaries first pass their Event-Header to COAST and are then 
     tracked to their first interaction.
  
  RU, Sa 11. Aug 19:06:01 CEST 2007 
  - changed security offset of last layer above the observation level
    from 1m to 1cm (1mm is too close and leads to a loss of particles already)
  - changed security offset for STACKIN from 1mm to 0.5mm (0,1mm is not enough)
  
  RU, Do 9. Aug 11:54:36 CEST 2007
  - fixed missing weight initialisation for weighted mean position calculations
  - fixed streaming of characters (version numbers + particle types)
  - added support for STACKIN
  - generally lift last histogram-layer 1m above the CORSIKA observation level, to
    assure getting the full shower particle data
  - since times, energies and radii are histogrammed lograithmically:
    added special treatment for values below zero 
    (->unphysical, log impossible, numerical problem)
    all data goes into the underflow-bins
  - started general cleanup of TPlotter data members and functions
  - added variances of mean <x> and <y> position
  - added division by zero check in calculation of mean <x> and <y>

*/

#include <TPlotter.h>
#include <TCorsika.h>

#include <crs/CorsikaConsts.h>
#include <crs/CParticle.h>
#include <crs/MEventHeader.h>
#include <crs/MEventEnd.h>
#include <crs/MRunHeader.h>
using namespace crs;

#include <COASTconfig.h>

#include <TFile.h>
#include <TTree.h>
#include <TH1D.h>
#include <TH2D.h>
#include <TH3D.h>
#include <TGraphErrors.h>
#include <TCanvas.h>
#include <TSystem.h>

#include <string>
#include <vector>
#include <map>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <cmath>
#include <cstdlib>
using namespace std;


/*
  
  Maybe:
  Use THCKSI instead of THICK for SLANT events ?

  Collection of CORSIKA function:

  // line 24578 (#if __SLANT__)
  //      DOUBLE PRECISION FUNCTION THCKSI( ARG )
  // C   ARG    = SLANT PATH IN CM (from top of atmosphere)


  // line 12473 (#if __CURVED__ && __SLANT__)
  //       DOUBLE PRECISION FUNCTION HEIGHTD(DIST,RADT)   
  // C   DIST    = SLANT DISTANCE TO THE OBS LEVEL (TO THE IMPACT POINT) (CM)
  // C   RADT    = IMPACT RADIUS (CM)


  // line 9960  (#if __CURVED__ && __SLANT__ )
  //       DOUBLE PRECISION FUNCTION DISTAND(H,RADT)
  // C   H       = HEIGHT ABOVE SEA LEVEL (CM)
  // C   RADT    = IMPACT RADIUS (CM)


  C  DEFINE HEIGHT FOR START AT THICK0 (IN G/CM**2)
  C  WHICH IS 112.8 KM FOR THICK0 = 0

 */


/* -------------------------------------------------------------------
   Define the particle names/types and CORSIKA ID here !!!!!!!!!!!!!!!!
*/
const unsigned int nParticles = 2;
//string particle_name [3] = {"EM", "Muon", "Hadron"};
string gParticle_name [nParticles] = {"electron", "positron"};//,"mu-","mu+"};
int gParticle_id      [nParticles] = {3, 2};//, 6, 5};
int gParticle_color   [nParticles] = {4, 2};//, 6, 5};
// -------------------------------------------------------------------



/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   
   - first find the point of the first interaction, and define the range
     where the shower should get histogramed

   - rotate all particles in shower coordinate system, with (0,0,0) at 
     the first interaction

   - define planes in equal slant depth bins 

   - fill histograms 
   
 */

TPlotter::TPlotter() {
  
  //fVerbosityLevel = 10;
  fVerbosityLevel = 0;

  fMaxInvalids = 10000;
  fTimeErrorMargin = 0.0;
  
  fPrimaryTrack = true;
  fPrimaryTrackFirst = true;
  
  fSlant = false;
  fCurved = false;
  fStackInput = false;
  
  fTimeUnderflow   = 0;
  fRadiusUnderflow = 0;
  fEnergyUnderflow = 0;
  fCountInvalid  = 0;
  
//itssavedemweight = 0;
//itssavedhdweight = 0;
  
  fCORSIKA = 0;
  
  Clear ();
  fDirectory = "";
    
  for (unsigned int j=0; j<nParticles; j++) {
    fParticles[gParticle_id[j]].name = gParticle_name[j];
    fParticles[gParticle_id[j]].color = gParticle_color[j];
  }
}



TPlotter::~TPlotter () {
  
  fParticles.clear();
  Clear();
  delete fFile;
}


void TPlotter::Welcome() const {
  cout << "\n"
       << "COAST: *************************************************\n"
       << "COAST: **                                               \n"
       << "COAST: ** You are using COAST-histogramming THRadio      \n"
       << "COAST: **    COAST version: " << VERSION << " \n"
       << "COAST: **  THRadio version: " << HISTOGRAMING_VERSION << " \n"
       << "COAST: **                                               \n"
       << "COAST: **  THIN/CURVED/SLANT/STACKIN: " << fThinning 
       << "/" << fCurved << "/" << fSlant << "/" << fStackInput << "\n"
       << "COAST: **                                               \n"
       << "COAST: *************************************************\n\n"
       << endl;

  /*
  if (fCurved) {
    cout << "\nError: CURVED option is not yet implemented in this version of COAST. Aborting ...\n\n";
    exit(10);
  }
  */
  
//  if (fSlant) {
//    cout << "\nError: SLANT option is not supported in this version of COAST. Aborting ...\n\n";
//    exit(10);
//  }
}




void TPlotter::Clear () {
  
  fPrimaryTrack = true;
  fPrimaryTrackFirst = true;
  fFirstInteractionX = 0;
  fFirstInteractionY = 0;
  fFirstInteractionZ = 0;
  
  fAxisX = 0;
  fAxisY = 0;
  fAxisZ = 0;
  
  fCosZenith = 0;
  fSinZenith = 0;
  fCosAzimuth = 0;
  fSinAzimuth = 0;
  
  fXmax = 0;
  fEventNo = 0;
  fObservationLevel = 0;
  fHeightFirstInt = 0;
  fZenith = 0;
  fAzimuth = 0;
  fShowerEnergy = 0;
  fShowerPrimary = 0;

  fCountInvalid = 0;
  
  fHists.clear();
  fLayerDepth.clear();
  fLayerHeight.clear();
  fZPlane.clear();
  fNhist = 0;

  fCORSIKA = 0;
}


void TPlotter::SetRunHeader (const crs::MRunHeader &header) {
  
  ostringstream ssTmp; 
  ssTmp.str(""); ssTmp << header.GetVersion();  fCorsikaVersion = ssTmp.str();
  ssTmp.str(""); ssTmp << VERSION;              fCoastVersion = ssTmp.str();
  ssTmp.str(""); ssTmp << HISTOGRAMING_VERSION; fHistVersion = ssTmp.str();
  
  SetRun ((int)header.GetRunID ());
  
  // create filename
  ostringstream fname;
  fname << "DAT" 
	<< setw (6) << setfill('0') << fRunNo;
  
  SetFileName(fname.str ());
}

void TPlotter::SetShowerHeader(const crs::MEventHeader &header) {
  
  if (header.GetSkimmingIncidence()) {
    fSkimming = true;
    fSkimmingAltitude = header.GetSkimmingAltitude() * cm;
    cout << " COAST: Detected skimming geometry with impact=" 
         << fSkimmingAltitude/m
         << " m" << endl;
  }
  
  // to flag the track of the primary particle
  fPrimaryTrack = true;
  fPrimaryTrackFirst = true;
  fFirstInteractionX = 0;
  fFirstInteractionY = 0;
  fFirstInteractionZ = 0;
  
  SetEvent(header.GetEventNumber());
  fShowerPrimary = (int)header.GetParticleID();
  
  SetShowerAxis(header.GetTheta()*rad, header.GetPhi()*rad);
  fShowerEnergy = header.GetEnergy()*GeV;
  
  fHeightFirstInt = header.GetZFirst()*cm;
  fObservationLevel = header.GetObservationHeight(header.GetNObservationLevels()-1)*cm;
  fObservationLevel += 10.*cm; // particles below the observation level are lost,
                              // therefore build in a 10cm safety margin to assure 
                              // getting the full particle data
  
  if (fHeightFirstInt<0) {
    if (fVerbosityLevel>=0) {
      cout << " COAST: height of first interaction is NEGATIVE, corrected." 
           << endl;
    }
    fHeightFirstInt = fabs(fHeightFirstInt);
  }
  
  cout  << " COAST: firstint " << fHeightFirstInt/m << "m\n"
        << " COAST: obslev " << fObservationLevel/m 
        << "m, including safety offset of 10cm" 
        << endl;
}


void TPlotter::SetShowerTrailer (const crs::MEventEnd &trailer) {
  fXmax = trailer.GetXmax()*g/cm/cm;
  if (!fSlant && fCosZenith!=0) fXmax /= fCosZenith;
  cout << " COAST: --------- shower end ------ \n"
       << " COAST: xmax: " << fXmax/g*cm*cm << "\n";
  if (fCountInvalid>0) 
    cout << " COAST: invalid-counter: " << fCountInvalid ;
  cout << endl;
}


void TPlotter::Init(int nBins, double maxRange) {
  
  fCORSIKA = new TCorsika(fCosZenith, 
                          fHeightFirstInt,
                          fObservationLevel,
                          fSlant, fCurved, fSkimming);
  if (fVerbosityLevel>0) fCORSIKA->SetVerbosityLevel(fVerbosityLevel);

  fNhist          = nBins;
  fMaxShowerRange = maxRange; // for skmimming geometries
  
  fLayerDepth.clear();
  fLayerHeight.clear();
  fZPlane.clear();
  
  if (fStackInput) { // STACKIN OPTION NEEDS SPECIAL TREATMENT !!!!
    // define safety margin to prevent invalid times (in front of shower front)
    // caused by rounding problems
    fTimeErrorMargin = 3.3e-3*ns;	// ignore time errors corresponding to ~1 mm before shower front
    double firstHeight = fHeightFirstInt;
    double firstDepth = fCORSIKA->GetSlantDepthOfHeight(firstHeight);
    SetFirstInteraction(0, 0, firstHeight, firstDepth, 0); // TODO
    CalculateSlices();
    fPrimaryTrack = false;
  }
  
  if (fCurved) {
    fCORSIKA->DumpAtmosphereTable();
  }
}


void TPlotter::CalculateSlices() {
  
  if (fVerbosityLevel>=10) { cout << "TPlotter::CalculateSlices" << endl; }
  
  // tell TCorsika the real starting point for histogramm layers
  //fCORSIKA->SetHeightOfFirstInteraction(fFirstInteractionZ);
  fCORSIKA->SetHeightOfFirstInteraction(fCORSIKA->GetHeightOfSlantDepth(fFirstInteractionSlantDepth));

  double zFirst = fFirstInteractionSlantDepth; 
  double zLast = 0;
  if (fSkimming) { zLast = zFirst += fMaxShowerRange*g/cm/cm;  }
  else {           zLast = fCORSIKA->GetLastLevelSlantDepth(); }
    
  double zUnit = g/cm/cm;
  string ModeStr = "slant depth = ";
  string UnitStr = "g/cm^2";
  
  cout << " COAST: start shower=" << zFirst/zUnit << " " << UnitStr
       << ", last histogram plane=" << zLast/zUnit << " " << UnitStr
       << endl;
  
  // --------------------------------------------------------------
  // decide where/what to plot
  
  
  ostringstream file_name;
  file_name << fDirectory
            << fFileName 
	    << "_"
	    << fEventNo
	    << ".hist.root";
  
  fFile = TFile::Open(file_name.str().c_str(), "RECREATE");
  fFile->cd ();
  
  int nBins = fNhist;
  double deltaSlice = (zLast-zFirst)/nBins;
  
  // --------------------------------------------------------------
  // create histogramms for each layer for this shower
  for (int i=0; i<nBins; ++i) {
    
    double zSlice = zFirst + deltaSlice*(i+1);
    
    /* ----------------
       height of planes in shower frame, with (0/0/0) at core (OBS level)
    */
    double zPlane = 0;
    //case eHeight:
    //zPlane = (zFirst-zLast) - (zFirst-zLast)/(nBins-1)*i;
    //break;
      
    zPlane = fCORSIKA->GetDistanceOfSlantDepth(zSlice); 
    
    fLayerDepth.push_back(fCORSIKA->GetSlantDepthOfDistance(zPlane));
    fLayerHeight.push_back(fCORSIKA->GetVerticalHeightOfDistance(zPlane));
    fZPlane.push_back(zPlane);
    
    if (fVerbosityLevel>=2) {
      cout << " COAST: plane " 
	   << " zSlice=" << zSlice/zUnit << UnitStr
	   << ", dist=" << zPlane/m << "m"
           << ", h=" << heigh_(zSlice/g*cm*cm*fCosZenith)*cm/km << "km"
	   << endl;
    }
    
    ostringstream h_title;
    h_title << ModeStr
	    << zSlice/zUnit
	    << " " << UnitStr;
    
    
    HistLayer hists; // this contains all histogramms for one layer

    // ------------------------------------------------------------------
    // loop over all particle types
    for (map<int,ParticleDef>::const_iterator iParticle = fParticles.begin();
	 iParticle != fParticles.end();
	 ++iParticle) {
      
      const string name = iParticle->second.name;
      const int color = iParticle->second.color;
      const int id = iParticle->first; // used as color
      
      ostringstream hT_name, hA_name, hE_name;
      hT_name << "hT_" << i << "_" << name;
      hA_name << "hA_" << i << "_" << name;
      hE_name << "hE_" << i << "_" << name;
      
      
      // --------------------------------------------------
      // generate histograms

      const int    nBinsTime  = 60;
      const double minLogTime = -3.0; // log10 (time/ns)
      const double maxLogTime = 4.5;  // log10 (time/ns)
      
      const int    nBinsR  = 50;
      const double minLogR = -3.; // log10 (r/100m) 
      const double maxLogR = 2.;  // log10 (r/100m) 
      
      const int    nBinsE  = 40;
      const double minLogE = -4.; // log10 (e/GeV)
      const double maxLogE = 2.;  // log10 (e/GeV)

      const int    nBinsZenith  = 50;
      const double minLogZenith = 0;   // [deg]
      const double maxLogZenith = 90;  // [deg]

      const int    nBinsAzimuth  = 36;
      const double minLogAzimuth = 0;    // [deg]
      const double maxLogAzimuth = 180;  // [deg]

      TH3D *histT = new TH3D (hT_name.str ().c_str (),
			      h_title.str ().c_str (),
			      nBinsTime, minLogTime, maxLogTime, 
			      nBinsR, minLogR, maxLogR,   
			      nBinsE, minLogE, maxLogE);  
      
      TH3D *histA = new TH3D (hA_name.str ().c_str (),
			      h_title.str ().c_str (),
			      nBinsZenith, minLogZenith, maxLogZenith, 
			      nBinsAzimuth, minLogAzimuth, maxLogAzimuth,
                              nBinsE, minLogE, maxLogE);  
      
      TH1D *histE = 0;
      //hE TH1D *histE = new TH1D (hE_name.str ().c_str (),
      //hE		      h_title.str ().c_str (),
      //hE		      200, -3.4, -2.7); // log10 (e/GeV)
      
      // --------------------------------------------------
      // for particles giving un-physical values because of
      // numerical problems, use these values to fill into
      // the underflow bin of the histogram
      fTimeUnderflow   = histT->GetXaxis()->GetXmin() - 1.0;
      fRadiusUnderflow = histT->GetYaxis()->GetXmin() - 1.0;
      fEnergyUnderflow = std::min(histT->GetZaxis()->GetXmin() - 1.0,
                                  histA->GetZaxis()->GetXmin() - 1.0);
      
      // --------------------------------------------------
      // set histogram properties
      histT->SetLineColor(color);
      histT->SetXTitle("log_{10}(time/ns)");
      histT->SetYTitle("log_{10}(r/100m)");
      histT->SetZTitle("log_{10}(E_{kin}/GeV)");

      histA->SetLineColor(color);
      histA->SetXTitle("theta/deg");
      //histA->SetYTitle ("log_{10}(r/100m)");
      histA->SetYTitle("phi/deg");
      histA->SetZTitle("log_{10}(E_{kin}/GeV)");
      
      //hE histE->SetLineColor (particle_id);
      //hE histE->SetXTitle ("log_{10}(E_{kin}/GeV)");
      
      // -------------------------------------------------
      // create data object for one layer
      hists[id] = Hists(histT, histA, histE);
      
      for (int iEnergyCenter = 0; iEnergyCenter<=nBinsE; ++iEnergyCenter) {
        Center center;
        center.x = 0;
        center.y = 0;
        center.w = 0;
        center.x2= 0;
        center.y2= 0;
        center.w2= 0;
        hists[id].center[iEnergyCenter] = center;
      }
    } // end loop particle types
    
    // -------------------------------------------------
    // collect all layers
    fHists.push_back(hists); 
    
  } // end loop layers
  
}







void TPlotter::Write () {

  if (fVerbosityLevel>=2) {
    cout << " COAST: Write " << endl;
    /*
    ostringstream gif_dir;
    gif_dir << fFileName 
	    << "_"
	    << fEventNo;
    */
  }

  fXmax /= g*cm*cm;

  // create the particle-string
  ostringstream particles_str;
  for (map<int,ParticleDef>::iterator iParticle = fParticles.begin ();
       iParticle != fParticles.end ();
       ++iParticle) {
    particles_str << iParticle->second.name << " ";
  }
  char *particles = const_cast<char*>(particles_str.str().c_str());
  
  fFile->cd ();
  TTree *run = new TTree ("shower", "shower");
  run->Branch ("xmax"    , &fXmax            , "xmax/F");
  run->Branch ("evntno"  , &fEventNo         , "eventno/I");
  run->Branch ("obslevel", &fObservationLevel, "obslevel/D");
  run->Branch ("firstint", &fHeightFirstInt  , "firstint/D");
  run->Branch ("zenith"  , &fZenith          , "zenith/F");
  run->Branch ("azimuth" , &fAzimuth         , "azimuth/F");
  run->Branch ("energy"  , &fShowerEnergy    , "energy/F");
  run->Branch ("primary" , &fShowerPrimary   , "primary/I");
  run->Branch ("particles" , &particles      , "particles/C");
  char *versionCorsika = const_cast<char*>(fCorsikaVersion.c_str());
  char *versionCoast   = const_cast<char*>(fCoastVersion.c_str());
  char *versionHist    = const_cast<char*>(fHistVersion.c_str());
  run->Branch ("corsika_version" , versionCorsika  , "corsika_version/C");
  run->Branch ("coast_version"   , versionCoast    , "coast_version/C");
  run->Branch ("thradio_version" , versionHist     , "thradio_version/C");
  run->Fill();
    
    
  Float_t time, slantDepth, dist, age, rm, temp, density, pressure;
  Float_t height;
  TTree *tree = new TTree ("data_layer", "General information of the layer");
  tree->Branch ("time"  , &time,   "time/F");
  tree->Branch ("depth" , &slantDepth,  "depth/F");
  tree->Branch ("dist", &dist, "dist/F");
  tree->Branch ("height", &height, "height/F");
  tree->Branch ("age"   , &age,    "age/F");
  tree->Branch ("rm", &rm, "rm/F");
  tree->Branch ("temp", &temp, "temp/F");
  tree->Branch ("pressure", &pressure, "pressure/F");
  tree->Branch ("density", &density, "density/F");
  
  
  // create hist trees for each particle type
  map<int,TTree *> trees;
  for (map<int,ParticleDef>::iterator iParticle = fParticles.begin ();
       iParticle != fParticles.end ();
       ++iParticle) {
	
    int id = iParticle->first;
    string name = iParticle->second.name;

    ostringstream tree_name, tree_info;
    tree_name << "data_" << name;
    tree_info << "All the histogramms for " << name;
    
    TTree *newTree = new TTree (tree_name.str ().c_str (), 
				tree_info.str ().c_str ());
    
    trees[id] = newTree;
  }

  bool firstFill = true;
  for (int i=0; i<fNhist; ++i) {

    for (map<int,ParticleDef>::iterator iParticle = fParticles.begin ();
	 iParticle != fParticles.end ();
	 ++iParticle) {
	
      int id = iParticle->first;
      string name = iParticle->second.name;

      TH3D *hT = 0;
      TH3D *hA = 0;
      //hE TH1D *hE = 0;
      
      hT = fHists[i][id].Time;
      hA = fHists[i][id].Angle;
      //hE hE = fHists [i][iParticle->second].Energy;
      
      vector<double> vCenter_E, vCenter_E_err;
      vector<double> vCenter_x, vCenter_x_err;
      vector<double> vCenter_y, vCenter_y_err;
      for (map<int,Center>::const_iterator iCenterBin 
             = fHists[i][id].center.begin();
           iCenterBin != fHists[i][id].center.end();
           ++iCenterBin) {
        
        int centerEnergyBin = iCenterBin->first;
        const Center& center = iCenterBin->second;
        
        double binEnergy = hT->GetZaxis()->GetBinCenter(centerEnergyBin);
        double binEnergyErr = 0;
        double center_x = 0;
        double center_y = 0;
        double center_x_err = 0;
        double center_y_err = 0;
        
        if (center.w>0) {
          
          center_x = center.x / center.w;
          center_y = center.y / center.w;
          
          double neff = pow(center.w, 2) / center.w2;
          
          double x_var = center.x2 / center.w - center_x*center_x;
	  if (x_var < 0.0) { x_var = 0.0; }	// correct rounding errors
          double x_rms = sqrt(x_var);
          center_x_err = x_rms / sqrt(neff);
          
          double y_var = center.y2 / center.w - center_y*center_y;
	  if (y_var < 0.0) { y_var = 0.0; }	// correct rounding errors
          double y_rms = sqrt(y_var);
          center_y_err = y_rms / sqrt(neff);

          vCenter_E.push_back(binEnergy);
          vCenter_E_err.push_back(binEnergyErr);
          vCenter_x.push_back(center_x);
          vCenter_y.push_back(center_y);
          vCenter_x_err.push_back(center_x_err);
          vCenter_y_err.push_back(center_y_err);
        }
      } // loop energy bins
      
      ostringstream bnameT, bnameA, bnameOx, bnameOy;
      ostringstream bnameL, bnameE;
      
      bnameT << "hT" << name;
      bnameA << "hA" << name;
      //hE bnameE << "hE" << iParticle->second;
      bnameOx << "offsetX_" << name;
      bnameOy << "offsetY_" << name;
      
      TGraphErrors* hOx 
        = new TGraphErrors(vCenter_E.size(),
                           &vCenter_E.front(), &vCenter_x.front(),
                           &vCenter_E_err.front(), &vCenter_x_err.front());
      TGraphErrors* hOy 
        = new TGraphErrors(vCenter_E.size(),
                           &vCenter_E.front(), &vCenter_y.front(),
                           &vCenter_E_err.front(), &vCenter_y_err.front());
      
      
      if (firstFill) {
        
	trees[id]->Branch(bnameT.str ().c_str (),
                          "TH3D",&hT, 32000, 0);
	trees[id]->Branch(bnameA.str ().c_str (),
                          "TH3D",&hA, 32000, 0);
	//hE trees[id]->Branch (bnameE.str ().c_str (),
	//hE 				  "TH1D",&hE, 32000, 0);
	trees[id]->Branch(bnameOx.str ().c_str (),
                          "TGraphErrors", &hOx, 32000, 0);
	trees[id]->Branch(bnameOy.str ().c_str (),
                          "TGraphErrors", &hOy, 32000, 0);

      } else {

	trees[id]->SetBranchAddress(bnameT.str().c_str(), &hT);
	trees[id]->SetBranchAddress(bnameA.str().c_str(), &hA);
	//hE trees[id]->SetBranchAddress(bnameE.str().c_str(), &hE);
	trees[id]->SetBranchAddress(bnameOx.str ().c_str (), &hOx);
	trees[id]->SetBranchAddress(bnameOy.str ().c_str (), &hOy);
      }
      
      time = (fZPlane[i]-fZPlane[0]) / crs::cSpeedOfLight;
      dist = fZPlane[i];  
      slantDepth = fLayerDepth[i]; 
      height = fLayerHeight[i];
      
      double T = fCORSIKA->Temperature(height);	
      rm = fCORSIKA->MoliereRadius(slantDepth*fCosZenith, T)/m;
      
      static double g_earth = 9.81 * m/(s*s);
      double Pressure = slantDepth * fCosZenith * g_earth;
      static double MeanAirDensity = 28.95 * g/mol;
      static double R_gas = 8.314 * joule/mol/Kelvin;
      double Density = Pressure / (R_gas*T/MeanAirDensity);
      
      temp = T;
      pressure = Pressure/bar;
      density = Density/g*cm*cm*cm;
      
      time /= ns;
      height /= km;
      dist /= km;
      slantDepth /= g*cm*cm;
      
      age = 3.0 / (1.0 + 2.0*fXmax/slantDepth); 
      
      trees[id]->Fill ();
      
      //hT->Print ();
      //hA->Print ();
    }
	
    tree->Fill ();
    firstFill = false;
	
    // delete hists
    for (map<int,ParticleDef>::iterator iParticle = fParticles.begin ();
	 iParticle != fParticles.end ();
	 ++iParticle) {
      int id = iParticle->first;
      delete (fHists [i][id].Time);
      delete (fHists [i][id].Angle);
      delete (fHists [i][id].Energy);

    }

  }
    
  run->Write ("", TFile::kOverwrite);
  tree->Write ("", TFile::kOverwrite);
  for (map<int,TTree*>::iterator iTree = trees.begin();
       iTree!=trees.end(); ++iTree) {
    iTree->second->Write("", TFile::kOverwrite);
  }
  fFile->Close ();
    
  // clean up
  Clear ();
}




// #define Rotate(x, y, sx, sy, cosa, sina) { 
inline
void TPlotter::Rotate (double x, double y, double z,
		       double &sx, double &sy, double &sz,
		       int inverse) {

  // rotate around z by azimuth
  double sx_ =             x*fCosAzimuth + inverse * y*fSinAzimuth;
  double sy_ = - inverse * x*fSinAzimuth +           y*fCosAzimuth; 
  double sz_ =   z;
  
  // rotate around y` by zenith
  double sx__ =             sx_*fCosZenith - inverse * sz_*fSinZenith;
  double sy__ = sy_;
  double sz__ = + inverse * sx_*fSinZenith +           sz_*fCosZenith; 

  // rotate back around z`` by -azimuth 
  sx =             sx__*fCosAzimuth - inverse * sy__*fSinAzimuth;
  sy = + inverse * sx__*fSinAzimuth +           sy__*fCosAzimuth; 
  sz =   sz__;

}


void TPlotter::AddTrack(const crs::CParticle &pre, 
			const crs::CParticle &post) {
  
  //hE int particleID0 = (int)pre.particleID;
  
  //hE if (fParticles.count(particleID0)) {
  //hE   string particle_name = fParticles [particleID0];
  //hE   fHists[0][particle_name].Energy
  //hE     ->Fill(log10(pre.energy), pre.weight);
  //hE }
  
  if (fVerbosityLevel>=9) {
    cout << " COAST:   PRE> "
	 << " id=" << (int)pre.particleID
	 << " E=" << pre.energy
	 << " w=" << pre.weight
	 << " x=" << pre.x << "cm"
	 << " y=" << pre.y << "cm"
	 << " z=" << pre.z << "cm"
	 << " t=" << pre.time*s/ns << "ns"
	 << " X=" << pre.depth << "g/cm^2"
	 << endl;
  }
  
  if (fVerbosityLevel>=10) {
    cout << " COAST:  POST> "
	 << " id=" << (int)post.particleID
	 << " E=" << post.energy
	 << " w=" << post.weight
	 << " x=" << post.x << "cm"
	 << " y=" << post.y << "cm"
	 << " z=" << post.z << "cm"
	 << " t=" << post.time*s/ns << "ns"
	 << " X=" << post.depth << "g/cm^2"
	 << endl;
  }
    
  /*
    Skip the track of the primary particle, which is in a different 
    reference system as the shower !!!
  */
  if (fPrimaryTrack) {
    
    if (fPrimaryTrackFirst) {
      fPrimaryTrackFirst = false;
      fPrimaryTrackEnergy = pre.energy;
      fPrimaryTrackId = (int)pre.particleID;
    }
  
    double dX_track = post.x - pre.x; 
    double dY_track = post.y - pre.y; 
    double dZ_track = post.z - pre.z; 
    double length_track = sqrt(pow(dX_track,2)+ 
                               pow(dY_track,2)+ 
                               pow(dZ_track,2));
    
    if (fabs(length_track)<1e-7) {
      ///cout << " COAST-error: this should never happen!" << endl;
      return; // pi0 could be the first secondary 
    }
    double cosZenith_track = -dZ_track/length_track;
    double azimuth = atan2(dY_track, dX_track);
    
    if (fVerbosityLevel>=5) {
      cout << " COAST-debug: cosZenith=" << cosZenith_track
           << " zenith=" << acos(cosZenith_track)/deg << " deg"
           << " azimuth=" << azimuth/deg << " deg"
           <<  endl;    
      
    } 

    if ((int)pre.particleID==fPrimaryTrackId &&
	pre.energy>=fPrimaryTrackEnergy*0.99999) {
      return;
    } 

//    if (fCurved) { SetShowerAxis(acos(cosZenith_track), azimuth); }
    SetFirstInteraction(pre.x, pre.y, pre.z, pre.depth*g/cm/cm, pre.time);
    CalculateSlices();
    
    if (fVerbosityLevel>=2) {
      cout << " COAST: Primary track end-pos: x=" << fFirstInteractionX/m 
	   << " y=" << fFirstInteractionY/m 
	   << " z=" << fFirstInteractionZ/m << endl;
    } else if (fVerbosityLevel>=1) {
      cout << " COAST: Primary track " << endl;
    }
    
    fPrimaryTrack = false;
  }
  
  /*   ------------------------
       convert to shower frame
       rotate around point of first interaction
  */
  double pre_shX, pre_shY, pre_shZ;
  Rotate(pre.x-fFirstInteractionX, pre.y-fFirstInteractionY, fFirstInteractionZ-pre.z, 
	 pre_shX, pre_shY, pre_shZ, +1);
  
  double post_shX, post_shY, post_shZ;
  Rotate(post.x-fFirstInteractionX, post.y-fFirstInteractionY, fFirstInteractionZ-post.z, 
	 post_shX, post_shY, post_shZ, +1);
  
  pre_shZ  += fFirstInteractionDist;
  post_shZ += fFirstInteractionDist;
  
  /*   ------------------------
       direction of particle in shower frame
  */
  double dX = post_shX - pre_shX; 
  double dY = post_shY - pre_shY; 
  double dZ = post_shZ - pre_shZ; 
  double length = sqrt (dX*dX + dY*dY + dZ*dZ);
    
  if (length==0) {
    /*   ------------------------ 
	 This happens for particles that are NOT tracked by Corsika
	 e.g. pi0 -> decay immediatly
	 SKIP them
    */
    return;
  }	
  
  double theta   = acos(dZ/length) * rad;
  double norm2Da = sqrt(pre_shX*pre_shX + pre_shY*pre_shY);
  double norm2Db = sqrt(dX*dX + dY*dY);
  double phi;
  if (norm2Da==0 && norm2Db!=0) {
    phi = 0.*deg; // this particles starts at the axis and moves outward
  } else if (norm2Db==0) {
    phi = -1.*deg; // this particles moves parallel to the axis
  } else {
    double arg = ((pre_shX*dX + pre_shY*dY) / (norm2Da * norm2Db));
    if (arg > 1.0) { arg = 1.0; } else if (arg < -1.0) { arg = -1.0; } // necessary to compensate for rounding errors
    phi = acos(arg) * rad;
  }
  
  
  
  // check for crossing of planes
  for (int iLayer=0; iLayer<fNhist; ++iLayer) {
	
    double zPlane = fZPlane[iLayer];
	
    if (fVerbosityLevel>=12) {
      cout << " COAST: plane=" << zPlane << "cm, pre=" << pre_shZ << "cm"
	   << " post=" << post_shZ << "cm";
    }
    
    if (!((pre_shZ<zPlane && post_shZ>zPlane) || 
	  (post_shZ<zPlane && pre_shZ>zPlane))) {
      if (fVerbosityLevel>=12) {
	cout << " no hit " << endl;
      }
      continue;
    }
    
    if (fVerbosityLevel>=12) {
      cout << " intersect plane=" << iLayer << endl;
    }
    
    
    double delta = (pre_shZ-zPlane) / (pre_shZ-post_shZ);	   
    
    double e_post = post.energy - gParticleMass[(int)post.particleID-1];
    double e_pre = pre.energy - gParticleMass[(int)pre.particleID-1];
    
    double dT = post.time - pre.time;
    double dE = e_post - e_pre;
    double dW = post.weight - pre.weight;

/* // debug output regarding weights
if (pre.particleID <= 3)
{
  if (pre.weight > itssavedemweight)
  {
    cout << "COAST: new max emweight is " << pre.weight << endl;
    itssavedemweight = pre.weight;
  }
}
else
{
  if (pre.weight > itssavedhdweight)
  {
    cout << "COAST: new max hdweight is " << pre.weight << endl;
    itssavedhdweight = pre.weight;
  }
}
*/
    
    double time = (pre.time + dT * delta); // * (s/ns);
    double energy = e_pre + dE * delta;
    double weight = pre.weight;
    double x = pre_shX + dX * delta;
    double y = pre_shY + dY * delta;
    //double z = pre_shZ + dZ * delta; 

    if (fVerbosityLevel>=10) {
      cout << " COAST: PLANE> "
           << " e_pre=" << e_pre
           << " e_post=" << e_post
           << " dT=" << dT
           << " dE=" << dE
           << " dW=" << dW
           << " delta=" << delta
           << "\n";    
    }
    
    
    double r = sqrt (pow (x, 2) + pow (y, 2));
    // double l = sqrt (pow (r, 2) + pow (z, 2));
	
    
    // times relative to what
    ///// //time -= l / crs::cSpeedOfLight;  // CURVED SHOWER FRONT
    time -= fFirstInteractionTime;
    time *= s/ns; // convert from seconds to nanoseconds
    time -= ((zPlane-fFirstInteractionDist)/crs::cSpeedOfLight);  // PLANE SHOWER FRONT
    // time -= (zPlane/crs::cSpeedOfLight);  // PLANE SHOWER FRONT
    
    if (fCountInvalid>=fMaxInvalids) {
	cout << " COAST: too many invalid histogram entries. Aborting simulation. Check your log file." 
	     << endl;
	exit(1);
    }

    if (time<=-fTimeErrorMargin) {
      cout << " COAST: invalid TIME: " 
           << time/ns << " ns (filling in underflow-bin)" << endl;
      cout << " Track-pre>  "; pre.Dump();
      cout << " Track-post> "; post.Dump();
      fCountInvalid++;
    }
    
    if (energy<=0) {
      cout << " invalid ENERGY: " 
           << energy << " GeV (filling in underflow-bin)" << endl;
      cout << " Track-pre>  "; pre.Dump();
      cout << " Track-post> "; post.Dump();
      fCountInvalid++;
    }
    
    if (r<=0) {
      cout << " invalid RADIUS: " 
           << r << " cm (filling in underflow-bin)" << endl;
      cout << " Track-pre>  "; pre.Dump();
      cout << " Track-post> "; post.Dump();
      fCountInvalid++;
    }
    
    
    const double r0 = 100.*m;
	
    int particleID = (int)pre.particleID;
    if (fParticles.count(particleID)) {
      
      string particle_name = fParticles[particleID].name;
      
      // calculate logarithm, and put to underflow bin if not possible
      double timeValue   = (time>0   ? log10(time/ns) : fTimeUnderflow);
      double radiusValue = (r>0      ? log10(r/r0)    : fRadiusUnderflow);
      double energyValue = (energy>0 ? log10(energy)  : fEnergyUnderflow);

      int energyBin 
        = fHists [iLayer][particleID].Time->GetZaxis()->FindBin(energyValue);
      
      fHists[iLayer][particleID].Time
	->Fill(timeValue, radiusValue, energyValue, weight);
      
      fHists[iLayer][particleID].Angle
	->Fill(theta/deg, phi/deg, energyValue, weight);
      
      /*
	fHists [iLayer][particle_name].Energy
	->Fill (energy,
	weight);
      */
            
      fHists[iLayer][particleID].center[energyBin].x += x * weight;
      fHists[iLayer][particleID].center[energyBin].y += y * weight;
      fHists[iLayer][particleID].center[energyBin].w += weight;
      fHists[iLayer][particleID].center[energyBin].x2+= x*x * weight;
      fHists[iLayer][particleID].center[energyBin].y2+= y*y * weight;
      fHists[iLayer][particleID].center[energyBin].w2+= weight*weight;
      
    }
  } 
}





TH1 *TPlotter::Interpolate3D (TH1* h1, double age1,
			      TH1* h2, double age2,
			      double age) {
  
    
  if (!((age<age1 && age>age2) ||
	(age<age2 && age>age1))) {
	
    cerr << " CANNOT interpolate because age is outside [age1,age2]." 
	 << " age=" << age << " age1="<<age1 << " age2=" << age2 
	 << "\n";
    return new TH3D ();	
  }
  
  ostringstream hName, hTitle;
  hName << h1->GetName ()
	<< "_interpol";
  hTitle << h1->GetTitle ()
	 << ", age=" << age;
    
  TH1 *h = (TH1*) h2->Clone (hName.str ().c_str ());
  
  h->Reset ("ICE");
  
  h->Add (h1, h2, std::fabs(age-age1), std::fabs(age-age2));
  h->SetTitle (hTitle.str ().c_str());
  
  return h;
}



void TPlotter::SetFirstInteraction(double x, double y, double z, double X, double t) {
  fFirstInteractionX = x;
  fFirstInteractionY = y;
  fFirstInteractionZ = z;
  fFirstInteractionTime = t;
  fFirstInteractionSlantDepth = X;
  fFirstInteractionDist = fCORSIKA->GetDistanceOfSlantDepth(fFirstInteractionSlantDepth);
//  fFirstInteractionDist = fCORSIKA->GetDistanceOfHeight(fFirstInteractionZ);

  cout << " COAST: fFirstInteractionDist=" << fFirstInteractionDist/m << "m "
       << ", fFirstInteractionZ=" << fFirstInteractionZ/m << "m "
       << ", fFirstInteractionSlantDepth=" << fFirstInteractionSlantDepth/g*cm*cm << "g/cm2 "
       << ", fFirstInteractionTime=" << fFirstInteractionTime << "s "
       << endl;
}


void TPlotter::SetShowerAxis(double zenith, double azimuth) {  
  cout << " COAST: zenith=" << zenith/deg << "deg"	
       << "   azimuth=" << azimuth/deg << "deg"	
       << endl;
  fZenith = zenith;
  fAzimuth = azimuth;
  fCosZenith = cos(zenith);
  fSinZenith = sin(zenith);
  fCosAzimuth = cos(azimuth);
  fSinAzimuth = sin(azimuth);
  fAxisZ = fCosZenith;
  fAxisX = fSinZenith * fCosAzimuth;;
  fAxisZ = fSinZenith * fSinAzimuth;
}


