#ifndef _crs_Plane_h_
#define _crs_Plane_h_

#include <crs/CParticle.h>


namespace crs {

  class Plane {
  public:
    Plane() : fD(0)
    { fPoint[0] = fPoint[1] = fPoint[2] = fNormal[0] = fNormal[1] = fNormal[2] = 0; }

    Plane(const double point[3], const double normal[3])
    {
      for (int i = 0; i < 3; ++i) {
        fPoint[i] = point[i];
        fNormal[i] = normal[i];
      }
      fD = Scalar(fPoint, fNormal);
    }

    Plane(const double x,  const double y,  const double z,
          const double nx, const double ny, const double nz)
    {
      fPoint[0] = x;
      fPoint[1] = y;
      fPoint[2] = z;
      fNormal[0] = nx;
      fNormal[1] = ny;
      fNormal[2] = nz;
      fD = Scalar(fPoint, fNormal);
    }

    double GetZ(const double x, const double y) const
    { return (fD - x * fNormal[0] - y * fNormal[1]) / fNormal[2]; }

    const double* GetPoint() const { return fPoint; }

    const double* GetNormal() const { return fNormal; }

    // note that p1 has to be on the normal side, p2 on the opposite
    // for efficiency p2 should be final point and normal oriented towards
    // incoming shower
    bool IsIntersecting(const CParticle& p1, const CParticle& p2) const
    { return Scalar(&p2.x, fNormal) <= fD && fD <= Scalar(&p1.x, fNormal); }

    // check for intersection and interpolate particle if true
    bool
    IsIntersecting(const CParticle& p1, const CParticle& p2, CParticle& interp)
      const
    {
      const double p2n = Scalar(&p2.x, fNormal);
      if (p2n <= fD) {
        const double p1n = Scalar(&p1.x, fNormal);
        if (fD <= p1n) {
          interp.particleID = p1.particleID;
          const double d1 = p1n - fD;
          const double d2 = p2n - fD;
          const double eps = d1 / (d1 - d2);
          const Interpolator interpolate(eps);
          // interpolate
          interp.x = interpolate(p1.x, p2.x);
          interp.y = interpolate(p1.y, p2.y);
          interp.z = interpolate(p1.z, p2.z);
          interp.time = interpolate(p1.time, p2.time);
          interp.energy = interpolate(p1.energy, p2.energy);
          interp.cosTheta = interpolate(p1.cosTheta, p2.cosTheta);
          interp.cosPhiX = interpolate(p1.cosPhiX, p2.cosPhiX);
          interp.cosPhiY = interpolate(p1.cosPhiY, p2.cosPhiY);
          interp.weight = p1.weight;
          return true;
        }
        return false;
      }
      return false;
    }

  private:
    // this should be a template since CDOUBLEPRECISION can change...
    template<typename T, typename U>
    static
    double
    Scalar(const T* x, const U* y)
    {
      double sum = 0;
      for (int i = 0; i < 3; ++i)
        sum += *(x++) * (*(y++));
      return sum;
    }

    class Interpolator {
    public:
      Interpolator(const double eps) : fEps1(1 - eps), fEps2(eps) { }
      double operator()(const double x1, const double x2) const
	{ return fEps1 * x1 + fEps2 * x2; }
    private:
      double fEps1;
      double fEps2;
    };

    double fPoint[3];
    double fNormal[3];
    double fD;
  };

}

#endif
