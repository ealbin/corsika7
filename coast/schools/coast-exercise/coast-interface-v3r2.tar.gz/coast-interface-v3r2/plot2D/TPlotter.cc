#include <TPlotter.h>

#include <crs/CorsikaConsts.h>
#include <crs/CParticle.h>
#include <crs/MEventHeader.h>
#include <crs/MEventEnd.h>
#include <crs/MRunHeader.h>
using namespace crs;

#include <TFile.h>
#include <TTree.h>
#include <TH1D.h>
#include <TH2D.h>
#include <TASImage.h>
#include <TH3D.h>
#include <TLine.h>
#include <TCanvas.h>
#include <TSystem.h>

#include <string>
#include <vector>
#include <map>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <cmath>
using namespace std;



typedef UInt_t CARD32;
typedef CARD32 ARGB32;

#if 1
#define MAKE_ARGB32(a,r,g,b)    ((( (CARD32)a)        <<24)|((((CARD32)r)&0x00FF)<<16)| \
                                     ((((CARD32)g)&0x00FF)<<8 )|(( (CARD32)b)&0x00FF))
#else
#define MAKE_ARGB32(a,r,g,b)    ((((a)&0x00FF)<<24)|(((r)&0x00FF)<<16)| \
                                     (((g)&0x00FF)<<8)|((b)&0x00FF))
#endif

#define MAKE_ARGB32_GREY(a,l)   (((a)<<24)|(((l)&0x00FF)<<16)| \
                                     (((l)&0x00FF)<<8)|((l)&0x00FF))
#define ARGB32_ALPHA8(c)        (((c)>>24)&0x00FF)
#define ARGB32_RED8(c)          (((c)>>16)&0x00FF)
#define ARGB32_GREEN8(c)        (((c)>>8 )&0x00FF)
#define ARGB32_BLUE8(c)         ( (c)     &0x00FF)
#define ARGB32_CHAN8(c,i)       (((c)>>((i)<<3))&0x00FF)
#define MAKE_ARGB32_CHAN8(v,i)  (((v)&0x0000FF)<<((i)<<3))

#define ARGB32_ALPHA16(c)       ((((c)>>16)&0x00FF00)|0x00FF)
#define ARGB32_RED16(c)         ((((c)>>8)&0x00FF00)|0x00FF)
#define ARGB32_GREEN16(c)       (( (c)    &0x00FF00)|0x00FF)
#define ARGB32_BLUE16(c)        ((((c)<<8)&0x00FF00)|0x00FF)
#define ARGB32_CHAN16(c,i)      ((ARGB32_CHAN8(c,i)<<8)|0x00FF)
#define MAKE_ARGB32_CHAN16(v,i) ((((v)&0x00FF00)>>8)<<((i)<<3))


/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   
   - first find the point of the first interaction, and define the range
     where the shower should get histogramed

   - rotate all particles in shower coordinate system, with (0,0,0) at 
     the first interaction

   - define planes in equal slant depth bins 

   - fill histograms 
   
 */

TPlotter::TPlotter() {
  fVerbosityLevel = 0;
  fFromGround = false;
  fPlotXmaxLevel = false;
  fPlotObservationLevels = false;
  fTopOfAtmosphere = 112.8 * km;  // from CORSIKA
  ReadInit();
  Clear ();
}



TPlotter::~TPlotter () {  
}



void TPlotter::Clear () {
  fPrimaryTrack = true;
  fPrimaryTrackFirst = true;
  fFirstParticleX = 0;
  fFirstParticleY = 0;
  fFirstParticleZ = 0;

  fAxisX = 0;
  fAxisY = 0;
  fAxisZ = 0;

  fCosZenith = 0;
  fSinZenith = 0;
  fCosAzimuth = 0;
  fSinAzimuth = 0;
  
  fEventNo = 0;
  fObservationLevel = 0;
  fHeightFirstInt = 0;
  fZenith = 0;
  fAzimuth = 0;
  fEnergy0 = 0;
  fPrimary = 0;
    
}

void TPlotter::ReadInit() {
  cout << " RU: **************** ReadInit ****************** " << endl;
  fXstart = -1.5*km;
  fXstop  =  1.5*km;
  
  fYstart = -0.1*km;
  fYstop  = 33.*km;
  double width  = fXstop-fXstart;
  double height = fYstop-fYstart;
  double pixelPerKm = 30.;
  fNX = int(width/km*pixelPerKm);
  fNY = int(height/km*pixelPerKm);
  fMaxRed   = 0;
  fMaxGreen = 0;
  fMaxBlue  = 0;
  fMinRed   = 0;
  fMinGreen = 0;
  fMinBlue  = 0;
  cout << " RU: w=" << width << " h=" << height << " nx=" << fNX << "ny=" << fNY << endl; 
}


void TPlotter::SetShowerZenith (float zenith) {
  cout << " RU: zenith/deg: " << zenith/deg << endl;
  fZenith = zenith*rad;
  fCosZenith = cos(zenith);
  fSinZenith = sin(zenith);
}



void TPlotter::SetShowerAzimuth (float azimuth) {
  cout << " RU: azimuth/deg: " << azimuth/deg << endl;
  fAzimuth = azimuth*rad;
  fCosAzimuth = cos(azimuth);
  fSinAzimuth = sin(azimuth);
}


void TPlotter::SetRunHeader (const crs::MRunHeader &header) {
  SetRun ((int)header.GetRunID ());
  // create filename
  ostringstream fname;
  fname << "DAT" 
	<< setw (6) << setfill('0') << fRunNo;
  SetFileName(fname.str ());
}


void TPlotter::SetShowerHeader (const crs::MEventHeader &header) {
  // to flag the track of the primary particle
  fPrimaryTrack = true;
  fPrimaryTrackFirst = true;
  fFirstParticleX = 0;
  fFirstParticleY = 0;
  fFirstParticleZ = 0;
  
  SetEvent (header.GetEventNumber ());
  SetPrimary ((int)header.GetParticleID ());
  SetShowerAxis(header.GetTheta ()*rad, header.GetPhi ()*rad);
  SetShowerEnergy (header.GetEnergy ()*GeV);
  SetHeightFirstInt (header.GetZFirst ()*cm);
  SetObservationLevel (header.GetObservationHeight (header.GetNObservationLevels ()-1)*cm);
  
  if (fHeightFirstInt<0) {
    if (fVerbosityLevel>=1) {
      cout << " RU: height of first interaction is NEGATIVE \n";
    }
    //fHeightFirstInt *= -1;
  }
  cout  << " RU: firstint " << fHeightFirstInt/m << "\n";
  cout  << " RU: obslev " << fObservationLevel/m << "\n";
}


void TPlotter::SetShowerTrailer(const crs::MEventEnd &trailer) {
  fXmax = trailer.GetXmax();
  fPrimaryTrack = true;
  fPrimaryTrackFirst = true;
}


void TPlotter::Init() {
  cout << " RU: **************** Init ****************** " << endl;
  ReadInit();
  int size = fNX*fNY;
  fRed   = new double[size];
  fGreen = new double[size];
  fBlue  = new double[size];
  for (int i=0; i<size; i++) {
    fRed[i] = 0;
    fBlue[i] = 0;
    fGreen[i] = 0;
  }
  fBgRed   = 255;
  fBgGreen = 255;
  fBgBlue  = 255;
}




void TPlotter::Write() {

  cout << " RU: **************** Write ****************** " << endl;

  if (fVerbosityLevel>=2) {
    cout << " RU: Write " << endl;
  }
  
 
  if (!fFromGround) {
    
    // const int bgColor = MAKE_ARGB32(255, fBgRed, fBgGreen, fBgBlue);
    
    cout << " maxRed="   << fMaxRed
	 << " maxGreen=" << fMaxGreen
	 << " maxBlue="  << fMaxBlue
	 << endl;
    
    double maxRed   = fMaxRed;
    double maxGreen = fMaxGreen;
    double maxBlue  = fMaxBlue;
    
    double maxTot = max(max(maxRed, maxGreen), maxBlue);
    //maxTot *= 0.001; // 1e10
    //maxTot *= 0.009; // 1e8
    //maxTot *= 0.04; // 1e6
    maxTot *= 0.2; // 1e4
    //maxTot *= 0.3; // 1e2
    maxRed   = maxTot;
    maxGreen = maxTot;
    maxBlue  = maxTot;
    
    // check color range
    for(int iX=0; iX<fNX; ++iX) {
      for(int iY=0; iY<fNY; ++iY) {
	int bin = iY*fNX + iX;
	if ((fRed[bin]>0 && fRed[bin] < fMinRed) || fMinRed==0) {fMinRed=fRed[bin];}
	if ((fGreen[bin]>0 && fGreen[bin] < fMinGreen) || fMinGreen==0) {fMinGreen=fGreen[bin];}
	if ((fBlue[bin]>0 && fBlue[bin] < fMinBlue) || fMinBlue==0) {fMinBlue=fBlue[bin];}
      }
    }
    
    cout << " minRed="   << fMinRed
	 << " minGreen=" << fMinGreen
	 << " minBlue="  << fMinBlue
	 << endl;
    
    double minRed   = fMinRed;
    double minGreen = fMinGreen;
    double minBlue  = fMinBlue;
    
    double minTot = min(min(minRed, minGreen), minBlue);
    minTot = 0;
    minRed   = minTot;
    minGreen = minTot;
    minBlue  = minTot;
    
    TASImage* img = new TASImage(fNX, fNY);
    UInt_t* data = img->GetArgbArray();
    for(int iX=0; iX<fNX; ++iX) {
      for(int iY=0; iY<fNY; ++iY) {
	
	int bin = (fNY-1-iY)*fNX + iX;
	int binOut = iY*fNX + iX;
	
	double red   = (maxRed   ? fRed[bin]/maxRed : 0.);
	double green = (maxGreen ? fGreen[bin]/maxGreen : 0.);
	double blue  = (maxBlue  ? fBlue[bin]/maxBlue : 0.);
	
	/*
	  double red   = (log(fRed[bin])-log(minRed))/(log(maxRed)-log(minRed));
	  double green = (log(fGreen[bin])-log(minGreen))/(log(maxGreen)-log(minGreen));
	  double blue  = (log(fBlue[bin])-log(minBlue))/(log(maxBlue)-log(minBlue));
	*/
	int redRGB   = fBgRed - int(green*255) - int(blue*255);
	int greenRGB = fBgGreen - int(red*255) - int(blue*255);
	int blueRGB  = fBgBlue - int(red*255) - int(green*255);

	
	if (redRGB<0)     redRGB = 0; 
	if (redRGB>255)   redRGB = 255;
	if (blueRGB<0)    blueRGB = 0; 
	if (blueRGB>255)  blueRGB = 255;
	if (greenRGB<0)   greenRGB = 0; 
	if (greenRGB>255) greenRGB = 255;
	
	int color = MAKE_ARGB32(255, redRGB, greenRGB, blueRGB);
	data[binOut] = color;
      
      }
    }
  
    double DY = (fYstop-fYstart) / fNY;
    
    if (fPlotXmaxLevel) {
      
      // -------------------------------------------------------------------
      // plot xmax level
      int yXmax  = int((heigh_(fXmax)-fYstart)/DY);
      cout << " RU: yXmax=" << yXmax << endl;
      for (int iX=0; iX<fNX; ++iX) {
      int binOut = (fNY-1-yXmax)*fNX + iX;
      data[binOut] = MAKE_ARGB32(255, 255, 50, 50);
      binOut = (fNY-yXmax)*fNX + iX;
      data[binOut] = MAKE_ARGB32(255, 255, 50, 50);
      }
      
    }
    
    
    if (fPlotObservationLevels) {
      
      // -------------------------------------------------------------------
      // plot observation level
      int yObs0  = int((0.*m-fYstart)/DY); // sea level
      int yObs1  = int((110.*m-fYstart)/DY); // kascade
      int yObs2  = int((1400.*m-fYstart)/DY); // auger
      int yObs3  = int((3300.*m-fYstart)/DY); // south pole
      cout << " RU: yObs=" << yObs1 << " " << fNY-1-yObs1 << endl;
      cout << " RU: yObs=" << yObs2 << " " << fNY-1-yObs2 << endl;
      for (int iX=0;iX<fNX; ++iX) {
	int binOut = (fNY-1-yObs0)*fNX + iX;
	data[binOut] = MAKE_ARGB32(255, 0, 0, 0);
	int binOut1 = (fNY-1-yObs1)*fNX + iX;
	data[binOut1] = MAKE_ARGB32(255, 0, 0, 0);
	int binOut2 = (fNY-1-yObs2)*fNX + iX;
	data[binOut2] = MAKE_ARGB32(255, 0, 0, 0);
	int binOut3 = (fNY-1-yObs3)*fNX + iX;
	data[binOut3] = MAKE_ARGB32(255, 0, 0, 0);
      }
    }
    
    
  
    TCanvas* c = new TCanvas("c", "c", fNX, fNY);
    c->Range(fXstart, fYstart, fXstop, fYstop);
    c->SetFillColor(0);
    /*
      TH2F* frame = new TH2F("frame", "frame", 2, fXstart, fXstop, 2, fYstart, fYstop);
      frame->SetXTitle("X     [cm]");
      frame->GetXaxis()->SetTitleOffset(1.5);
      frame->GetXaxis()->SetTicks("+-");
      frame->SetYTitle("Y     [cm]");
      frame->GetYaxis()->SetTitleOffset(1.5);
      frame->GetYaxis()->SetTicks("+-");
      frame->Draw();
    */
    img->Draw();
    /*
      TLine *line = new TLine(fXstart, heigh_(fXmax), fXstop, heigh_(fXmax));
      line->SetLineColor(103);
      line->SetLineWidth(2);
      line->Draw("same");
    */
    //frame->Draw("same");
    
    
    ostringstream outName;
    outName << fFileName << "_" << fEventNo << ".eps";
    c->Print(outName.str().c_str());
  }
  
  Clear (); // clean up
}




//#define Rotate(x, y, sx, sy, cosa, sina) { \
inline
void TPlotter::Rotate (double x, double y, double z,
		       double &sx, double &sy, double &sz,
		       int inverse) {

  // rotate around z by azimuth
  double sx_ =             x*fCosAzimuth + inverse * y*fSinAzimuth;
  double sy_ = - inverse * x*fSinAzimuth +           y*fCosAzimuth; 
  double sz_ =   z;
  
  // rotate around y` by zenith
  double sx__ =             sx_*fCosZenith - inverse * sz_*fSinZenith;
  double sy__ = sy_;
  double sz__ = + inverse * sx_*fSinZenith +           sz_*fCosZenith; 

  // rotate back around z`` by -azimuth 
  sx =             sx__*fCosAzimuth - inverse * sy__*fSinAzimuth;
  sy = + inverse * sx__*fSinAzimuth +           sy__*fCosAzimuth; 
  sz =   sz__;

}


void TPlotter::AddTrack(const crs::CParticle &pre, 
			const crs::CParticle &post) {
  
  int particleID0 = (int)pre.particleID;
    
  if (fVerbosityLevel>=9) {
    cout << " RU: PRE> "
	 << " id=" << (int)pre.particleID
	 << " E=" << pre.energy
	 << " w=" << pre.weight
	 << " x=" << pre.x << "cm"
	 << " y=" << pre.y << "cm"
	 << " z=" << pre.z << "cm"
	 << " t=" << pre.time*s/ns << "ns"
	 << " X=" << pre.depth << "g/cm^2"
	 << "\n";
  }
  
  if (fVerbosityLevel>=10) {
    cout << " RU: POST> "
	 << " id=" << (int)post.particleID
	 << " E=" << post.energy
	 << " w=" << post.weight
	 << " x=" << post.x << "cm"
	 << " y=" << post.y << "cm"
	 << " z=" << post.z << "cm"
	 << " t=" << post.time*s/ns << "ns"
	 << " X=" << post.depth << "g/cm^2"
	 << "\n";
    
  }
  
  
  /*
    Skip the track of the primary particle, which is in a different 
    reference system as the shower !!!
  */
  if (fPrimaryTrack) {
    
    if (fPrimaryTrackFirst) {
      fPrimaryTrackFirst = false;
      fPrimaryTrackEnergy = pre.energy;
      fPrimaryTrackId = (int)pre.particleID;
    }
    
    if (fPrimaryTrackId==(int)pre.particleID) {
      return;
    } 
    
    SetFirstInteraction(pre.x, pre.y, pre.z, pre.time);
    
    /*
      if (fHeightFirstInt<0) {
      fHeightFirstInt = pre.z;
      // hier weiter
      }
    */    
    
    if (fVerbosityLevel>=2) {
      cout << " RU: Primary track end-pos: x=" << fFirstParticleX/m 
	   << " y=" << fFirstParticleY/m 
	   << " z=" << fFirstParticleZ/m << "\n";
    } else if (fVerbosityLevel>=1) {
      cout << " RU: Primary track " << "\n";
    }
    
    fPrimaryTrack = false;
  }
   

  /*
  /*   ------------------------
       convert to shower frame
       rotate around point of first interaction
  */
  /*
  double pre_shX, pre_shY, pre_shZ;
  Rotate(pre.x-fFirstParticleX, pre.y-fFirstParticleY, fFirstParticleZ-pre.z, 
	 pre_shX, pre_shY, pre_shZ, +1);
  
  double post_shX, post_shY, post_shZ;
  Rotate(post.x-fFirstParticleX, post.y-fFirstParticleY, fFirstParticleZ-post.z, 
	 post_shX, post_shY, post_shZ, +1);
  */
  //pre_shZ  += fFirstParticleDist;
  //post_shZ += fFirstParticleDist;
  
  /*   ------------------------
       direction of particle in shower frame
  */
  /*
  double dX = post_shX - pre_shX; 
  double dY = post_shY - pre_shY; 
  double dZ = post_shZ - pre_shZ; 
  */
  double dX = post.x - pre.x; 
  double dY = post.y - pre.y; 
  double dZ = post.z - pre.z; 
  double length = sqrt (dX*dX + dY*dY + dZ*dZ);
    
  if (length==0) {
    /*   ------------------------ 
	 This happens for particles that are NOT tracked by Corsika
	 e.g. pi0 -> decay immediatly
	 SKIP them
    */
    return;
  }	
  

  // 0:red 1:green 2:blue
  int particleID = (int)pre.particleID;
  int color = 0;
  switch(particleID) {
      case 1:
      case 2:
      case 3:
        color = 0;
        break;
      case 4:
      case 5:
      case 6:
        color = 1;
        break;
      default:
        color = 2;
        break;
  }
  
  if (fVerbosityLevel>=2) {
    cout << " RU: *********** track c=" << color << " w=" << pre.weight 
         << " x1=" << pre.x*cm/km << " z1=" << pre.z*cm/km
         << " x2=" << post.x*cm/km << " z2=" << post.z*cm/km
         << endl;
  }
  
  DrawLine(color, pre.weight, pre.x*cm, pre.z*cm, post.x*cm, post.z*cm);  
}

void TPlotter::DrawLine(int color, double w,
                        const double x1, const double y1, 
                        const double x2, const double y2) {
  
  double DX = (fXstop-fXstart) / fNX;
  double DY = (fYstop-fYstart) / fNY;
  
  // pixel address
  double x1pix = (x1 - fXstart)  / DX;
  double y1pix = (y1 - fYstart)  / DY;
  double x2pix = (x2 - fXstart)  / DX;
  double y2pix = (y2 - fYstart)  / DY;
  
  // current pixel
  int xCurr = int(x1pix);
  int yCurr = int(y1pix);
  
  double dx = x2pix-x1pix;
  double dy = y2pix-y1pix;
  double dTot = sqrt(dx*dx + dy*dy);
  double dCurr = 0;
  
  int dxBin = (dx>0 ? +1 : -1);
  int dyBin = (dy>0 ? +1 : -1);
  if (dx==0) dxBin = 0;
  if (dy==0) dyBin = 0;
  double d = sqrt(dx*dx + dy*dy);
  if (d==0) return;
  dx /= d;
  dy /= d;
  
  //cout << " dx=" << dx << " dy=" << dy << endl;
  //cout << " NX=" << fNX << " NY=" << fNY << endl;
  
  
  while(true) {
    
    double xTest = xCurr + ( dx>0 ? 1 : 0);
    double yTest = yCurr + ( dy>0 ? 1 : 0);
    
    double faraway = 999999999;
    double d1 = faraway;
    double d2 = faraway;
    
    if (dx!=0) d1 = (xTest-x1pix) / dx;
    if (dy!=0) d2 = (yTest-y1pix) / dy;
    
    if (d1<0) d1 = faraway;
    if (d2<0) d2 = faraway;
    double dMin = min(d1,d2);
    dMin = min(dMin, dTot);
    double dPix = dMin - dCurr;

    /*
    cout << " xCurr=" << xCurr << " yCurr=" << yCurr 
         << " dTot="<< dTot << " d1=" << d1 << " d2=" << d2
         << " dCurr=" << dMin;
    */
  
    if (xCurr>=0 && yCurr>=0 &&
        xCurr<fNX && yCurr<fNY) {

      if (dPix*w<0) {
        cout << " smaler zero " << dPix << " " << w << endl;
      }
        
      int bin = (yCurr*fNX + xCurr);
      
      //cout << " bin=" << bin;
      
      if (color==0) {
        fRed[bin] += dPix*w;
        if (fRed[bin]>fMaxRed) fMaxRed = fRed[bin];
    
      } else if (color==1) {
        fGreen[bin] += dPix*w;
        if (fGreen[bin]>fMaxGreen) fMaxGreen = fGreen[bin];

      } else if (color==2) {
        fBlue[bin] += dPix*w;
        if (fBlue[bin]>fMaxBlue) fMaxBlue = fBlue[bin];
      }
    }

    //cout << endl;
    
    if (d1>dTot && d2>dTot) { // finished      
      break;
    }
    
    if (d1>d2) {
      if (dy>0) yCurr++;
      else yCurr--;
    } else {
      if (dx>0) xCurr++;
      else xCurr--;
    }
    
    dCurr = dMin;
    
  };
  
}


void TPlotter::SetFirstInteraction(double x, double y, double z, double t) {
  fFirstParticleX = x;
  fFirstParticleY = y;
  fFirstParticleZ = z;
  fFirstParticleTime = t;
}


void TPlotter::SetShowerAxis(double zenith, double azimuth) {  
  fZenith = zenith;
  fAzimuth = azimuth;
  fCosZenith = cos(zenith);
  fSinZenith = sin(zenith);
  fCosAzimuth = cos(azimuth);
  fSinAzimuth = sin(azimuth);
  fAxisZ = fCosZenith;
  fAxisX = fSinZenith * fCosAzimuth;;
  fAxisZ = fSinZenith * fSinAzimuth;
}



