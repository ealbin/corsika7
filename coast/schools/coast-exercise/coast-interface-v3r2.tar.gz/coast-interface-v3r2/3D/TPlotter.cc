#include <TPlotter.h>

#include <crs/CorsikaConsts.h>
#include <crs/CParticle.h>
#include <crs/MRunHeader.h>
#include <crs/MEventHeader.h>
#include <crs/MEventEnd.h>
using namespace crs;

#include <TFile.h>
#include <TCanvas.h>
#include <TView3D.h>
#include <TPolyLine3D.h>
#include <TSystem.h>
#include <TObjArray.h>

#include <TDOMParser.h>
#include <TXMLAttr.h>
#include <TXMLNode.h>

#include <string>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <cstdlib>
using namespace std;


TPlotter::TPlotter() {
  
  const string COAST_USER_LIB(gSystem->Getenv("COAST_USER_LIB"));
  const string COAST_DIR(gSystem->Getenv("COAST_DIR"));
  const string PWD(gSystem->Getenv("PWD"));
  
  TDOMParser* domParser = new TDOMParser();
  int parsecode = domParser->ParseFile((PWD+"/COAST3DConfig.xml").c_str());
  if (parsecode < 0) {
    if (COAST_USER_LIB != "")
      parsecode = domParser->ParseFile((COAST_USER_LIB+"/COAST3DConfig.xml").c_str());
    if (parsecode < 0) {
      if (COAST_DIR != "")
	parsecode = domParser->ParseFile((COAST_DIR+"/config/COAST3DConfig.xml").c_str());
      if (parsecode < 0) {	
	cerr << "\n ***********************************************\n"
	     << " * COAST-3D: XML-config error!\n"
	     << " * Message: \"" << domParser->GetParseCodeMessage(parsecode) << "\"\n";
	if (COAST_USER_LIB=="")
	  cerr << " *\n * Define COAST_USER_LIB environment variable ! \n";
	if (COAST_DIR=="")
	  cerr << " *\n * Define COAST_DIR environment variable ! \n";
	cerr << " *************************************************"
	     << endl;
	exit(2);
      } else {
	cout << "COAST> using config file: " << (COAST_DIR+"/config/COAST3DConfig.xml") << endl;
      }
    } else {
      cout << "COAST> using config file: " << (COAST_USER_LIB+"/COAST3DConfig.xml") << endl;
    }
  } else {
    cout << "COAST> using config file: " << (PWD+"/COAST3DConfig.xml") << endl;
  }    
  if (!ParseConfig(domParser->GetXMLDocument()->GetRootNode())) {
    cerr << "\n ***********************************************\n"
	 << " * COAST-3D: XML-config error!\n"
	 << " * Message: \"" << domParser->GetParseCodeMessage(parsecode) << "\"\n";    
    cerr << " *************************************************"
	 << endl;
    exit(2);
  }
  Clear();
}

TPlotter::~TPlotter() {
  Clear();
  delete fFile;
}

bool TPlotter::ParseConfig(TXMLNode* config) { 
  if (string(config->GetNodeName()) != "COAST3DConfig") {
    cerr << "Bad configuration file (\"" << config->GetNodeName() << "\") for COAST3D " 
	 << endl;
    return false;
  }
  for (TXMLNode* node = config->GetChildren(); node; node = node->GetNextNode()) {
    if (node->GetNodeType() == TXMLNode::kXMLElementNode) { // Element Node
      if (string(node->GetNodeName()) == "ParticleType") {
	ParticleType type;
	int id = -1;
	for (TXMLNode* data = node->GetChildren() ; data; data = data->GetNextNode()) {
	  if (data->GetNodeType() == TXMLNode::kXMLElementNode) { // Element Node
            if (strcmp(data->GetNodeName(), "Name") == 0)
	      type.name = data->GetText();
            if (strcmp(data->GetNodeName(), "Id") == 0)
	      id = atoi(data->GetText());
            if (strcmp(data->GetNodeName(), "Color") == 0) {
	      int color = atoi(data->GetText());
	      if (color == 3) 
		color = kGreen+1;
	      type.color = color;
	    }
            if (strcmp(data->GetNodeName(), "MinEnergy") == 0)
	      type.minEnergy = atof(data->GetText());
            if (strcmp(data->GetNodeName(), "MaxDraw") == 0)
	      type.maxDraw = atoi(data->GetText());
	  }
	}
	if (fParticleType.count(id)) {
	  cerr << " TPlotter::ParseConfig> Multiple definitions of particle Id=" << id
	       << endl;
	  return false;
	}
	fParticleType[id] = type;
	fParticleType[id].lines = new TObjArray();
	fParticleType[id].lines->SetOwner(kFALSE);
	fParticleType[id].count = 0;
      }
    }
  }
  return true;
}


void TPlotter::Clear() {
  
  fPrimaryTrack = true;
  fFirst = true;
  
  fEventNo = 0;
  fObservationLevel = 0;
  fHeightFirstInt = 0;
  fZenith = 0;
  fAzimuth = 0;
  fEnergy0 = 0;
  fPrimary = 0;
  
  fCosZenith = 0;
  fSinZenith = 0;
  fCosAzimuth = 0;
  fSinAzimuth = 0;
  
  for (map<int,ParticleType>::iterator i=fParticleType.begin(); i!=fParticleType.end(); ++i) {
    i->second.lines->Delete(); 
    i->second.lines = new TObjArray();
    i->second.lines->SetOwner(kFALSE);
    i->second.count = 0;     
  }
}



void TPlotter::SetShowerZenith (float zenith) {
  fZenith = zenith*rad;
  fCosZenith = cos (zenith);
  fSinZenith = sin (zenith);
}



void TPlotter::SetShowerAzimuth (float azimuth) {
  fAzimuth = azimuth*rad;
  fCosAzimuth = cos (azimuth);
  fSinAzimuth = sin (azimuth);
}


void TPlotter::SetRunHeader (const crs::MRunHeader &header) {
    
  int run = (int)header.GetRunID ();
  // create filename
  ostringstream fname;
  fname << "DAT" 
	<< setw (6) << setfill('0') << run;
  SetFileName (fname.str ());
}


void TPlotter::SetShowerHeader (const crs::MEventHeader &header) {

  // to flag the track of the primary particle
  fPrimaryTrack = true;

  SetEvent (header.GetEventNumber ());
  SetPrimary ((int)header.GetParticleID ());
  SetShowerZenith (header.GetTheta ()*rad);
  SetShowerAzimuth (header.GetPhi ()*rad);    
  SetShowerEnergy (header.GetEnergy ()*GeV);
  SetHeightFirstInt (header.GetZFirst ()*cm);
  SetObservationLevel (header.GetObservationHeight(header.GetNObservationLevels ()-1)*cm);

}
    
    
void TPlotter::SetShowerTrailer (const crs::MEventEnd &trailer) {
}


void TPlotter::Init() {
    
  ostringstream file_name;
  file_name << fFileName 
	    << "_"
	    << fEventNo
	    << "_3d.root";
    
  fFile = TFile::Open (file_name.str ().c_str (), "RECREATE");
  fFile->cd ();    

  ostringstream cname;
  cname << "ev_" << fEventNo; 

  fCanvas = new TCanvas(cname.str().c_str());
  fCanvas->SetView(new TView3D());

  /*
    fLinesElec->Delete();
    fLinesMuon->Delete();
    fLinesHadr->Delete();
  */
}


void TPlotter::Close () {
}


void TPlotter::Write () {

  fCanvas->cd();
  
  cout << " COAST> +++++++++++++++++++++++++++++++++++\n ";
  for (map<int,ParticleType>::iterator i=fParticleType.begin(); i!=fParticleType.end(); ++i) {
    cout << " COAST> plotted " << setw(8) << i->second.count << " tracks of type \'" << i->second.name << "\'\n";
    if ( i->second.count>0 ) { 
      i->second.lines->Draw();
    }
  }
  cout << " COAST> +++++++++++++++++++++++++++++++++++ " << endl;
  
  fCanvas->GetView ()->SetRange (fXmin, fYmin, fZmin, fXmax, fYmax, fZmax);
  fCanvas->Write ("", TFile::kOverwrite);
  fFile->Close ();
    
  Clear();
}




//#define Rotate(x, y, sx, sy, cosa, sina) { 
inline
void TPlotter::Rotate (double x, double y, double z,
		       double &sx, double &sy, double &sz,
		       int inverse) {
    

  double sx_ =             x*fCosAzimuth + inverse * y*fSinAzimuth;
  double sy_ = - inverse * x*fSinAzimuth +           y*fCosAzimuth; 
  double sz_ =   z;


  sx =             sx_*fCosZenith - inverse * sz_*fSinZenith;
  sy = sy_;
  sz = + inverse * sx_*fSinZenith +           sz_*fCosZenith; 

}


void TPlotter::AddTrack (const crs::CParticle &pre, 
			 const crs::CParticle &post) {
    

  /*
    Skip the track of the primary particle, which is in a different 
    reference system as the shower !!!
  */
  if (fPrimaryTrack) {
    fPrimaryTrack = false;
    return;
  }


  /*   ------------------------
       convert to shower frame
  */
  /*
    double pre_shX, pre_shY, pre_shZ;
    Rotate (pre.x, pre.y, fHeightFirstInt-pre.z, 
    pre_shX, pre_shY, pre_shZ, +1);


    double post_shX, post_shY, post_shZ;
    Rotate (post.x, post.y, fHeightFirstInt-post.z, 
    post_shX, post_shY, post_shZ, +1);
  */

  double e = post.energy/GeV;
  int particleID = (int)pre.particleID;
  
  double xPre = pre.x/km;
  double yPre = pre.y/km;
  double zPre = pre.z/km;
  
  double xPost = post.x/km;
  double yPost = post.y/km;
  double zPost = post.z/km;
  
  if (particleID<0) {
    fconex = true;
    particleID = -particleID;
  }else{
    fconex = false;
  }
  
  map<int,ParticleType>::iterator it = fParticleType.find(particleID);
  if (it == fParticleType.end())
    return;
  
  if (it->second.minEnergy>e)
    return;
  
  /*
    cout << " RU: "
    << " " << pre.particleID
    << " " << xPre 
    << " " << yPre 
    << " " << zPre 
    << " " << post.particleID
    << " " << xPost 
    << " " << yPost 
    << " " << zPost 
    << endl;
  */

  /*   ------------------------
       direction of particle in shower frame
  */
  double dX = xPost - xPre; 
  double dY = yPost - yPre; 
  double dZ = zPost - zPre; 
  double length = sqrt (dX*dX + dY*dY + dZ*dZ);
  
  if (length==0) {
    /*   ------------------------ 
	 This happens for particles that are NOT tracked by Corsika
	 e.g. pi0 -> decay immediatly
	 SKIP them
    */
    return;
  }	

  if (it->second.count>=it->second.maxDraw)
    return;
  
  const int color = it->second.color;
  
  TPolyLine3D* l = new TPolyLine3D(2);
  l->SetPoint(0, xPre, yPre, zPre);
  l->SetPoint(1, xPost, yPost, zPost);
  l->SetLineColor(color);
  //fCanvas->cd ();
  //l->Draw ();

  it->second.lines->Add(l);
  it->second.count++;
      
  if (fFirst) {

    fXmin = std::min (xPre, xPost);
    fYmin = std::min (yPre, yPost);
    fZmin = std::min (zPre, zPost);

    fXmax = std::max (xPre, xPost);
    fYmax = std::max (yPre, yPost);
    fZmax = std::max (zPre, zPost);

    fFirst = false;

  } else {

    if (std::min (xPre, xPost)<fXmin)
      fXmin = std::min (xPre, xPost);
    if (std::min (yPre, yPost)<fYmin)
      fYmin = std::min (yPre, yPost);
    if (std::min (zPre, zPost)<fZmin)
      fZmin = std::min (zPre, zPost);

    if (std::max (xPre, xPost)<fXmax)
      fXmax = std::max (xPre, xPost);
    if (std::max (yPre, yPost)<fYmax)
      fYmax = std::max (yPre, yPost);
    if (std::max (zPre, zPost)<fZmax)
      fZmax = std::max (zPre, zPost);

  }
    
}



double TPlotter::MoliereRadius (double VDepth,
				double Temperature) {

  static double E_scale = 21.*MeV;
  static double X_rad_length = 37*g/cm/cm;
  static double e_crit = 81.*MeV;
  static double R_m = E_scale * X_rad_length / e_crit;   // [g/cm2]

  // correct for 2 radiation length
  VDepth -= 2. * X_rad_length * fCosZenith;
  if (VDepth<=0) VDepth = 1.e-8;

  static double MeanAirDensity = 28.95 * g/mol;
  static double g_earth = 9.81 * m/(s*s);
  static double R_gas = 8.314 * joule/mol/Kelvin;
  //    static double Na = 6.022e23 / mol;
  double Pressure = VDepth * g_earth;
  double Density = Pressure / (R_gas*Temperature/MeanAirDensity);

  return R_m / Density;
}


/*
  double TPlotter::MoliereRadius (double Temperature, 
  double Pressure) {
    
  static double exponent = 1./5.25588;
    
  Temperature /= Kelvin;
  Pressure /= millibar;
    
  double CorrectedPressure = Pressure - 73.94*fCosZenith;
  if (CorrectedPressure<=0) {
  //cout << " RU: CorrectedPressure<0: " << CorrectedPressure << endl;
  //cout << " T: " << Temperature << " P: " << Pressure << endl;
  CorrectedPressure = 0.01;
  Pressure = CorrectedPressure + 73.94*fCosZenith;
  }

  double Rm = 272.5 * Temperature * 
  pow (CorrectedPressure/Pressure, exponent) / CorrectedPressure;
    
  return Rm * m;
  }
*/

double TPlotter::Temperature (double height) {
  /*
    h1(km)   h2(km) 	dT/dh (K/km)
    0 	11 	-6.5
    11 	20 	0.0
    20 	32 	1.0
    32 	47 	2.8
    47 	51 	0.0
    51 	71 	-2.8
    71 	84.852 	-2.0

    Note: 84.852 km geopotential=86 km geometric

    These data along with the sea level standard values of
    Sea level pressure = 101325 N/m2
    Sea level temperature = 288.15 K
    Hydrostatic constant = 34.1631947 kelvin/km
    define the atmosphere. The sea level density of 1.225 kg/m3 is 
    derived from the fundamental quantities above
  */

  double temp = 288.15*Kelvin;

  if (height < 11*km) {

    temp += -6.5*(Kelvin/km) * height;
	
  } else if (height < 20*km) {

    temp += -6.5*(Kelvin/km) * 11*km;

  } else if (height < 32*km) {

    temp += -6.5*(Kelvin/km) * 11*km
      + 1.0*(Kelvin/km) * (height-20*km);

  } else if (height < 47*km) {

    temp += -6.5*(Kelvin/km) * 11*km
      + 1.0*(Kelvin/km) * (32*km-20*km)
      + 2.8*(Kelvin/km) * (height-32*km);

  } else if (height < 51*km) {

    temp += -6.5*(Kelvin/km) * 11*km
      + 1.0*(Kelvin/km) * (32*km-20*km)
      + 2.8*(Kelvin/km) * (47*km-32*km);

  } else if (height < 71*km) {

    temp += -6.5*(Kelvin/km) * 11*km
      + 1.0*(Kelvin/km) * (32*km-20*km)
      + 2.8*(Kelvin/km) * (47*km-32*km)
      - 2.8*(Kelvin/km) * (height-51*km);

  } else if (height < 84.852*km) {

    temp += -6.5*(Kelvin/km) * 11*km
      + 1.0*(Kelvin/km) * (32*km-20*km)
      + 2.8*(Kelvin/km) * (47*km-32*km)
      - 2.8*(Kelvin/km) * (71*km-51*km)
      - 2.0*(Kelvin/km) * (height-71*km);

  } else {

    temp += -6.5*(Kelvin/km) * 11*km
      + 1.0*(Kelvin/km) * (32*km-20*km)
      + 2.8*(Kelvin/km) * (47*km-32*km)
      - 2.8*(Kelvin/km) * (71*km-51*km)
      - 2.0*(Kelvin/km) * (84.852*km-71*km);

  }

  return temp;
	
}
